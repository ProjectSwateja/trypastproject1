--Exercise n. 5
--Find the top 10 users (the id) who answered the most questions in 2010

SELECT  u.id as id_user,

count(pa.owner_user_id) as count

FROM 
`bigquery-public-data.stackoverflow.users` u
join `bigquery-public-data.stackoverflow.posts_answers` pa
on u.id=pa.owner_user_id
where EXTRACT( YEAR FROM pa.creation_date)=2010
group by id_user
order by count desc
limit 10
