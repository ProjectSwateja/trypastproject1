# GCP_Lab2_Bigquery
This Lab will focus on using Big Query and the public datasets available on GCP.

## Description

Given project contains 9 exercises based on big query and implemented on google cloud using public dataset.
