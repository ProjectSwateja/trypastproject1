--Exercise n. 7
--Find the most popular programming languages`

SELECT l.name, count(*)  as count FROM `bigquery-public-data.github_repos.languages`,
unnest(language) as l
group by l.name
order by count desc
limit 1
