
--Exercise n1. 
--Given the shared file top_4000_movies_data.csv 
--1. Create a BigQuery table “Movie” 
--2. Find the top 10 highest budget films, year by year, from 2016 to 2020.
with base_table as(
select *, EXTRACT(YEAR from Release_Date) as year
from `nttdata-c4e-bde.uc1_4.Movie`),
rank_table as(
select year,Movie_Title,Production_Budget,
Rank() over(PARTITION BY year order by Production_Budget desc) as rank
from base_table
where year between  2016 and 2020)
select Movie_Title,Production_Budget,year from rank_table where rank<11
order by year desc, Production_Budget desc 