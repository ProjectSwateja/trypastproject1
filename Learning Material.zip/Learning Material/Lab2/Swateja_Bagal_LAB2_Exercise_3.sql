--Exercise n. 3
--Show a flat result of the pages visited on 1st August 2017


SELECT
visitId, h.page.pageTitle, h.page.pagePath
from
`bigquery-public-data.google_analytics_sample.ga_sessions_20170801`,

unnest(hits) h