--Exercise n. 8
--Find the top 10 committers in 2016 on Github repositories that uses the Java languag

with base_table as(
    select l.name ,repo_name
    from 
    `bigquery-public-data.github_repos.languages`,
unnest(language) as l

) 
SELECT sc.repo_name as name,
committer.name as cname,
count(name) as count,

 FROM base_table  b
 inner join 
 `bigquery-public-data.github_repos.sample_commits` sc
 on b.repo_name=sc.repo_name
 where name="Java" and
 extract(YEAR FROM committer.date)=2016
 group by name,cname,name
 order by count desc
 limit 10