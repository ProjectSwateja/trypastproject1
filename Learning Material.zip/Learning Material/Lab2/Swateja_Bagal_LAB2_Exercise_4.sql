--Exercise n. 4
--Find how many times a page it was visited in July 2017. Group by date the result

SELECT 
count(h.page.pagePath) as counter,
h.page.pagePath,
cast(date as Date FORMAT 'YYYYMMDD') as date FROM 
`bigquery-public-data.google_analytics_sample.ga_sessions_201707*`,
unnest(hits)h
group by date,pagePath

order by date asc,counter des