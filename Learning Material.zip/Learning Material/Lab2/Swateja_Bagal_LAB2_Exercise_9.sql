--Exercise n. 9
--Find for each commit on Github on a .c file of the Linux kernel, the previous and the 
--next commit. 


SELECT repo_name,
d.new_path as file,
 committer.date as date,
lag(commit) over(PARTITION BY d.new_path order by committer.date) as privious_commit,
commit as commit,
lead(commit) over(PARTITION BY d.new_path order by committer.date) as next_commit,

FROM `bigquery-public-data.github_repos.sample_commits`,
unnest(difference) d
where repo_name like '%linux' and
d.new_path like '%kernel/acct.c'

