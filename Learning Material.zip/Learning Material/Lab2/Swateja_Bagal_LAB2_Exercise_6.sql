--Exercise n. 6
--Find the top 10 StackOverflow users (the id) by accepted responses on 2010 posts
select u.id,
count(*) as count
from `bigquery-public-data.stackoverflow.users` u
inner join 
`bigquery-public-data.stackoverflow.posts_answers` pa 
on u.id=pa.owner_user_id
 
INNER JOIN `bigquery-public-data.stackoverflow.stackoverflow_posts` sp
on sp.accepted_answer_id=pa.id
where sp.accepted_answer_id is not null
and Extract(YEAR from sp.creation_date )=2010
group by id
order by count DESC
limit 10
