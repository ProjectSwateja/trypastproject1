import requests

def get_feature_progress_section(features, redmine_url, api_key):
    if not features:
        return "### 📈 Feature Progress\n- No features defined for this team.\n"

    tracker_id_user_story = 6
    tracker_id_feature = 2

    output_lines = ["### 📈 Feature Progress"]
    headers = {"X-Redmine-API-Key": api_key}

    for feature_name, epic_id in features.items():
        total = 0
        closed = 0

        # Get children of Epic
        url = f"{redmine_url}/issues.json?parent_id={epic_id}&status_id=*"
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            output_lines.append(f"- **{feature_name}**: ❌ Failed to fetch epic children")
            continue

        epic_children = response.json().get("issues", [])
        for child in epic_children:
            tracker_id = child["tracker"]["id"]
            child_id = child["id"]

            # Case 1: Direct user story under epic
            if tracker_id == tracker_id_user_story:
                total += 1
                if child["status"]["name"].lower() == "closed":
                    closed += 1

            # Case 2: Feature → Get its user stories
            elif tracker_id == tracker_id_feature:
                feature_url = f"{redmine_url}/issues.json?parent_id={child_id}&tracker_id={tracker_id_user_story}&status_id=*"
                sub_resp = requests.get(feature_url, headers=headers)
                if sub_resp.status_code != 200:
                    continue
                stories = sub_resp.json().get("issues", [])
                total += len(stories)
                closed += sum(1 for s in stories if s["status"]["name"].lower() == "closed")

        percent = round((closed / total) * 100) if total else 0
        progress_bar = get_progress_bar(percent)
        output_lines.append(f"- **{feature_name}**: {progress_bar} {percent}% ({closed}/{total} closed)")

    return "\n".join(output_lines)


def get_progress_bar(percent):
    total_blocks = 20
    filled_blocks = round((percent / 100) * total_blocks)
    empty_blocks = total_blocks - filled_blocks
    return "🟩" * filled_blocks + "⬜" * empty_blocks
