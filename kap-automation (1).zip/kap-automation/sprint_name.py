import requests
import xml.etree.ElementTree as ET
from datetime import datetime

def get_current_sprint_name(redmine_url, api_key, project_id):
    url = f"{redmine_url}/projects/{project_id}/versions.xml"
    headers = {"X-Redmine-API-Key": api_key}
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        print(f"⚠️ Failed to fetch sprint info for project {project_id}")
        return "unknown_sprint"

    root = ET.fromstring(response.content)
    today = datetime.now().date()

    for version in root.findall('version'):
        due_date_el = version.find('due_date')
        if due_date_el is not None:
            due_date = datetime.strptime(due_date_el.text, "%Y-%m-%d").date()
            if today <= due_date:
                name_el = version.find('name')
                return name_el.text.replace(" ", "_") if name_el is not None else "unknown_sprint"

    return "unknown_sprint"
