import requests, json
from datetime import datetime, timedelta
from langchain.schema import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from feature_progress import get_feature_progress_section
from user_stories import fetch_user_stories
import xml.etree.ElementTree as ET
import logging

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# Load config
with open("config.json") as f:
    config = json.load(f)
logging.info("Loaded config.json file")

# Shared settings
api_key = config["api_key"]
redmine_url = config["redmine_url"]
OPENAI_API_KEY = config["openai_api_key"]
OPENAI_BASE_URL = config["openai_base_url"]
model_name = config["llm_model"]
days_back = config["days_back"]

gitlab_token = config["gitlab_token"]
gitlab_project_id = config["gitlab_project_id"]
gitlab_project_path = config["gitlab_project_path"]
gitlab_branch = config["gitlab_branch"]
gitlab_base_url = config["gitlab_base_url"]

# Date setup
today = datetime.now()
effective_day_back = 3 if today.weekday() == 0 else 1
check_date = (today - timedelta(days=effective_day_back)).strftime("%Y-%m-%d")
logging.info(f"Set check date to {check_date}")

# LLM setup
llm = ChatOpenAI(
    model=model_name,
    base_url=OPENAI_BASE_URL,
    api_key=OPENAI_API_KEY,
    temperature=0
)
logging.info("Initialized LLM")

# Get current sprint name from Redmine API
def get_current_sprint_name(redmine_url, api_key, project_id):
    logging.info(f"Getting current sprint name for project {project_id}")
    url = f"{redmine_url}/projects/{project_id}/versions.xml"
    headers = {"X-Redmine-API-Key": api_key}
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        logging.error(f"Failed to fetch versions for project {project_id}")
        return "unknown_sprint"
    root = ET.fromstring(response.content)
    for version in root.findall("version"):
        due_date_elem = version.find("due_date")
        name_elem = version.find("name")
        status_elem = version.find("status")
        if due_date_elem is not None and name_elem is not None:
            due_date = datetime.strptime(due_date_elem.text, "%Y-%m-%d")
            status = status_elem.text if status_elem is not None else "open"
            # if due_date >= today and status == "open":
            if due_date.date() >= today.date() and status == "open":
                logging.info(f"Found current sprint name: {name_elem.text.replace(' ', '_')}")
                return name_elem.text.replace(" ", "_")
    logging.info("No current sprint found")
    return "unknown_sprint"

# Generate focus points from LLM
def generate_focus_from_summary(summaries):
    logging.info("Generating focus points from summaries")
    joined = "\n".join([f"{k}: {v}" for k, v in summaries.items() if v.strip()])
    prompt = [
        SystemMessage(content="You're an experienced agile coach helping teams plan next steps."),
        HumanMessage(content=f"""
Here are the key contributions from each team member today:

{joined}

From this information, suggest 3 short, actionable team-wide focus points for tomorrow. Do not include explanations, only the bullet points.
""")
    ]
    logging.info("Invoking LLM to generate focus points")
    return llm.invoke(prompt).content.strip().split("\n")[:3]

def process_team(team_config):
    logging.info(f"Processing team: {team_config['team_name']}")
    team_name = team_config["team_name"]
    project_id = team_config["project_id"]
    exception_list = team_config.get("exception_list", [])
    folder_path = team_config.get("folder_path", "")
    sprint_folder = get_current_sprint_name(redmine_url, api_key, project_id)
    logging.info(f"Got sprint folder: {sprint_folder}")

    users_response = requests.get(
        f"{redmine_url}/projects/{project_id}/memberships.json",
        headers={"X-Redmine-API-Key": api_key}
    )
    if users_response.status_code != 200:
        logging.error(f"Failed to fetch users for team: {team_name}")
        return "", folder_path, sprint_folder

    users = users_response.json()["memberships"]
    user_ids = [(u["user"]["id"], u["user"]["name"]) for u in users if u["user"]["id"] not in exception_list]
    logging.info(f"Got user IDs: {user_ids}")

    user_data = []
    for uid, uname in user_ids:
        logging.info(f"Processing user: {uname}")
        issues = requests.get(
            f"{redmine_url}/issues.json",
            params={"assigned_to_id": uid, "status_id": "*"},
            headers={"X-Redmine-API-Key": api_key}
        ).json().get("issues", [])

        tasks = []
        for issue in issues:
            issue_id = issue["id"]
            resp = requests.get(
                f"{redmine_url}/issues/{issue_id}.json?include=journals",
                headers={"X-Redmine-API-Key": api_key}
            )
            if resp.status_code != 200: 
                logging.error(f"Failed to fetch issue {issue_id}")
                continue
            journals = resp.json()["issue"].get("journals", [])
            # notes = [j["notes"] for j in journals if "created_on" in j and j["created_on"].split("T")[0] == check_date and j["notes"]]
            notes = [j["notes"] for j in journals if "created_on" in j and j["created_on"].split("T")[0] == check_date and j.get("notes")]
            if notes:
                tasks.append(f"Issue ID: {issue_id}, Notes: {notes}")
        user_data.append({"user_name": uname, "user_id": uid, "tasks": tasks})
        logging.info(f"Processed user: {uname}")

    completed, no_tasks, contributions = [], [], {}
    table_rows, summaries = [], {}

    for u in user_data:
        logging.info(f"Processing user data: {u['user_name']}")
        uname, uid, tasks = u["user_name"], u["user_id"], u["tasks"]
        story_ids = fetch_user_stories(redmine_url, api_key, uid, sprint_folder)
        story_str = " ".join(story_ids) if story_ids else "-"

        msg = [
            SystemMessage(content="You are an expert project coordinator generating structured daily updates."),
            HumanMessage(content=f"""
Your response must be a valid JOSN object with three keys: "work_done", "next_steps", and "blockers".

Strictly summarize the developer's update in below format only:
{{
  "work_done": "summary of what was completed",
  "next_steps": "planned work",
  "blockers": "any current blockers"
}}

Do not add extra comments, explainations, or markdown outside the JSON object.

Developer: {uname}
Tasks: {tasks}
""")
        ]

        summary_msg = [
            SystemMessage(content="You are summarizing the most notable contribution in one line for highlights."),
            HumanMessage(content=f"""
Summarize the user's key accomplishment today in a single line for highlights.
Avoid general activities like meetings or syncs unless they are core contributions.
User Name: {uname}
Tasks: {tasks}""")
        ]

        if tasks:
            logging.info(f"User {uname} has tasks")
            contributions[uname] = len(tasks)
            completed.append(uname)
            #row_data = llm.invoke(msg)
            row_data = llm.invoke(msg).content.strip()
            logging.info(f"Invoked LLM for user {uname}")
            try:
                #parsed = json.loads(row_data.content.strip())
                parsed = json.loads(row_data)
                work_done = parsed.get("work_done", "-")
                next_steps = parsed.get("next_steps", "-")
                blockers = parsed.get("blockers", "-")
            except Exception as e:
                logging.error(f"Parsing error for {uname}: {e}\nRaw LLM output: {row_data.content.strip()}")
                work_done = " LLM format error"
                next_steps = blockers = "-"
            table_rows.append(f"| {uname} | {story_str} | {work_done} | {next_steps} | {blockers} |")
            summaries[uname] = llm.invoke(summary_msg).content.strip()
            logging.info(f"Processed user {uname}")
        else:
            logging.info(f"User {uname} has no tasks")
            no_tasks.append(uname)

    top_two = sorted(contributions.items(), key=lambda x: x[1], reverse=True)[:2]
    top_performer = top_two[0][0] if len(top_two) > 0 else "[Top Contributor]"
    second_best = top_two[1][0] if len(top_two) > 1 else "[Second Best]"

    focus_today = generate_focus_from_summary(summaries)
    team_features = team_config.get("features", {})
    feature_block = get_feature_progress_section(team_features, redmine_url, api_key)
    logging.info("Generated focus points and feature block")

    final_output = f"""
# 🚀 Daily Update  - {today.strftime('%Y-%m-%d')} ({team_name} Team)

### 🌟 Highlights
- Kudos to **{top_performer}** — {summaries.get(top_performer, 'for outstanding work!')} 
- Great progress by **{second_best}** — {summaries.get(second_best, 'on recent efforts!')}

---
{feature_block}
---

### Team Progress - What was accomplished yesterday 
| Developer         | User Stories | Work Done                | Next Steps           | Blockers        |
|-------------------|--------------|---------------------------|----------------------|------------------|
"""
    final_output += "\n".join(table_rows)
    final_output += "\n\n---\n\n### 🚫 Team Members With No Updates\n"
    for name in no_tasks:
        final_output += f"- **{name}** (On leave / no notes updated)\n"

    final_output += f"""

---
### 🗺️ Suggested Focus for Today
{focus_today[0]}
{focus_today[1] if len(focus_today) > 1 else '-'}
{focus_today[2] if len(focus_today) > 2 else '-'}

---
### ✅ Summary

- 👥 Total Members: **{len(user_data)}**
- 📌 With Updates: **{len(completed)}**
- 🚫 No Updates: **{len(no_tasks)}**

Let’s stay focused and keep the updates flowing! 📈
"""

    logging.info("Generated final output")
    return final_output, folder_path, sprint_folder

def upload_to_gitlab(file_name, content, folder_path, token, project_id, branch):
    logging.info(f"Uploading daily update to GitLab: {file_name}")
    encoded_project = requests.utils.quote(str(project_id), safe='')
    full_path = f"{folder_path}/{file_name}"
    url = f"{gitlab_base_url}/api/v4/projects/{encoded_project}/repository/files/{requests.utils.quote(full_path, safe='')}"
    headers = {"PRIVATE-TOKEN": token}
    data = {
        "branch": branch,
        "content": content,
        "commit_message": f"Add daily summary for {file_name}",
    }

    exists = requests.get(url, headers=headers, params={"ref": branch})
    response = requests.put(url, headers=headers, data=data) if exists.status_code == 200 else requests.post(url, headers=headers, data=data)

    if response.status_code in [200, 201]:
        logging.info(f"✅ GitLab updated: {full_path}")
        return f"{gitlab_base_url}/{gitlab_project_path}/-/blob/{branch}/{full_path}"
    else:
        logging.error(f" ❌ GitLab error: {response.status_code} - {response.text}")
        return None

# Run for each team
for team in config["teams"]:
    logging.info(f"Processing team: {team['team_name']}")
    block, folder_path, sprint_folder = process_team(team)
    file_name = f"{today.strftime('%Y-%m-%d')}.md"

    file_url = upload_to_gitlab(
        file_name=file_name,
        content=block,
        folder_path=f"{folder_path}/{sprint_folder}",
        token=gitlab_token,
        project_id=gitlab_project_id,
        branch=gitlab_branch
    )

    if file_url:
        msg = {
            "text": f" ✅ Daily summary for **{today.strftime('%Y-%m-%d')}** is now available for the **{team['team_name']}** team.\n [Click here to read the update]({file_url})"
        }
        requests.post(team["webhook_url"], json=msg)
        logging.info(f"📨 Notified: {team['team_name']}")
    else:
        logging.error(f"Failed to upload daily update for team {team['team_name']}")
