import requests

def fetch_user_stories(redmine_url, api_key, developer_id, sprint_name):
    headers = {"X-Redmine-API-Key": api_key}
    tracker_id_user_story = 6  # User Story
    tracker_id_task = 5        # Task

    url = f"{redmine_url}/issues.json?assigned_to_id={developer_id}&tracker_id={tracker_id_user_story}&status_id=*"
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        return []

    issues = response.json().get("issues", [])
    user_stories = []

    for issue in issues:
        # Skip if not in the current sprint
        fixed_version = issue.get("fixed_version", {}).get("name", "")
        if fixed_version.lower() != sprint_name.lower():
            continue

        story_id = issue["id"]

        # Fetch child tasks for this user story
        task_url = f"{redmine_url}/issues.json?parent_id={story_id}&tracker_id={tracker_id_task}&status_id=*"
        task_response = requests.get(task_url, headers=headers)
        tasks = task_response.json().get("issues", []) if task_response.status_code == 200 else []

        total = len(tasks)
        closed = sum(1 for t in tasks if t["status"]["name"].lower() == "closed")
        percent = round((closed / total) * 100) if total else 0

        user_stories.append(f"[{story_id}]({redmine_url}/issues/{story_id}) ({percent}%)")

    return user_stories
