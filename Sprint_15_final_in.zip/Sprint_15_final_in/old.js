// const reactNativeDotenv = require("react-native-dotenv");

// Trigger file input when user clicks on the text or icon
document.getElementById('triggerInput').addEventListener('click', function () {
  document.getElementById('videoInput').click();
});

document.getElementById('triggerIcon').addEventListener('click', function () {
  document.getElementById('videoInput').click();
});
document
  .getElementById('videoInput')
  .addEventListener('change', function (event) {
    const file = event.target.files[0];
    const videoPlayer = document.getElementById('videoPlayer');
    const scenarioButton = document.getElementById('actionButton');

    if (file && file.type.startsWith('video/')) {
      const fileURL = URL.createObjectURL(file);
      videoPlayer.src = fileURL;
      videoPlayer.style.display = 'block'; // Display video
      scenarioButton.style.display = 'block'; // Show button when video is displayed

      const formData = new FormData();
      formData.append('videoInput', file);

      fetch('/upload_video', {
        method: 'POST',
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            populateScenarios(data.scenarios, data.dropdownOptions);
          }
        });
    }
  });
function populateScenarios(scenarios, dropdownOptions) {
  const radioButtonsContainer = document.getElementById('scenarioRadioButtons');
  radioButtonsContainer.innerHTML = ''; // Clear previous buttons

  scenarios.forEach((scenario) => {
    // Create the label which will contain the radio button and text
    const label = document.createElement('label');
    label.style.display = 'block'; // Ensure label is displayed vertically

    // Create the radio button
    const radioButton = document.createElement('input');
    radioButton.type = 'radio';
    radioButton.name = 'scenario';
    radioButton.value = scenario.num;

    // Add radio button and scenario description inside the label
    label.appendChild(radioButton);
    label.appendChild(
      document.createTextNode(` [${scenario.num}] ${scenario.desc}`)
    );

    // Append the label to the container
    radioButtonsContainer.appendChild(label);
  });

  // Add the "Other" option
  const otherLabel = document.createElement('label');
  otherLabel.style.display = 'block';

  const otherOption = document.createElement('input');
  otherOption.type = 'radio';
  otherOption.name = 'scenario';
  otherOption.value = 'その他';
  otherOption.id = 'otherOption'; // Add an id for easier access later

  otherLabel.appendChild(otherOption);
  otherLabel.appendChild(document.createTextNode(' その他'));
  radioButtonsContainer.appendChild(otherLabel);

  // event listener to toggle dropdown visibility and populate when other is selected
  document.querySelectorAll('input[name="scenario"]').forEach((input) => {
    input.addEventListener('change', function () {
      const otherDropdown = document.getElementById('otherDropdown');
      if (this.value === 'その他') {
        otherDropdown.style.display = 'block';

        const dropdown = document.getElementById('scenarioDropdown');
        dropdown.innerHTML = '';

        dropdownOptions.forEach((option) => {
          optionElement.value = option;
          optionElement.text = option;
          dropdown.appendChild(optionElement);
        });
      } else {
        otherDropdown.style.display = 'none';
      }
    });
  });
}

document.getElementById('actionButton').addEventListener('click', function () {
  document.getElementById('radioBlock').style.display = 'block';
});

