from flask import Flask, render_template, request, jsonify
import google.ai.generativelanguage as glm
import json
import re
import os
import pandas as pd
import requests
from dotenv import load_dotenv
import google.generativeai as genai
from google.generativeai.types import ContentType
from PIL import Image
from IPython.display import Markdown
import time
import cv2
from pathlib import Path
import yaml
from yaml.loader import SafeLoader
import ast
import re
import numpy as np

UPLOAD_FOLDER = 'uploaded_video'
os.makedirs(UPLOAD_FOLDER, exist_ok = True)
# configのロード
with open(Path(__file__).parent.joinpath("config.yaml"), encoding="utf-8") as file:
    config = yaml.load(file, Loader=SafeLoader)



# API-KEYの設定
GOOGLE_API_KEY=config["gemini"]["api_key"]
genai.configure(api_key=GOOGLE_API_KEY)
GEMINI_MODEL=config["gemini"]["model"]

safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_NONE"
    }
]

response_schema1 = {
    "type": "string"
}

response_schema2 = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "判例番号": {
                "type": "string"
            },
            "事故内容": {
                "type": "string"
            },
            "A車": {
                "type": "string"
            },
            "B車": {
                "type": "string"
            },
            "理由": {
                "type": "string"
            },
        },
        #"required": ["判例番号","事故内容", "A車", "B車", "理由"]
        "required": ["判例番号"]
    }
}

response_schema3 = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "修正要素": {
                "type": "string"
            },
            "数値": {
                "type": "number"
            },
            "該当ありorなし": {
                "type": "boolean"
            },
            "該当理由": {
                "type": "string"
            },
            "秒数": {
                "type": "number"
            }
        },
        "required": ["修正要素","数値", "該当ありorなし", "該当理由", "秒数"]
    }
}

# Generation Config
generation_config= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
}

generation_config1= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema1
}

generation_config2= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  #"response_schema": response_schema2
}

generation_config3= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema3
}

generation_config4= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema3
}


model = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config, safety_settings=safety_settings)
model1 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config1, safety_settings=safety_settings)
model2 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config2, safety_settings=safety_settings)
model3 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config3, safety_settings=safety_settings)
model4 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config4, safety_settings=safety_settings)


load_dotenv()
app = Flask(__name__)
UPLOAD_FOLDER = 'uploaded_video'
os.makedirs(UPLOAD_FOLDER, exist_ok = True)
GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')

GEMINI_MODEL = os.getenv('GEMINI_MODEL')

safety_settings = [

    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},

]

generation_config = {

    "temperature": 0.2,

    "top_k": 1,

    "max_output_tokens": 8192,

    #"response_mime_type": "application/json",

}


@app.route('/')
def index():
    return render_template('index.html')

#Some Globally in code required files

@app.route('/upload_video', methods = ['POST'])
def upload_video():
    video = request.files.get('videoInput')
    if video:
        video_path = os.path.join(UPLOAD_FOLDER, video.filename)
        video.save(video_path)
        video_file = genai.upload_file(path=video_path)
        time.sleep(12)
        file_path = '序章.txt'
        with open(file_path, 'r', encoding='utf-8') as file:
            josho = file.read()


        with open(f"josho_prompt.txt", 'r', encoding='utf-8') as file:
            josho_prompt1 = file.read()
            josho_prompt= josho_prompt1.format(josho=josho)

        history1 = [
        {'role':'user','parts': [josho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        ]

        text = """交通事故のドライブレコーダー動画が渡されます。
        以下のどの状況に当てはまるか、もっとも近いものを1つだけ番号で回答してください。

            1　歩行者と自動車orバイク
            2　歩行者と自転車
            3　自動車と自動車
            4　バイクと自動車
            5　自転車と自動車orバイク
            6　高速道路上
            7　駐車場内
            0　該当なし


        ##回答例
            3
        """
        
        history1.append({'role':'user','parts':text})
        history1.append({'role':'user', 'parts': [video_file]})
        response = model1.generate_content(history1)
        result1 = response.text
        print(result1)
        print("------------------------------------------------------")

        # Step2: CarA CArB Details じこしゃ の しょうさい
        file_path = '事故車の詳細.txt'
        with open(file_path, 'r', encoding='utf-8') as file:
            prompt = file.read()

        file_path = '本章序文.txt'
        with open(file_path, 'r', encoding='utf-8') as file:
            honsho = file.read()
        
        honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
        {honsho}"""

        history2 = [
        {'role':'user','parts': [josho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        {'role':'user','parts': [honsho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        ]

        history2.append({'role':'user','parts':prompt})
        history2.append({'role':'user', 'parts': [video_file]})
        response = model.generate_content(history2)
        result2 = response.text
        print(result2)
        
        #Scenario Selection

        #Step3: Finding 3 matching scenarios
        #3シナリオ.txt Prompt file
        file_path = 'car_car.csv'

        with open(file_path, 'r', encoding='utf-8') as file:
            hanrei = file.read()

        with open(f"3シナリオ.txt", 'r', encoding='utf-8') as file:
            scenario3 = file.read()
            query2= scenario3.format(result2=result2, hanrei=hanrei)
            scenarios = model2.generate_content(query2).text
            print("**********scenario details***********")
            print(scenarios)
            print(type(scenarios))
            scenario_json = json.loads(scenarios)
            print(type(scenarios))
            print(scenario_json)           
            scenarios_format = [re.sub(r'【+|】+','',scenario) for scenario in scenario_json]
            scenarios_format = [f'【{scenario}】' for scenario in scenarios_format]
            # print(scenarios_format)           
            #return jsonify(success=True, scenarios=scenarios, dropdownOptions = first_column_data)

            csv_path = 'car_car.csv'
            df = pd.read_csv(csv_path)
            filtered_df = df[df.iloc[:,0].isin(scenarios_format)]
            filtered_df = filtered_df.replace({np.nan:None})
            selected_columns = filtered_df.iloc[:,[0,5,6,8,9]]
            scenario_data = selected_columns.to_dict(orient="records")
            # print(scenario_data)           
            print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')

            first_column_data = df.iloc[:, 0].tolist()
            first_column_data = [str(option).replace('【', '').replace('】','') for option in first_column_data]
            return jsonify(success=True,scenarios = scenario_data, dropdownOptions = first_column_data)

@app.route('/analyze_scenario', methods=['GET'])
def analyze_scenario():
    scenario_num = request.args.get('scenarioNum')
    result = f'Selected scenario {scenario_num}'
    return jsonify(result=result)

@app.route('/shusei_yousou', methods=['POST'])
def shusei_yousou():
    video = request.files.get('videoInput')
    if video:
        video_path = os.path.join(UPLOAD_FOLDER, video.filename)
        video.save(video_path)
        video_file2 = genai.upload_file(path=video_path)
        time.sleep(10)    
        file_path = '序章.txt'

    with open(file_path, 'r', encoding='utf-8') as file:
        josho = file.read()

    josho_prompt=f"""あなたは事故の状況から、過失割合の修正要素が該当するかどうか判断する保険会社の担当者です。
    まずは以下の「序章」の用語や考え方を覚えてください。
    {josho}"""

    #file_path = '3prompt.txt'
    #with open(file_path, 'r', encoding='utf-8') as file:
        #prompt = file.read()

    file_path = '本章序文.txt'
    with open(file_path, 'r', encoding='utf-8') as file:
        honsho = file.read()
    
    honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
    {honsho}"""

    with open( "104-1.txt", 'r', encoding='utf-8') as file:
        hanrei = file.read()

    hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。基本割合を数値も含めて出力してください。
    {hanrei}"""

    kihon_wariai = model.generate_content(hanrei_prompt)
    #print(kihon_wariai.text)

                    # 修正要素を算出
    hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。修正要素と数値を1行ずつ数値も含めて出力してください。
    {hanrei}"""

    shusei_youso1 = model.generate_content(hanrei_prompt)
    shusei_youso = shusei_youso1.text
    #print(shusei_youso)

    #return jsonify(result=shusei_youso)
                    # 他の判例番号の内容を参照する場合

    prompt = f"""
    与えられた文章のみを利用して出力してください。
    以下の修正要素に「参照」というワードが含まれている場合で、【】で囲まれている番号をすべて数値で表示してください。
    ()や（）で囲まれている番号は表示しないでください。
    空白や改行や数字以外の文字は含めないでください。


    修正要素：
    {hanrei}

    """
    response = model1.generate_content(prompt)
    file_names = json.loads(response.text)

    # 各辞書から 'hanrei_num' の値を取得してリストにする        
    hoka = ""

    # 各ファイル名に対して処理を行う
    for sansho in file_names:
    # ファイル名が空でない場合のみ処理を行う
        if sansho.strip():
            file_path = 'sansho.txt'        
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    hoka_text = file.read()
                hoka = hoka + hoka_text
            except FileNotFoundError:
                print(f"File not found: {file_path}")

    hanrei_prompt = f"""以下は「他の判例」の資料です。修正要素を算出する際に、参照が必要な場合に利用してください。
    {hoka}"""

    josho_prompt=f"""あなたは事故の状況から、過失割合の修正要素が該当するかどうか判断する保険会社の担当者です。
    まずは以下の「序章」の用語や考え方を覚えてください。
    {josho}"""
    
    honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
    {honsho}"""
                    
    query3 = f"""
                
                
                    交通事故の動画と、動画以外の追加要素が渡されます。
                    [出力内容]
                    以下に渡される[修正要素]の内容を1行ずつ、今回の交通事故に該当するか数値も含めて表示してください。
                    渡される[修正要素]以外の内容は表示しないでください。修正要素の数値は変更しないでください。
                    修正要素の内容は、過去の会話履歴の「本章序文」の用語を参考に判断してください。
                    修正要素が該当する場合「該当あり」として、その修正要素の内容と数値と算出理由を1行で教えてください。
                    算出理由となった内容が、動画の開始から何秒時点かも表示してください。
                    法定速度を超過している場合は、根拠となる情報も表示してください。
                    タイムスタンプを正しいフォーマットで表示する。X:X形式で渡す. 該当しない場合は「-」を表示
                    修正要素が「著しい過失」と「重過失」の両方に該当する場合は、「重過失」にしてください。
                    修正要素が適用できそうな場合、適用できるかどうかわからない場合は、「わからない」と記入し、修正要素の内容、数値、計算理由を1行で記入してください。
                    また、信頼度（%）も記入してください。この答えにどれだけの自信があるか。
                    修正要素が該当しない場合「該当なし」として表示してください。
                    【】で囲まれた数字の判例番号の参照が必要な場合、過去の会話で与えられた「他の判例」を参照してください。
                    最終的な過失割合はここでは算出しないで、基本割合と修正要素と修正要素の理由だけを出力してください。

                    [修正要素]
                    {shusei_youso}

    """

    history3 = [
        {'role':'user','parts': [josho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        {'role':'user','parts': [honsho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        {'role':'user','parts': [hanrei_prompt]},
        {'role':'model','parts': ["理解しました"]},
    ]   

    history3.append({'role':'user', 'parts': [video_file2]})
    history3.append({'role':'user','parts':query3})
    result4 = model3.generate_content(history3).text
    print("************modifier prompt******************")
    print(result4)
    print("************modifier type******************")
    print(type(result4))
    print("*************Type is ****************")
    data1 = json.loads(result4)
    print(type(data1))
    print(data1)
    formatted_data = []
    for key, value in data1.items():
        # Split the '該当あり/なし' part from the rest
        parts = value.split(':', 1)
        decision = parts[0].strip()
        details = parts[1].strip() if len(parts) > 1 else ""

        # Parse number, reason, and timerange if present
        number = key.split(":")[-1].strip()  # Assuming number is in the key
        reason = ""
        time_range = ""
       
        # Extract timestamp if available in the details
        if "(" in details and ")" in details:
            reason, time_range = details.rsplit("(", 1)
            time_range = time_range.rstrip(")")
        else:
            reason = details
       
        # Append to formatted data
        formatted_data.append({
            "text": key.split(":")[0].strip(),  # 修正要素 (element) text
            "number": number,
            "decision": decision,
            "timeRange": time_range,
            "reason": reason.strip(),
        })
        print(formatted_data)
   
    return jsonify(formatted_data)



# @app.route('/process_data', methods = ['POST'])
# def process_data():
#     #response = request.get_json()
#     import json
#     video = request.files.get('videoInput')
#     response1 = request.form.get('data')
#     response1 = json.loads(response1)
#     # data = shusei_yousou()
#     video = request.files.get('videoInput')
#     if video:
#         video_path = os.path.join(UPLOAD_FOLDER, video.filename)
#         video.save(video_path)
#         video_file2 = genai.upload_file(path=video_path)
#         time.sleep(10)    
#         file_path = '序章.txt'

#     with open(file_path, 'r', encoding='utf-8') as file:
#         josho = file.read()

#     josho_prompt=f"""あなたは事故の状況から、過失割合の修正要素が該当するかどうか判断する保険会社の担当者です。
#     まずは以下の「序章」の用語や考え方を覚えてください。
#     {josho}"""

#     file_path = '本章序文.txt'
#     with open(file_path, 'r', encoding='utf-8') as file:
#         honsho = file.read()
    
#     honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
#     {honsho}"""

#     with open( "104-1.txt", 'r', encoding='utf-8') as file:
#         hanrei = file.read()

#     hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。基本割合を数値も含めて出力してください。
#     {hanrei}"""

#     kihon_wariai = model.generate_content(hanrei_prompt)
#     print(kihon_wariai.text)

#                     # 修正要素を算出
#     hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。修正要素と数値を1行ずつ数値も含めて出力してください。
#     {hanrei}"""

#     shusei_youso1 = model.generate_content(hanrei_prompt)
#     shusei_youso = shusei_youso1.text
#     #print(shusei_youso)

#     #return jsonify(result=shusei_youso)
#                     # 他の判例番号の内容を参照する場合

#     prompt = f"""
#     与えられた文章のみを利用して出力してください。
#     以下の修正要素に「参照」というワードが含まれている場合で、【】で囲まれている番号をすべて数値で表示してください。
#     ()や（）で囲まれている番号は表示しないでください。
#     空白や改行や数字以外の文字は含めないでください。

#     修正要素：
#     {hanrei}

#     """
#     response = model1.generate_content(prompt)
#     file_names = json.loads(response.text)

#     # 各辞書から 'hanrei_num' の値を取得してリストにする        
#     hoka = ""

#     # 各ファイル名に対して処理を行う
#     for sansho in file_names:
#     # ファイル名が空でない場合のみ処理を行う
#         if sansho.strip():
#             file_path = 'sansho.txt'        
#             try:
#                 with open(file_path, 'r', encoding='utf-8') as file:
#                     hoka_text = file.read()
#                 hoka = hoka + hoka_text
#             except FileNotFoundError:
#                 print(f"File not found: {file_path}")

#     hanrei_prompt = f"""以下は「他の判例」の資料です。修正要素を算出する際に、参照が必要な場合に利用してください。
#     {hoka}"""
              
#     query3 = f"""
#     交通事故の動画が渡されます。

#     [出力内容]
#     以下に渡される[修正要素]の内容を1行ずつ、今回の交通事故に該当するか数値も含めて表示してください。
#     渡される[修正要素]以外の内容は表示しないでください。修正要素の数値は変更しないでください。
#     修正要素の内容は、過去の会話履歴の「本章序文」の用語を参考に判断してください。
#     修正要素が該当する場合「該当あり」として、その修正要素の内容と数値と算出理由を1行で教えてください。
#     算出理由となった内容が、動画の開始から何秒時点かも表示してください。
#     法定速度を超過している場合は、根拠となる情報も表示してください。
#     修正要素が該当しない場合「該当なし」として表示してください。

#     【】で囲まれた数字の判例番号の参照が必要な場合、過去の会話で与えられた「他の判例」を参照してください。

#     最終的な過失割合はここでは算出しないで、基本割合と修正要素と修正要素の理由だけを出力してください。

#     [修正要素]
#     {shusei_youso}
#     """

#     history3 = [
#         {'role':'user','parts': [josho_prompt]},
#         {'role':'model','parts': ["理解しました"]},
#         {'role':'user','parts': [honsho_prompt]},
#         {'role':'model','parts': ["理解しました"]},
#         {'role':'user','parts': [hanrei_prompt]},
#         {'role':'model','parts': ["理解しました"]},
#     ]   

#     history3.append({'role':'user', 'parts': [video_file2]})
#     history3.append({'role':'user','parts':query3})
#     result4 = model3.generate_content(history3).text
#     print("************modifier prompt******************")
#     print(result4)
#     data = json.loads(result4)
#     df = pd.DataFrame(data)
#     print(df)
#     return result4

if __name__ == '__main__':
     app.run(debug=True)
 