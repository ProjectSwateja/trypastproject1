from flask import Flask, render_template, request, jsonify
import google.ai.generativelanguage as glm
import json
import re
import os
import pandas as pd
import requests
from dotenv import load_dotenv
import google.generativeai as genai
from google.generativeai.types import ContentType
from PIL import Image
from IPython.display import Markdown
import time
import cv2
from pathlib import Path
import yaml
from yaml.loader import SafeLoader
import ast
import re
import numpy as np

UPLOAD_FOLDER = 'uploaded_video'
os.makedirs(UPLOAD_FOLDER, exist_ok = True)
# configのロード
with open(Path(__file__).parent.joinpath("config.yaml"), encoding="utf-8") as file:
    config = yaml.load(file, Loader=SafeLoader)



# API-KEYの設定
GOOGLE_API_KEY=config["gemini"]["api_key"]
genai.configure(api_key=GOOGLE_API_KEY)
GEMINI_MODEL=config["gemini"]["model"]

safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_NONE"
    }
]



# Generation Config
generation_config= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
}

generation_config1= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
#   "response_schema": response_schema1
}

generation_config2= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
#   "response_schema": response_schema2
}

generation_config3= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
#   "response_schema": response_schema3
}

generation_config4= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
#   "response_schema": response_schema3
}

model = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config, safety_settings=safety_settings)
model1 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config1, safety_settings=safety_settings)
model2 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config2, safety_settings=safety_settings)
model3 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config3, safety_settings=safety_settings)
model4 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config4, safety_settings=safety_settings)

load_dotenv()
app = Flask(__name__)
UPLOAD_FOLDER = 'uploaded_video'
os.makedirs(UPLOAD_FOLDER, exist_ok = True)
GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')

GEMINI_MODEL = os.getenv('GEMINI_MODEL')

safety_settings = [

    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},

]

generation_config = {

    "temperature": 0.2,

    "top_k": 1,

    "max_output_tokens": 8192,

    #"response_mime_type": "application/json",

}


@app.route('/')
def index():
    return render_template('index.html')

#Some Globally in code required files

@app.route('/upload_video', methods = ['POST'])
def upload_video():
    video = request.files.get('videoInput')
    if video:
        video_path = os.path.join(UPLOAD_FOLDER, video.filename)
        video.save(video_path)
        video_file = genai.upload_file(path=video_path)
        time.sleep(12)
        file_path = '序章.txt'
        with open(file_path, 'r', encoding='utf-8') as file:
            josho = file.read()


        with open(f"josho_prompt.txt", 'r', encoding='utf-8') as file:
            josho_prompt1 = file.read()
            josho_prompt= josho_prompt1.format(josho=josho)

        history1 = [
        {'role':'user','parts': [josho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        ]

        text = """交通事故のドライブレコーダー動画が渡されます。
        以下のどの状況に当てはまるか、もっとも近いものを1つだけ番号で回答してください。

            1　歩行者と自動車orバイク
            2　歩行者と自転車
            3　自動車と自動車
            4　バイクと自動車
            5　自転車と自動車orバイク
            6　高速道路上
            7　駐車場内
            0　該当なし


        ##回答例
            3
        """
        
        history1.append({'role':'user','parts':text})
        history1.append({'role':'user', 'parts': [video_file]})
        response = model1.generate_content(history1)
        result1 = response.text
        print(result1)
        print("------------------------------------------------------")

        # Step2: CarA CArB Details じこしゃ の しょうさい
        file_path = '事故車の詳細.txt'
        with open(file_path, 'r', encoding='utf-8') as file:
            prompt = file.read()

        file_path = '本章序文.txt'
        with open(file_path, 'r', encoding='utf-8') as file:
            honsho = file.read()
        
        honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
        {honsho}"""

        history2 = [
        {'role':'user','parts': [josho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        {'role':'user','parts': [honsho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        ]

        history2.append({'role':'user','parts':prompt})
        history2.append({'role':'user', 'parts': [video_file]})
        response = model.generate_content(history2)
        result2 = response.text
        print(result2)
        
        #Scenario Selection

        #Step3: Finding 3 matching scenarios
        #3シナリオ.txt Prompt file
        file_path = 'car_car.csv'

        with open(file_path, 'r', encoding='utf-8') as file:
            hanrei = file.read()

        with open(f"3シナリオ.txt", 'r', encoding='utf-8') as file:
            scenario3 = file.read()
            query2= scenario3.format(result2=result2, hanrei=hanrei)
            scenarios = model2.generate_content(query2).text
            print(scenarios)
            print(type(scenarios))
            scenario_json = json.loads(scenarios)
            # print(scenario_json)           
            scenarios_format = [re.sub(r'【+|】+','',scenario) for scenario in scenario_json]
            scenarios_format = [f'【{scenario}】' for scenario in scenarios_format]
            # print(scenarios_format)           
            #return jsonify(success=True, scenarios=scenarios, dropdownOptions = first_column_data)

            csv_path = 'car_car.csv'
            df = pd.read_csv(csv_path)
            filtered_df = df[df.iloc[:,0].isin(scenarios_format)]
            filtered_df = filtered_df.replace({np.nan:None})
            selected_columns = filtered_df.iloc[:,[0,5,6,8,9]]
            scenario_data = selected_columns.to_dict(orient="records")
            # print(scenario_data)           
            print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')

            first_column_data = df.iloc[:, 0].tolist()
            first_column_data = [str(option).replace('【', '').replace('】','') for option in first_column_data]
            return jsonify(success=True,scenarios = scenario_data, dropdownOptions = first_column_data)

@app.route('/analyze_scenario', methods=['GET'])
def analyze_scenario():
    scenario_num = request.args.get('scenarioNum')
    result = f'Selected scenario {scenario_num}'
    return jsonify(result=result)

@app.route('/shusei_yousou', methods=['POST'])
def shusei_yousou():
    video = request.files.get('videoInput')
    if video:
        video_path = os.path.join(UPLOAD_FOLDER, video.filename)
        video.save(video_path)
        video_file2 = genai.upload_file(path=video_path)
        time.sleep(10)    
        file_path = '序章.txt'

    with open(file_path, 'r', encoding='utf-8') as file:
        josho = file.read()

    josho_prompt=f"""あなたは事故の状況から、過失割合の修正要素が該当するかどうか判断する保険会社の担当者です。
    まずは以下の「序章」の用語や考え方を覚えてください。
    {josho}"""

    #file_path = '3prompt.txt'
    #with open(file_path, 'r', encoding='utf-8') as file:
        #prompt = file.read()

    file_path = '本章序文.txt'
    with open(file_path, 'r', encoding='utf-8') as file:
        honsho = file.read()
    
    honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
    {honsho}"""

    with open( "104-1.txt", 'r', encoding='utf-8') as file:
        hanrei = file.read()

    hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。基本割合を数値も含めて出力してください。
    {hanrei}"""

    kihon_wariai = model.generate_content(hanrei_prompt)
    print(kihon_wariai.text)

                    # 修正要素を算出
    hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。修正要素と数値を1行ずつ数値も含めて出力してください。
    {hanrei}"""

    shusei_youso1 = model.generate_content(hanrei_prompt)
    shusei_youso = shusei_youso1.text
    print(shusei_youso)

    #return jsonify(result=shusei_youso)
                    # 他の判例番号の内容を参照する場合

    prompt = f"""
    与えられた文章のみを利用して出力してください。
    以下の修正要素に「参照」というワードが含まれている場合で、【】で囲まれている番号をすべて数値で表示してください。
    ()や（）で囲まれている番号は表示しないでください。
    空白や改行や数字以外の文字は含めないでください。


    修正要素：
    {hanrei}

    """
    response = model1.generate_content(prompt)
    file_names = json.loads(response.text)

    # 各辞書から 'hanrei_num' の値を取得してリストにする        
    hoka = ""

    # 各ファイル名に対して処理を行う
    for sansho in file_names:
    # ファイル名が空でない場合のみ処理を行う
        if sansho.strip():
            file_path = 'sansho.txt'        
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    hoka_text = file.read()
                hoka = hoka + hoka_text
            except FileNotFoundError:
                print(f"File not found: {file_path}")

    hanrei_prompt = f"""以下は「他の判例」の資料です。修正要素を算出する際に、参照が必要な場合に利用してください。
    {hoka}"""

    josho_prompt=f"""あなたは事故の状況から、過失割合の修正要素が該当するかどうか判断する保険会社の担当者です。
    まずは以下の「序章」の用語や考え方を覚えてください。
    {josho}"""
    
    honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
    {honsho}"""
                    
    query3 = f"""
                
                    交通事故の動画と、動画以外の追加要素が渡されます。
                    [出力内容]
                    以下に渡される[修正要素]の内容を1行ずつ、今回の交通事故に該当するか数値も含めて表示してください。
                    渡される[修正要素]以外の内容は表示しないでください。修正要素の数値は変更しないでください。
                    修正要素の内容は、過去の会話履歴の「本章序文」の用語を参考に判断してください。
                    修正要素が該当する場合「該当あり」として、その修正要素の内容と数値と算出理由を1行で教えてください。
                    算出理由となった内容が、動画の開始から何秒時点かも表示してください。
                    法定速度を超過している場合は、根拠となる情報も表示してください。
                    タイムスタンプを正しいフォーマットで表示する。X:X形式で渡す. 該当しない場合は「-」を表示
                    修正要素が「著しい過失」と「重過失」の両方に該当する場合は、「重過失」にしてください。
                    修正要素が適用できそうな場合、適用できるかどうかわからない場合は、「わからない」と記入し、修正要素の内容、数値、計算理由を1行で記入してください。
                    また、信頼度（%）も記入してください。この答えにどれだけの自信があるか。
                    修正要素が該当しない場合「該当なし」として表示してください。
                    【】で囲まれた数字の判例番号の参照が必要な場合、過去の会話で与えられた「他の判例」を参照してください。
                    最終的な過失割合はここでは算出しないで、基本割合と修正要素と修正要素の理由だけを出力してください。

                    [修正要素]
                    {shusei_youso}

                    """

    history3 = [
        {'role':'user','parts': [josho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        {'role':'user','parts': [honsho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        {'role':'user','parts': [hanrei_prompt]},
        {'role':'model','parts': ["理解しました"]},
    ]   

    history3.append({'role':'user', 'parts': [video_file2]})
    history3.append({'role':'user','parts':query3})
    result4 = model3.generate_content(history3).text
    print("************modifier prompt******************")
    print(result4)
    print("*************Type is ****************")
    data1 = json.loads(result4)
    print(data1)
    formatted_data = []
    for key, value in data1.items():
        # Split the '該当あり/なし' part from the rest
        parts = value.split(':', 1)
        decision = parts[0].strip()
        details = parts[1].strip() if len(parts) > 1 else ""

        # Parse number, reason, and timerange if present
        number = key.split(":")[-1].strip()  # Assuming number is in the key
        reason = ""
        time_range = ""
       
        # Extract timestamp if available in the details
        if "(" in details and ")" in details:
            reason, time_range = details.rsplit("(", 1)
            time_range = time_range.rstrip(")")
        else:
            reason = details
       
        # Append to formatted data
        formatted_data.append({
            "text": key.split(":")[0].strip(),  # 修正要素 (element) text
            "number": number,
            "decision": decision,
            "timeRange": time_range,
            "reason": reason.strip(),
        })
        print(formatted_data)
   
    return jsonify(formatted_data)

@app.route('/process_data', methods = ['POST'])
def process_data():
    #response = request.get_json()
    video = request.files.get('videoInput')
    response1 = request.form.get('data')
    response1 = json.loads(response1)
    # data = shusei_yousou()
    video = request.files.get('videoInput')
    if video:
        video_path = os.path.join(UPLOAD_FOLDER, video.filename)
        video.save(video_path)
        video_file2 = genai.upload_file(path=video_path)
        time.sleep(10)    
        file_path = '序章.txt'

    with open(file_path, 'r', encoding='utf-8') as file:
        josho = file.read()

    josho_prompt=f"""あなたは事故の状況から、過失割合の修正要素が該当するかどうか判断する保険会社の担当者です。
    まずは以下の「序章」の用語や考え方を覚えてください。
    {josho}"""

    #file_path = '3prompt.txt'
    #with open(file_path, 'r', encoding='utf-8') as file:
        #prompt = file.read()

    file_path = '本章序文.txt'
    with open(file_path, 'r', encoding='utf-8') as file:
        honsho = file.read()
    
    honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
    {honsho}"""

    with open( "104-1.txt", 'r', encoding='utf-8') as file:
        hanrei = file.read()

    hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。基本割合を数値も含めて出力してください。
    {hanrei}"""

    kihon_wariai = model.generate_content(hanrei_prompt)
    print(kihon_wariai.text)

                    # 修正要素を算出
    hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。修正要素と数値を1行ずつ数値も含めて出力してください。
    {hanrei}"""

    shusei_youso1 = model.generate_content(hanrei_prompt)
    shusei_youso = shusei_youso1.text
    print(shusei_youso)

    #return jsonify(result=shusei_youso)
                    # 他の判例番号の内容を参照する場合

    prompt = f"""
    与えられた文章のみを利用して出力してください。
    以下の修正要素に「参照」というワードが含まれている場合で、【】で囲まれている番号をすべて数値で表示してください。
    ()や（）で囲まれている番号は表示しないでください。
    空白や改行や数字以外の文字は含めないでください。


    修正要素：
    {hanrei}

    """
    response = model1.generate_content(prompt)
    file_names = json.loads(response.text)

    # 各辞書から 'hanrei_num' の値を取得してリストにする        
    hoka = ""

    # 各ファイル名に対して処理を行う
    for sansho in file_names:
    # ファイル名が空でない場合のみ処理を行う
        if sansho.strip():
            file_path = 'sansho.txt'        
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    hoka_text = file.read()
                hoka = hoka + hoka_text
            except FileNotFoundError:
                print(f"File not found: {file_path}")

    hanrei_prompt = f"""以下は「他の判例」の資料です。修正要素を算出する際に、参照が必要な場合に利用してください。
    {hoka}"""

    josho_prompt=f"""あなたは事故の状況から、過失割合の修正要素が該当するかどうか判断する保険会社の担当者です。
    まずは以下の「序章」の用語や考え方を覚えてください。
    {josho}"""
    
    honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
    {honsho}"""
                    
    query3 = f"""
                
                    交通事故の動画と、動画以外の追加要素が渡されます。
                    [出力内容]
                    以下に渡される[修正要素]の内容を1行ずつ、今回の交通事故に該当するか数値も含めて表示してください。
                    渡される[修正要素]以外の内容は表示しないでください。修正要素の数値は変更しないでください。
                    修正要素の内容は、過去の会話履歴の「本章序文」の用語を参考に判断してください。
                    修正要素が該当する場合「該当あり」として、その修正要素の内容と数値と算出理由を1行で教えてください。
                    算出理由となった内容が、動画の開始から何秒時点かも表示してください。
                    法定速度を超過している場合は、根拠となる情報も表示してください。
                    タイムスタンプを正しいフォーマットで表示する。X:X形式で渡す. 該当しない場合は「-」を表示
                    修正要素が「著しい過失」と「重過失」の両方に該当する場合は、「重過失」にしてください。
                    修正要素が適用できそうな場合、適用できるかどうかわからない場合は、「わからない」と記入し、修正要素の内容、数値、計算理由を1行で記入してください。
                    また、信頼度（%）も記入してください。この答えにどれだけの自信があるか。
                    修正要素が該当しない場合「該当なし」として表示してください。
                    【】で囲まれた数字の判例番号の参照が必要な場合、過去の会話で与えられた「他の判例」を参照してください。
                    最終的な過失割合はここでは算出しないで、基本割合と修正要素と修正要素の理由だけを出力してください。

                    [修正要素]
                    {shusei_youso}

                    """

    history3 = [
        {'role':'user','parts': [josho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        {'role':'user','parts': [honsho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        {'role':'user','parts': [hanrei_prompt]},
        {'role':'model','parts': ["理解しました"]},
    ]   

    history3.append({'role':'user', 'parts': [video_file2]})
    history3.append({'role':'user','parts':query3})
    result4 = model3.generate_content(history3).text
    print("************modifier prompt******************")
    print(result4)
    data = json.loads(result4)
    result41=data

    # default_response = [
    #     {'firstColumn': 'Bの明らかな先入', 'action': 'False'}, 
    #     {'firstColumn': 'Aの著しい過失', 'action': 'False'},
    #     {'firstColumn': 'Aの重過失', 'action': 'False'},
    #     {'firstColumn': 'Bの著しい過失', 'action': 'False'},
    #     {'firstColumn': 'Bの重過失', 'action': 'False'}
    #     ]

    # for item in response: 
    #     if item['action'] == 'Yes': item['action'] = True
    # print(response)
    # print("********User data and gemini data recived************")

    # for res in response:
    #     for default_res in default_response:
    #         if res['firstColumn'] == default_res['firstColumn']:
    #             default_res['action'] = res['action']

    # print(default_response)

    # for d in data:
    #     for dr in default_response:
    #         if d["修正要素"] == dr["firstColumn"]:
    #             d["該当ありorなし"] = dr["action"]
            #d["該当理由"] = r["action"]

#print(data)
    
    # data1 = json.dumps(data)
    # data2 = json.loads(data1)
    # df = pd.DataFrame(data2)
    # print("************Process data method updated modifier*****************")
    # print(df)
    # #response = request.form['data']
    # # response1 = request.form['videoInput']
    # #print("User modified on UI:", data)
    # #print("***********outer function called*******")
    # #result4 = shusei_yousou()

    # result41=data2
    # print("************fault prompt modifier***********")
    # print(result41)
    file_path = '序章.txt'
    with open(file_path, 'r', encoding='utf-8') as file:
        josho = file.read()

    josho_prompt=f"""あなたは事故の状況から、過失割合の修正要素が該当するかどうか判断する保険会社の担当者です。
    まずは以下の「序章」の用語や考え方を覚えてください。
    {josho}"""

    #file_path = '3prompt.txt'
    #with open(file_path, 'r', encoding='utf-8') as file:
        #prompt = file.read()

    file_path = '本章序文.txt'
    with open(file_path, 'r', encoding='utf-8') as file:
        honsho = file.read()
    
    honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
    {honsho}"""

    with open( "104-1.txt", 'r', encoding='utf-8') as file:
        hanrei = file.read()

    hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。基本割合を数値も含めて出力してください。
    {hanrei}"""

    kihon_wariai = model.generate_content(hanrei_prompt)
    print(kihon_wariai.text)

                    # 修正要素を算出
    hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。修正要素と数値を1行ずつ数値も含めて出力してください。
    {hanrei}"""

    shusei_youso1 = model.generate_content(hanrei_prompt)
    shusei_youso = shusei_youso1.text
    print(shusei_youso)


    josho_prompt=f"""あなたは事故の状況から、過失割合の修正要素が該当するかどうか判断する保険会社の担当者です。
    まずは以下の「序章」の用語や考え方を覚えてください。
    {josho}"""

    # file_path = '本章序文.txt'
    # with open(file_path, 'r', encoding='utf-8') as file:
    #     honsho = file.read()
    
    honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
    {honsho}"""

    # 修正要素を算出
    #hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。修正要素と数値を1行ずつ数値も含めて出力してください。
    #{hanrei}"""

    def calculate_fault_ratio(base_a: int, base_b: int, factors_a: list[int], factors_b: list[int]) -> (int, int):
        """ 与えられた基本割合と修正要素から、交通事故過失割合を算出する 
        base_a:Aの基本割合
        base_b:Bの基本割合
        factors_a:Aの修正要素（配列）
        factors_b:Bの修正要素（配列）
        """
        
        # Aの基本割合を基準にして修正要素を加減
        adjusted_a = base_a + sum(factors_a) + sum(factors_b)
        
        # 過失割合の最大を100とする
        if adjusted_a > 100:
            adjusted_a = 100

        # 過失割合の最小を0とする
        if adjusted_a < 0:
            adjusted_a = 0
        
        
        # 最終的に100からAの値を減算した値がBの過失割合になる
        fault_ratio_a = adjusted_a
        fault_ratio_b = 100 - fault_ratio_a
        
        return fault_ratio_a, fault_ratio_b

    functions = {
        "calculate_fault_ratio": calculate_fault_ratio,
    }

    prompt = f"""与えられた基本割合と修正要素から、交通事故過失割合を算出してレポートを作成してください。最終的な過失割合の計算は必ず関数を使用してください。修正要素が渡されない場合は、修正要素は0として算出してください。
    修正要素の「著しい過失」と「重過失」の両方も該当する場合は、「重過失」だけを考慮する。
    #基本割合
    {kihon_wariai}
    #修正要素
    {result41}
    ##計算方法
    修正要素の「著しい過失」と「重過失」の両方も該当する場合は、「重過失」だけを考慮する。
    A車　最終過失割合　＝　＜A車 基本割合＞　+ ＜A車 該当する全ての修正要素＞ + ＜B車 該当する全ての修正要素＞
    # 過失割合の最小を0、最大を100とする（Aのみ計算）
    B車　最終過失割合　＝　100 - ＜A車　最終過失割合＞
    
    #以下の計算を正しく行い、各ステップを改行してください。

    ##出力テンプレート##
    （以下の内容を実際のアウトプットに上書きする。車Aと車Bの間にいつも改行する）
    ■ 基本割合:
    → A車：〇〇
    → B車：〇〇
    ■ 該当の修正要素
    → A車：修正要素〇〇 数値〇〇　
    → B車：修正要素〇〇 数値〇〇
    ■ 過失割合計算
    → A車　最終過失割合 = 〇〇 + 〇〇 + 〇〇
    → B車　最終過失割合 = 100 - 〇〇
    ■　計算の説明
    →　〇〇
    
    ■ 最終過失割合
    → A車：〇〇
    → B車：〇〇
    
    #出力例
    ■ 基本割合:
    → A車：20
    → B車：80
    ■ 該当の修正要素
    → A車：Aの重過失 +20　
    → B車：Bの著しい過失 -10
    ■ 過失割合計算
    → A車　最終過失割合 30 = 20 + 20 + (-10)
    → B車　最終過失割合 70 = 100 - 30
    
    ■　計算の説明
    A車の修正要素: 「Aの重過失」が該当し、+20の修正が加算されます。
    B車の修正要素: 「Bの著しい過失」が該当し、-10の修正が加算されます。
    最終過失割合: A車の最終過失割合は20 + 20 + (-10) = 30となります。B車の最終過失割合は100 - 30 = 70となります。
    ■ 最終過失割合
    → A車：30
    → B車：70
    """

    #st.markdown(prompt)
    model5 = genai.GenerativeModel(model_name="gemini-1.5-pro-002",generation_config=generation_config, safety_settings=safety_settings,tools=functions.values(),)

    response = model5.generate_content(prompt)

    # 関数呼び出し
    def call_function(function_call, functions):
        function_name = function_call.name
        function_args = function_call.args
        return functions[function_name](**function_args)

    # 関数レスポンス群の生成
    function_responses = []
    for part in response.parts:
        # 関数の使用を選択したかどうかの確認
        if part.function_call:
            # 関数呼び出しの実行
            result = call_function(part.function_call, functions)

            # 関数レスポンスの生成
            function_response = glm.Part(function_response=glm.FunctionResponse(
                name=part.function_call.name, 
                response={"result": result}
            ))
            function_responses.append(function_response)


    # 会話履歴の作成
    messages = [
        {'role':'user',
        'parts': [prompt]},
        {'role':'model',
        'parts': response.candidates[0].content.parts},
        {'role':'user',
        'parts': function_responses}
    ]

    for content in messages:
        if 'parts' in content and not content['parts']:
            raise ValueError("content.parts must not be empty")

    # 質問応答
    response = model.generate_content(messages)

    print("-----------------------------------------------")
    print(response.text)
    fault_final=response.text
    #return fault_final
    # report_prompt = "Write few sentences about japan. and also specify which gemini pro model are u using to find the answer"
    # model6 = genai.GenerativeModel(model_name="gemini-1.5-pro-002",generation_config=generation_config, safety_settings=safety_settings)
    # report_ans = model6.generate_content(report_prompt)
    # print(report_ans)
    model6 = genai.GenerativeModel(model_name="gemini-1.5-pro-002",generation_config=generation_config, safety_settings=safety_settings)

    with open("report.txt", "r", encoding="utf-8") as file:
        query311 = file.read()
    t31 = query311.format(hanrei=hanrei, honsho=honsho)
    #print(t31)
            #t4 = """• Analyze the incident video and decribe the video in detail."""
    result_report = model6.generate_content(
    [t31, video_file2])  # 配列に画像とテキストを含めればOK
    print(result_report.text)
    accident_overview = f"""{result_report.text}を読み、{result_report.text}に記載されている事故の考えられる事故概要のみを表示する。
            注意：{result_report.text}に記載されている以外の詳細を指定しないでください。
                    適切な形式で表示する。*** 表示しない"""
    accident_overview1 = model6.generate_content(accident_overview)  
    #output2= f"<b style='font-size: 20px;'>事故概要</b>\n \n{accident_overview1.text}\n "
    print("**************Report Accident Overview****************")
    print(accident_overview1.text)
    accident_overview_answer = accident_overview1.text

    potential_cause= f"""{result_report.text}を読み、{result_report.text}に記載されている事故の考えられる原因の詳細のみを表示する。
    注意：{result_report.text}に記載されている以外の詳細を指定しないでください。
    適切な形式で表示する。*** 表示しない"""
    potential_cause1 = model6.generate_content(potential_cause)  # 配列に画像とテキストを含めればOK
    potential_cause_answer =  potential_cause1.text         
    print("**************Report Potential causes****************")
    print(potential_cause_answer)
    timestamp= f"""{result_report.text}を読み、{result_report.text}に記載されているタイムスタンプ付事故のシーケンスの詳細のみを表示する。
    注意：{result_report.text}に記載されている以外の詳細を指定しないでください。
    適切な形式で表示する。*** 表示しない"""
    print("*************Report Timestamp *****************")              
    timestamp1 = model.generate_content(timestamp)  
    timestamp_answer=timestamp1.text
    print(timestamp_answer)
    print("*************Report kihon_wariai *****************") 
    kihon_wariai_answer = kihon_wariai.text
    print(kihon_wariai_answer)
    print("*************Report_Final_fault_calculation *****************") 
    print(fault_final)
    return fault_final

if __name__ == '__main__':
     app.run(debug=True)
 