import os
import pandas as pd
import base64
import sys
import yaml
import streamlit as st
import json
from pathlib import Path
from yaml.loader import SafeLoader
import google.generativeai as genai
from vertexai.generative_models import GenerationConfig, GenerativeModel, Part

import google.ai.generativelanguage as glm
from pprint import pprint


# configのロード
with open(Path(__file__).parent.joinpath("config.yaml"), encoding="utf-8") as file:
    config = yaml.load(file, Loader=SafeLoader)

# API-KEYの設定
GOOGLE_API_KEY=config["gemini"]["api_key"]
genai.configure(api_key=GOOGLE_API_KEY)
GEMINI_MODEL=config["gemini"]["model"]

safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_NONE"
    }
]

response_schema1 = {
    "type": "string"
}

response_schema2 = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "判例番号": {
                "type": "string"
            },
            "事故内容": {
                "type": "string"
            },
            "A車": {
                "type": "string"
            },
            "B車": {
                "type": "string"
            },
            "理由": {
                "type": "string"
            },
        },
        "required": ["判例番号","事故内容", "A車", "B車", "理由"]
    }
}

response_schema3 = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "修正要素": {
                "type": "string"
            },
            "数値": {
                "type": "number"
            },
            "該当ありorなし": {
                "type": "boolean"
            },
            "該当理由": {
                "type": "string"
            },
            "秒数": {
                "type": "number"
            }
        },
        "required": ["修正要素","数値", "該当ありorなし", "該当理由", "秒数"]
    }
}


# Generation Config
generation_config= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
}

generation_config1= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema1
}

generation_config2= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema2
}

generation_config3= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema3
}

generation_config4= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema3
}


model = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config, safety_settings=safety_settings)
model1 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config1, safety_settings=safety_settings)
model2 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config2, safety_settings=safety_settings)
model3 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config3, safety_settings=safety_settings)
model4 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config4, safety_settings=safety_settings)


## videoアップロード
file_name = "交差点事故動画2.mp4"
video_file = genai.upload_file(path=file_name)

import time

# APIがファイルを受信したことを確認
while video_file.state.name == "PROCESSING":
    print('Waiting for video to be processed.')
    time.sleep(10)
    video_file = genai.get_file(video_file.name)

if video_file.state.name == "FAILED":
    raise ValueError(video_file.state.name)
print("Video processing complete:", video_file.uri)


## 1.動画から事故の大区分を確定するフェーズ

file_path = '序章.txt'

with open(file_path, 'r', encoding='utf-8') as file:
    josho = file.read()

josho_prompt=f"""あなたは事故の状況から、過失割合の修正要素が該当するかどうか判断する保険会社の担当者です。
まずは以下の「序章」の用語や考え方を覚えてください。
{josho}"""

history1 = [
{'role':'user','parts': [josho_prompt]},
{'role':'model','parts': ["理解しました"]},
]

text = """交通事故のドライブレコーダー動画が渡されます。
以下のどの状況に当てはまるか、もっとも近いものを1つだけ番号で回答してください。

1　歩行者と自動車orバイク
2　歩行者と自転車
3　自動車と自動車
4　バイクと自動車
5　自転車と自動車orバイク
6　高速道路上
7　駐車場内
0　該当なし


##回答例
3
"""

history1.append({'role':'user','parts':text})
history1.append({'role':'user', 'parts': [video_file]})

response = model1.generate_content(history1)

result1 = response.text
print(result1)
print("------------------------------------------------------")


## 2.判例タイムズ（過去事例）から判定番号を確定するフェーズ

# 大区分（result1）によってプロンプトを変更する
# 今回は3 車同士として
file_path = '3prompt.txt'
with open(file_path, 'r', encoding='utf-8') as file:
    prompt = file.read()

file_path = '本章序文.txt'
with open(file_path, 'r', encoding='utf-8') as file:
    honsho = file.read()
  
honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
{honsho}"""

history2 = [
{'role':'user','parts': [josho_prompt]},
{'role':'model','parts': ["理解しました"]},
{'role':'user','parts': [honsho_prompt]},
{'role':'model','parts': ["理解しました"]},
]

history2.append({'role':'user', 'parts': [video_file]})
history2.append({'role':'user','parts':prompt})


response = model.generate_content(history2)

result2 = response.text
print(result2)
#with open(f"output/{sys.argv[1]}_youyaku.txt", "w", encoding="utf-8") as f:
    #f.write(response.text)

# 目次一覧
file_path = '3hanrei.txt'

with open(file_path, 'r', encoding='utf-8') as file:
    hanrei = file.read()

query2 = f"""
以下の事故の状況から、与えられた交通事故判例の【】の判例番号がどれになるか３つ候補を挙げてください。
出力内容は"判例番号","事故内容", "A車", "B車","理由"です。
事故内容は区分の内容をすべて表示してください。
候補になった理由も教えてください。

事故の状況：
{result2}

交通事故判例一覧：
{hanrei}
"""

print("------------------------------------------------------")

result3 = model2.generate_content(query2).text
formatted_json = json.dumps(result3, ensure_ascii=False, indent=4)
pprint(json.loads(result3))

# with open(f"output/{sys.argv[1]}_hanrei.txt", "w", encoding="utf-8") as f:
#     f.write(result3)

print("------------------------------------------------------")


# 3.基本割合と修正要素を算出するフェーズ

# 
#hanrei_num = sys.argv[2]

file_path = '104-1.txt'
with open(file_path, 'r', encoding='utf-8') as file:
    hanrei = file.read()


# 基本割合を算出
hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。基本割合を数値も含めて出力してください。
{hanrei}"""

kihon_wariai = model.generate_content(hanrei_prompt)
print(kihon_wariai.text)

# 修正要素を算出
hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。修正要素と数値を1行ずつ数値も含めて出力してください。
{hanrei}"""

shusei_youso = model.generate_content(hanrei_prompt)
print(shusei_youso.text)


# 他の判例番号の内容を参照する場合
prompt = f"""
与えられた文章のみを利用して出力してください。
以下の修正要素に「参照」というワードが含まれている場合で、【】で囲まれている番号をすべて数値で表示してください。
()や（）で囲まれている番号は表示しないでください。
空白や改行や数字以外の文字は含めないでください。

修正要素：
{hanrei}

"""
response = model1.generate_content(prompt)
import json

file_names = json.loads(response.text)

# 各辞書から 'hanrei_num' の値を取得してリストにする
print(file_names)
# file_names = [item['hanrei_num'] for item in data]


# file_names_from_split = response.text.split(',')
# print(file_names_from_split)

hoka = ""

# 各ファイル名に対して処理を行う
for sansho in file_names:
    # ファイル名が空でない場合のみ処理を行う
    if sansho.strip():
        file_path = 'sansho.txt'
        
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                hoka_text = file.read()
            hoka = hoka + hoka_text
        except FileNotFoundError:
            print(f"File not found: {file_path}")


hanrei_prompt = f"""以下は「他の判例」の資料です。修正要素を算出する際に、参照が必要な場合に利用してください。
{hoka}"""


additional_car_b = "無免許運転"
additional_car_a = "飲酒運転"

# query3 = f"""
# 交通事故の動画と、動画以外の追加要素が渡されます。

# [出力内容]
# 以下に渡される[修正要素]の内容を1行ずつ、今回の交通事故に該当するか数値も含めて表示してください。
# 渡される[修正要素]以外の内容は表示しないでください。修正要素の数値は変更しないでください。
# 修正要素の内容は、過去の会話履歴の「本章序文」の用語を参考に判断してください。
# 修正要素が該当する場合「該当あり」として、その修正要素の内容と数値と算出理由を1行で教えてください。
# 算出理由となった内容が、動画の開始から何秒時点かも表示してください。
# 法定速度を超過している場合は、根拠となる情報も表示してください。
# 修正要素が「著しい過失」と「重過失」の両方に該当する場合は、「重過失」にしてください。
# 修正要素が該当しない場合「該当なし」として表示してください。

# 【】で囲まれた数字の判例番号の参照が必要な場合、過去の会話で与えられた「他の判例」を参照してください。

# 最終的な過失割合はここでは算出しないで、基本割合と修正要素と修正要素の理由だけを出力してください。

# [動画以外の追加要素]
# A車：{additional_car_a}
# B車：{additional_car_b}

# [修正要素]
# {shusei_youso}

# """


query3 = f"""
    交通事故の動画が渡されます。

    [出力内容]
    以下に渡される[修正要素]の内容を1行ずつ、今回の交通事故に該当するか数値も含めて表示してください。
    A車を青い車、B車を白い車とする。そして、それに応じて修正ファクターを更新する。
    渡される[修正要素]以外の内容は表示しないでください。修正要素の数値は変更しないでください。
    修正要素の内容は、過去の会話履歴の「本章序文」の用語を参考に判断してください。
    修正要素が該当する場合「該当あり」として、その修正要素の内容と数値と算出理由を1行で教えてください。
    算出理由となった内容が、動画の開始から何秒時点かも表示してください。
    法定速度を超過している場合は、根拠となる情報も表示してください。
    修正要素が該当しない場合「該当なし」として表示してください。


    【】で囲まれた数字の判例番号の参照が必要な場合、過去の会話で与えられた「他の判例」を参照してください。

    最終的な過失割合はここでは算出しないで、基本割合と修正要素と修正要素の理由だけを出力してください。

    [修正要素]
    {shusei_youso}
"""

history3 = [
{'role':'user','parts': [josho_prompt]},
{'role':'model','parts': ["理解しました"]},
{'role':'user','parts': [honsho_prompt]},
{'role':'model','parts': ["理解しました"]},
{'role':'user','parts': [hanrei_prompt]},
{'role':'model','parts': ["理解しました"]},
]

history3.append({'role':'user', 'parts': [video_file]})
history3.append({'role':'user','parts':query3})

result4 = model3.generate_content(history3).text
# Modified code
#result4 = model3.generate_content("\n".join([part['parts'][0] for part in history3])).text
print("************type of result4****************")
print(type(result4))
print(result4)

data1 = json.loads(result4)
df1 = pd.DataFrame(data1)
print(df1)
# 基本割合
#A20 : B80
st.title("ジェミニが生成したオリジナル結果(Original gemini generated result)")
st.table(df1)
#あり
# 修正要素

car_b_gross1="あり"
car_a_gross1="なし"
car_a_gross2="あり" 
car_b_gross2="なし"
car_b_gross3="あり"

user_input_display=f"""
Bの明らかな先入 - {car_b_gross1} \n
\n Aの著しい過失 - {car_a_gross1} \n
\n Aの重過失  - {car_a_gross2} \n
\n Bの著しい過失 - {car_b_gross2} \n
\n Bの重過失 - {car_b_gross3} """

st.markdown("ユーザ訂正")
st.markdown(user_input_display)
# user_input = f"""Bの明らかな先入 - {car_b_gross1}
# Aの著しい過失  -  {car_a_gross1}
# Aの重過失   -   {car_a_gross2}
# Bの著しい過失 - {car_b_gross2}
# Bの重過失 - {car_b_gross3}"""
import json
data = {
    "Bの明らかな先入": car_b_gross1,
    "Aの著しい過失": car_a_gross1,
    "Aの重過失": car_a_gross2,
    "Bの著しい過失": car_b_gross2,
    "Bの重過失": car_b_gross3
}
ユーザー確認 = json.dumps(data, ensure_ascii=False)
#ユーザー確認 = user_input.format(car_b_gross1="なし", car_a_gross1="なし", car_a_gross2="なし", car_b_gross2="あり", car_b_gross3="あり")
print("*********User prompt*************")
print (ユーザー確認)
query31 = f"""
    result4では、ユーザー確認に基づき該当ありまたは詳細情報を更新しています。
    該当ありorなし 変更については、ユーザー確認 以下を参照してください。

        修正要素
        {result4}
        ユーザー確認
        {ユーザー確認}
"""

history31 = [
{'role':'user','parts': [josho_prompt]},
{'role':'model','parts': ["理解しました"]},
{'role':'user','parts': [honsho_prompt]},
{'role':'model','parts': ["理解しました"]},
{'role':'user','parts': [hanrei_prompt]},
{'role':'model','parts': ["理解しました"]},
]
history31.append({'role':'user', 'parts': [video_file]})
history31.append({'role':'user','parts':query31})


result41 = model3.generate_content(history31).text
# Modified code
#result4 = model3.generate_content("\n".join([part['parts'][0] for part in history3])).text
print(result41)
data = json.loads(result41)
df = pd.DataFrame(data)
print(df)
st.title("ユーザー入力に基づいて詳細を更新(Updated details based on user input)")
st.table(df)
#4.過失割合を計算するフェーズ

def calculate_fault_ratio(base_a: int, base_b: int, factors_a: list[int], factors_b: list[int]) -> (int, int):
    """ 与えられた基本割合と修正要素から、交通事故過失割合を算出する 
    base_a:Aの基本割合
    base_b:Bの基本割合
    factors_a:Aの修正要素（配列）
    factors_b:Bの修正要素（配列）
    """
    
    # Aの基本割合を基準にして修正要素を加減
    adjusted_a = base_a + sum(factors_a) + sum(factors_b)
    
    # 過失割合の最大を100とする
    if adjusted_a > 100:
        adjusted_a = 100

    # 過失割合の最小を0とする
    if adjusted_a < 0:
        adjusted_a = 0
    
    
    # 最終的に100からAの値を減算した値がBの過失割合になる
    fault_ratio_a = adjusted_a
    fault_ratio_b = 100 - fault_ratio_a
    
    return fault_ratio_a, fault_ratio_b

functions = {
    "calculate_fault_ratio": calculate_fault_ratio,
}


  
# prompt = f"""与えられた基本割合と修正要素から、交通事故過失割合を算出してレポートを作成してください。最終的な過失割合の計算は必ず関数を使用してください。修正要素が渡されない場合は、修正要素は0として算出してください。

# #基本割合
# {kihon_wariai}

# #修正要素
# {result41}

# #レポート例
# ＜基本割合＞　A車15　B車85

# ＜修正要素＞
# A車の著しい過失 10　
# B車の著しい過失 -5

# ＜過失割合計算＞（以下の内容を具体的に数値で記載。計算式は記載しない。）
# # Aの基本割合を基準にして修正要素を加減（Bの修正要素もAに加減する、Aのみ記載）
# # 過失割合の最小を0、最大を100とする（Aのみ記載）
# # 最終的に100からAの値を減算した値がBの過失割合になる

# 最終的な過失割合は A車20 B車80になります。

#"""
# prompt = f"""与えられた基本割合と修正要素から、交通事故過失割合を算出してください。修正要素が渡されない場合は、修正要素は0として算出してください。
#                          故障率計算の詳細とステップごとの計算を示してください。
#                 #基本割合
#                 {kihon_wariai}

#                 #修正要素
#                 {result41}
#                 """
prompt = f"""与えられた基本割合と修正要素から、交通事故過失割合を算出してレポートを作成してください。最終的な過失割合の計算は必ず関数を使用してください。修正要素が渡されない場合は、修正要素は0として算出してください。
修正要素の「著しい過失」と「重過失」の両方も該当する場合は、「重過失」だけを考慮する。
#基本割合
{kihon_wariai}
#修正要素
{result41}
##計算方法
修正要素の「著しい過失」と「重過失」の両方も該当する場合は、「重過失」だけを考慮する。
A車　最終過失割合　＝　＜A車 基本割合＞　+ ＜A車 該当する全ての修正要素＞ + ＜B車 該当する全ての修正要素＞
# 過失割合の最小を0、最大を100とする（Aのみ計算）
B車　最終過失割合　＝　100 - ＜A車　最終過失割合＞
 
#以下の計算を正しく行い、各ステップを改行してください。

##出力テンプレート##
（以下の内容を実際のアウトプットに上書きする。車Aと車Bの間にいつも改行する）
■ 基本割合:
→ A車：〇〇
→ B車：〇〇
■ 該当の修正要素
→ A車：修正要素〇〇 数値〇〇　
→ B車：修正要素〇〇 数値〇〇
■ 過失割合計算
→ A車　最終過失割合 = 〇〇 + 〇〇 + 〇〇
→ B車　最終過失割合 = 100 - 〇〇
■　計算の説明
→　〇〇
 
■ 最終過失割合
→ A車：〇〇
→ B車：〇〇
 
#出力例
■ 基本割合:
→ A車：20
→ B車：80
■ 該当の修正要素
→ A車：Aの重過失 +20　
→ B車：Bの著しい過失 -10
■ 過失割合計算
→ A車　最終過失割合 30 = 20 + 20 + (-10)
→ B車　最終過失割合 70 = 100 - 30
 
■　計算の説明
A車の修正要素: 「Aの重過失」が該当し、+20の修正が加算されます。
B車の修正要素: 「Bの著しい過失」が該当し、-10の修正が加算されます。
最終過失割合: A車の最終過失割合は20 + 20 + (-10) = 30となります。B車の最終過失割合は100 - 30 = 70となります。
■ 最終過失割合
→ A車：30
→ B車：70
"""
model5 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config, safety_settings=safety_settings,tools=functions.values(),)

response = model5.generate_content(prompt)

# 関数呼び出し
def call_function(function_call, functions):
    function_name = function_call.name
    function_args = function_call.args
    return functions[function_name](**function_args)

# 関数レスポンス群の生成
function_responses = []
for part in response.parts:
    # 関数の使用を選択したかどうかの確認
    if part.function_call:
        # 関数呼び出しの実行
        result = call_function(part.function_call, functions)

        # 関数レスポンスの生成
        function_response = glm.Part(function_response=glm.FunctionResponse(
            name=part.function_call.name, 
            response={"result": result}
        ))
        function_responses.append(function_response)


# 会話履歴の作成
messages = [
    {'role':'user',
     'parts': [prompt]},
    {'role':'model',
     'parts': response.candidates[0].content.parts},
    {'role':'user',
     'parts': function_responses}
]


for content in messages:
    if 'parts' in content and not content['parts']:
        raise ValueError("content.parts must not be empty")

# 質問応答
response = model.generate_content(messages)

print("-----------------------------------------------")
print(response.text)
st.title("最終過失割合")
st.markdown(response.text)

# ファイルの削除
genai.delete_file(video_file.name)
