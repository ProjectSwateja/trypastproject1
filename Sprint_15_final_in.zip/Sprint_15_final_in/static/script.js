// Trigger file input when user clicks on the text or icon
document.getElementById('triggerInput').addEventListener('click', function () {
  document.getElementById('videoInput').click();
});

document.getElementById('triggerIcon').addEventListener('click', function () {
  document.getElementById('videoInput').click();
});

document
  .getElementById('videoInput')
  .addEventListener('change', function (event) {
    const file = event.target.files[0];
    const formData = new FormData();
    formData.append('videoInput', file);
    const videoPlayer = document.getElementById('videoPlayer');
    const scenarioButton = document.getElementById('actionButton');
    const loader = document.getElementById('loader');
    const selectScenarioButton = document.getElementById(
      'selectScenarioButton'
    );

    if (file && file.type.startsWith('video/')) {
      const fileURL = URL.createObjectURL(file);
      videoPlayer.src = fileURL;
      videoPlayer.style.display = 'block'; // Display video
      scenarioButton.style.display = 'block'; // Show button when video is displayed
      loader.style.display = 'block';
      selectScenarioButton.style.display = 'none';

      const formData = new FormData();
      formData.append('videoInput', file);

      fetch('/upload_video', {
        method: 'POST',
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          console.log(data);
          if (data.success) {
            console.log(data.column_6);
            // const responseElements = document.getElementById('responsevideo');
            populateScenarios(data.scenarios, data.dropdownOptions);
          }
        });
    }

    function populateScenarios(scenarios, dropdownOptions) {
      console.log(scenarios);
      const radioButtonsContainer = document.getElementById(
        'scenarioRadioButtons'
      );
      radioButtonsContainer.innerHTML = ''; // Clear previous buttons

      scenarios.forEach((scenario) => {
        const label = document.createElement('label');
        label.style.display = 'block'; // Ensure label is displayed vertically

        const radioButton = document.createElement('input');
        radioButton.type = 'radio';
        radioButton.name = 'scenario';
        radioButton.value = scenario['判例番号'];

        const description = document.createElement('div');
        description.innerHTML = ` 
            <p style="margin-left: 60px;">${scenario['区分５']}</p>
            ${
              scenario['区分６']
                ? `<p style="margin-left: 60px;">${scenario['区分６']}</p>`
                : ''
            }
            <p style="margin-left: 60px;"><strong>A車: </strong> ${
              scenario['A車']
            }</p>
            <p style="margin-left: 60px;"><strong>B車: </strong>${
              scenario['B車']
            }</p>
            <p> </p>
        `;

        const image = document.createElement('img');
        image.src = `/static/images/${radioButton.value}.png`;
        image.onerror = function () {
          image.src = `/static/images/dummy.png`;
        };
        image.style.width = '170px';
        image.style.marginTop = '10px';
        image.style.paddingLeft = '50px';
        image.style.marginBottom = '30px';
        image.style.marginLeft = '30px';

        label.appendChild(radioButton);
        label.appendChild(document.createTextNode(` ${scenario['判例番号']} `));
        label.appendChild(description); // Append the description div
        const imageContainer = document.createElement('div');
        imageContainer.style.clear = 'both';
        imageContainer.appendChild(image);
        label.appendChild(imageContainer);
        radioButtonsContainer.appendChild(label);
      });

      // Add the "Other" option
      const otherLabel = document.createElement('label');
      otherLabel.style.display = 'block';

      const otherOption = document.createElement('input');
      otherOption.type = 'radio';
      otherOption.name = 'scenario';
      otherOption.value = 'その他';
      otherOption.id = 'otherOption'; // Add an id for easier access later

      otherLabel.appendChild(otherOption);
      otherLabel.appendChild(document.createTextNode(' その他'));
      radioButtonsContainer.appendChild(otherLabel);

      // hide loader and show the button
      document.getElementById('loader').style.display = 'none';
      document.getElementById('selectScenarioButton').style.display = 'block';

      // Event listener to toggle dropdown visibility and populate it when "Other" is selected
      document.querySelectorAll('input[name="scenario"]').forEach((input) => {
        input.addEventListener('change', function () {
          const otherDropdown = document.getElementById('otherDropdown');
          if (this.value === 'その他') {
            otherDropdown.style.display = 'block';

            const dropdown = document.getElementById('scenarioDropdown');
            dropdown.innerHTML = ''; // Clear previous options

            // Create and append new <option> elements
            dropdownOptions.forEach((option) => {
              const optionElement = document.createElement('option');
              optionElement.value = option;
              optionElement.text = option;
              dropdown.appendChild(optionElement);
            });
          } else {
            otherDropdown.style.display = 'none';
          }
        });
      });
    }

    // Add event listener for the new button
    document
      .getElementById('selectScenarioButton')
      .addEventListener('click', function () {
        let selectedScenario;
        // Check for selected radio button
        const selectedRadio = document.querySelector(
          'input[name="scenario"]:checked'
        );
        if (selectedRadio) {
          selectedScenario = selectedRadio.value; // Get the value from the selected radio button
        } else {
          // Check for selected dropdown option
          const dropdown = document.getElementById('scenarioDropdown');
          selectedScenario = dropdown.value;
          // selectedScenario = document.getElementById('scenarioDropdown').value;
        }
        // Display success message
        const messageDisplay = document.getElementById(
          'selectedScenarioMessage'
        );
        if (selectedScenario) {
          if (selectedScenario === 'その他') {
            selectedScenario =
              document.getElementById('scenarioDropdown').value;
          }
          // messageDisplay.textContent = `シナリオ番号 ${selectedScenario} が選択されました`;
          // messageDisplay.style.display = 'block'; // Show the message
        } else {
          messageDisplay.textContent = 'Please select a scenario.';
          messageDisplay.style.display = 'block'; // Show the message
        }
        const tableLoader = document.getElementById('tableLoader');
        tableLoader.style.display = 'block';
        function newtable(tableData) {
          const tbody = document.querySelector('#resultTable tbody');
          tbody.innerHTML = '';
          const identification = document.getElementById('identification');
          identification.style.display = 'none';
          const basicFault = document.getElementById('basicFault');
          basicFault.style.display = 'none';
          const tableHead = document.getElementById('tableHead');
          tableHead.style.display = 'none';
          const resultTable = document.getElementById('resultTable');
          resultTable.style.display = 'none';

          tableData.forEach((row, index) => {
            const tr = document.createElement('tr');

            const tdText = document.createElement('td');
            tdText.textContent = row.text;
            tr.appendChild(tdText);

            const tdNumber = document.createElement('td');
            tdNumber.textContent = row.number;
            tr.appendChild(tdNumber);

            const tdDecision = document.createElement('td');
            tdDecision.textContent = row.decision;
            tr.appendChild(tdDecision);

            const tdTimerange = document.createElement('td');
            tdTimerange.textContent = row.timeRange;
            tr.appendChild(tdTimerange);

            const tdReason = document.createElement('td');
            tdReason.textContent = row.reason;
            tr.appendChild(tdReason);

            const tdAction = document.createElement('td');
            const yesRadio = document.createElement('input');
            yesRadio.type = 'radio';
            yesRadio.name = `action_${index}`;
            yesRadio.value = 'yes';

            const noRadio = document.createElement('input');
            noRadio.type = 'radio';
            noRadio.name = `action_${index}`;
            noRadio.value = 'no';
            noRadio.checked = true;

            const handleActionChange = (isYesSelected, commentInput) => {
              commentInput.disabled = !isYesSelected;
              commentInput.required = isYesSelected;
              if (!isYesSelected) {
                commentInput.value = '';
              }
            };

            yesRadio.addEventListener('change', () =>
              handleActionChange(true, inputComment)
            );

            noRadio.addEventListener('change', () =>
              handleActionChange(false, inputComment)
            );

            tdAction.appendChild(yesRadio);
            tdAction.appendChild(document.createTextNode(' Yes '));
            tdAction.appendChild(noRadio);
            tdAction.appendChild(document.createTextNode(' No '));
            tr.appendChild(tdAction);

            const tdComment = document.createElement('td');
            const inputComment = document.createElement('input');
            inputComment.type = 'text';
            inputComment.name = `comment_${index}`;
            inputComment.disabled = true;
            inputComment.required = false;

            tdComment.appendChild(inputComment);
            tr.appendChild(tdComment);

            tbody.appendChild(tr);
          });
          tableLoader.style.display = 'none';
          identification.style.display = 'block';
          basicFault.style.display = 'block';
          tableHead.style.display = 'block';
          resultTable.style.display = 'block';
          additionalModifiers.style.display = 'block';
          displaySelectedButton.style.display = 'block';
        }
        const formData = new FormData();
        formData.append('videoInput', file);
        fetch('/shusei_yousou', {
          method: 'POST',
          body: formData,
        })
          .then((response) => response.json())
          .then((data) => {
            console.log(data);
            newtable(data);
            const shuseiYousouDisplay = document.getElementById(
              'shuseiYousouDisplay'
            );
            // shuseiYousouDisplay.innerHTML = `<strong> Response Data: </strong></br>${data}`;
            shuseiYousouDisplay.style.display = 'block';
            console.log(data);
          });
        // 2nd table

        function enableDisableTextField(selectElement, textField) {
          if (selectElement.value === '0') {
            textField.disabled = true;
            textField.value = ''; // Clear the text field
            textField.required = false;
          } else {
            textField.disabled = false;
            textField.required = true;
            textField.focus();
          }
        }
        const additionalModifiers = document.getElementById(
          'additionalModifiers'
        );
        // additionalModifiers.style.display = 'block';
        const displaySelectedButton = document.getElementById(
          'displaySelectedButton'
        );

        const faultSelectA = document.getElementById('faultSelectA');
        const userReasonA = document.getElementById('userReasonA');
        const faultSelectB = document.getElementById('faultSelectB');
        const userReasonB = document.getElementById('userReasonB');
        faultSelectA.addEventListener('change', () =>
          enableDisableTextField(faultSelectA, userReasonA)
        );
        faultSelectB.addEventListener('change', () =>
          enableDisableTextField(faultSelectB, userReasonB)
        );
      });
    document
      .getElementById('displaySelectedButton')
      .addEventListener('click', function () {
        const finalfault = document.getElementById('finalfault');
        const tbody = document.querySelector('#resultTable tbody');
        const dataToSend = [];
        tbody.querySelectorAll('tr').forEach((row) => {
          const first_column = row.cells[0].textContent;
          const yesRadio = row.querySelector(
            'input[type="radio"][value="yes"]'
          );
          const actionSelected = yesRadio.checked ? 'Yes' : 'No';
          const numericvalueCell = row.cells[1];
          const reasonInput = row.querySelector('input[type="text"]');

          if (yesRadio.checked) {
            const numericvalue = numericvalueCell.textContent;
            const reason = reasonInput.value.trim();

            if (!reason) {
              alert('理由を述べてください。');
              return;
            }
            dataToSend.push({
              firstColumn: first_column,
              action: actionSelected,
            });
            // output += `<p>数値: ${numericvalue}, ユーザー根拠: ${reason}</p>`;
          }
        });
        // if (output) {
        //   displayDiv.innerHTML = `<strong>User Given Modifiers: </strong>${output}`;
        // } else {
        //   displayDiv.innerHTML = `<p> Nothing to display !!</p>`;
        // }
        formData.append('data', JSON.stringify(dataToSend));

        fetch('/process_data', {
          method: 'POST',
          body: formData,
        })
          .then((response) => response.text())
          .then((data) => {
            console.log('Response:', data);
            finalfault.innerHTML = `<p><strong> 過失割合: </strong></br>${data}</p>`;
            finalfault.style.display = 'block';
          });
        // const faultSelectAValue = faultSelectA.value;
        // const userReasonAValue = userReasonA.value || 'なし';

        // const faultSelectBValue = faultSelectB.value;
        // const userReasonBValue = userReasonB.value || 'なし';
        // finalfault.style.display = 'block';
      });
    // const additionalModifiers = document.getElement('additionalModifiers');
    // additionalModifiers.style.display = 'block';

    document
      .getElementById('actionButton')
      .addEventListener('click', function () {
        document.getElementById('radioBlock').style.display = 'block';
      });
  });
