// Trigger file input when user clicks on the text or icon
document.getElementById('triggerInput').addEventListener('click', function () {
  document.getElementById('videoInput').click();
});

document.getElementById('triggerIcon').addEventListener('click', function () {
  document.getElementById('videoInput').click();
});

document
  .getElementById('videoInput')
  .addEventListener('change', function (event) {
    const file = event.target.files[0];
    const videoPlayer = document.getElementById('videoPlayer');
    const scenarioButton = document.getElementById('actionButton');

    if (file && file.type.startsWith('video/')) {
      const fileURL = URL.createObjectURL(file);
      videoPlayer.src = fileURL;
      videoPlayer.style.display = 'block'; // Display video
      scenarioButton.style.display = 'block'; // Show button when video is displayed

      const formData = new FormData();
      formData.append('videoInput', file);

      fetch('/upload_video', {
        method: 'POST',
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            populateScenarios(data.scenarios, data.dropdownOptions);
          }
        });
    }
  });

function populateScenarios(scenarios, dropdownOptions) {
  const radioButtonsContainer = document.getElementById('scenarioRadioButtons');
  radioButtonsContainer.innerHTML = ''; // Clear previous buttons

  scenarios.forEach((scenario) => {
    const label = document.createElement('label');
    label.style.display = 'block'; // Ensure label is displayed vertically

    const radioButton = document.createElement('input');
    radioButton.type = 'radio';
    radioButton.name = 'scenario';
    radioButton.value = scenario.num;

    const image = document.createElement('img');
    image.src = `/static/images/${scenario.num}.png`;
    image.style.width = '100px';
    image.style.marginLeft = '10px';

    label.appendChild(radioButton);
    label.appendChild(
      document.createTextNode(` [${scenario.num}] ${scenario.desc}`)
    );
    label.appendChild(image);

    radioButtonsContainer.appendChild(label);
  });

  // Add the "Other" option
  const otherLabel = document.createElement('label');
  otherLabel.style.display = 'block';

  const otherOption = document.createElement('input');
  otherOption.type = 'radio';
  otherOption.name = 'scenario';
  otherOption.value = 'その他';
  otherOption.id = 'otherOption'; // Add an id for easier access later

  otherLabel.appendChild(otherOption);
  otherLabel.appendChild(document.createTextNode(' その他'));
  radioButtonsContainer.appendChild(otherLabel);

  // Event listener to toggle dropdown visibility and populate it when "Other" is selected
  document.querySelectorAll('input[name="scenario"]').forEach((input) => {
    input.addEventListener('change', function () {
      const otherDropdown = document.getElementById('otherDropdown');
      if (this.value === 'その他') {
        otherDropdown.style.display = 'block';

        const dropdown = document.getElementById('scenarioDropdown');
        dropdown.innerHTML = ''; // Clear previous options

        // Create and append new <option> elements
        dropdownOptions.forEach((option) => {
          const optionElement = document.createElement('option');
          optionElement.value = option;
          optionElement.text = option;
          dropdown.appendChild(optionElement);
        });
      } else {
        otherDropdown.style.display = 'none';
      }
    });
  });
}

// Add event listener for the new button
document
  .getElementById('selectScenarioButton')
  .addEventListener('click', function () {
    let selectedScenario;

    // Check for selected radio button
    const selectedRadio = document.querySelector(
      'input[name="scenario"]:checked'
    );
    if (selectedRadio) {
      selectedScenario = selectedRadio.value; // Get the value from the selected radio button
    } else {
      // Check for selected dropdown option
      const dropdown = document.getElementById('scenarioDropdown');
      selectedScenario = dropdown.value;
      // selectedScenario = document.getElementById('scenarioDropdown').value;
    }

    // Display success message
    const messageDisplay = document.getElementById('selectedScenarioMessage');
    if (selectedScenario) {
      if (selectedScenario === 'その他') {
        selectedScenario = document.getElementById('scenarioDropdown').value;
      }
      messageDisplay.textContent = `シナリオ番号 ${selectedScenario} が選択されました`;
      messageDisplay.style.display = 'block'; // Show the message
    } else {
      messageDisplay.textContent = 'Please select a scenario.';
      messageDisplay.style.display = 'block'; // Show the message
    }
  });

document.getElementById('actionButton').addEventListener('click', function () {
  document.getElementById('radioBlock').style.display = 'block';
});

document.getElementById('generateBtn').addEventListener('click', async () => {

  const prompt = document.getElementById('prompt').value;

  const responseElement = document.getElementById('response');

  try {

      const response = await fetch('/api/generate', {

          method: 'POST',

          headers: {

              'Content-Type': 'application/json'

          },

          body: JSON.stringify({ prompt: prompt })

      });

      if (!response.ok) {

          throw new Error(`HTTP error! status: ${response.status}`);

      }

      const data = await response.json();

      responseElement.textContent = JSON.stringify(data, null, 2); 

  } catch (error) {

      responseElement.textContent = `Error: ${error.message}`;

  }

});

