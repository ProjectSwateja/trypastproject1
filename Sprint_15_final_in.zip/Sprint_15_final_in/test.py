from flask import Flask, request, jsonify
import os
import google.generativeai as genai
import yaml
from yaml.loader import SafeLoader
import json

app = Flask(__name__)

# Load config from YAML
with open("config.yaml", "r") as f:
    config = yaml.safe_load(f)

GOOGLE_API_KEY = config["gemini"]["api_key"]
GEMINI_MODEL = config["gemini"]["model"]
genai.configure(api_key=GOOGLE_API_KEY)

# ... (Your safety settings and generation configs from the original code,  
#       but make sure `response_mime_type` is "application/json" in all configs) ...


@app.route('/api/gemini', methods=['POST'])
def gemini_api():
    try:
        data = request.get_json()
        prompt = data.get('prompt')  # Get the prompt from the request

        # Choose the appropriate model and generation config based on the request
        # Example:  If data includes a 'model_type' key, use that to select the model
        model_type = data.get('model_type', 'default') # default model
        if model_type == 'model1':
            model = genai.GenerativeModel(model_name=GEMINI_MODEL, generation_config=generation_config1, safety_settings=safety_settings)
        elif model_type == 'model2':
            model = genai.GenerativeModel(model_name=GEMINI_MODEL, generation_config=generation_config2, safety_settings=safety_settings)
        # ... and so on for other models ...
        else:
            model = genai.GenerativeModel(model_name=GEMINI_MODEL, generation_config=generation_config, safety_settings=safety_settings)


        response = model.generate(prompt=prompt)
        return jsonify({'result': response[0]['text']})  # Return the response as JSON

    except Exception as e:
        return jsonify({'error': str(e)}), 500  # Handle errors gracefully

if __name__ == '__main__':
    app.run(debug=True)  # Set debug=False for production