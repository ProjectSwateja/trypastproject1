from flask import Flask, render_template, request, jsonify
import os
import pandas as pd
import requests
from dotenv import load_dotenv
import google.generativeai as genai
from google.generativeai.types import ContentType
from PIL import Image
from IPython.display import Markdown
import time
import cv2

GOOGLE_API_KEY = "AIzaSyDHerzbcFUHIZDbIULhZnd_09BzDVEOrsI"
genai.configure(api_key=GOOGLE_API_KEY)

model = genai.GenerativeModel('gemini-1.5-pro-001')


load_dotenv()
app = Flask(__name__)


UPLOAD_FOLDER = 'uploaded_video'
os.makedirs(UPLOAD_FOLDER, exist_ok = True)

GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')

GEMINI_MODEL = os.getenv('GEMINI_MODEL')

safety_settings = [

    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},

]

generation_config = {

    "temperature": 0,

    "top_k": 1,

    "max_output_tokens": 8192,

    "response_mime_type": "application/json",

}



@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload_video', methods = ['POST'])
def upload_video():
    video = request.files.get('videoInput')
    if video:
        video_path = os.path.join(UPLOAD_FOLDER, video.filename)
        video.save(video_path)
        # video.save(f'uploaded_videos/${video.filename}')

        #read csv file and extract the first column
    csv_path = r'C:\Users\253289\Documents\POC\GEMINI_POC\ALL\sprint_14\Gemini\Sprint_13\car_car.csv'
    df = pd.read_csv(csv_path)
    first_column_data = df.iloc[:, 0].tolist()

    #myfile = genai.upload_file(path=video_path)
    prompt = 'Describe the whole video'
    video_file = genai.upload_file(path="信号無し交差点の事故.mp4")
    # myfile = genai.upload_file(media / "信号無し交差点の事故.mp4")
    print(f"{video_file=}")

    # response = model.generate_content(
    #     [myfile, "\n\n", "Can you tell me about the instruments in this photo?"]
    # )
    # print(f"{result.text=}")

    response = model.generate_content([video_file, prompt],
                                  request_options={"timeout": 600})
    result = response.text
    return jsonify(result)

    scenarios = [{'num': '104-1', 'desc': '一方に一時停止の規制がある場合'},
                {'num': '104-2', 'desc': '一方に一時停止の規制がある場合'},
                {'num': '104-3', 'desc': '一方に一時停止の規制がある場合'}]
    return jsonify(success=True, scenarios=scenarios, dropdownOptions = first_column_data)

@app.route('/analyze_scenario', methods=['GET'])
def analyze_scenario():
    scenario_num = request.args.get('scenarioNum')

    result = f'Selected scenario {scenario_num}'
    return jsonify(result=result)

@app.route('/api/generate', methods=['POST'])


def generate_response():

    prompt = request.json.get('prompt')
    response = model.generate_content(prompt)
    result = response.text
    return jsonify(result)

   
    # try:

    #     response = model.generate_content(prompt)

    #     response.raise_for_status()  # Raise an error for bad responses

    #     return jsonify(response.json()), 200

    # except requests.exceptions.RequestException as e:

    #     return jsonify({"error": str(e)}), 500



# def generate_response():

#     prompt = request.json.get('prompt')
   
#     try:

#         response = requests.post(

#             '/upload_video',  
#             json={

#                 "model": GEMINI_MODEL,

#                 "prompt": prompt,

#                 "safety_settings": safety_settings,

#                 "generation_config": generation_config

#             },

#             headers={

#                 'Authorization': f'Bearer {GOOGLE_API_KEY}',

#                 'Content-Type': 'application/json'

#             }

#         )

#         response.raise_for_status()  # Raise an error for bad responses

#         return jsonify(response.json()), 200

#     except requests.exceptions.RequestException as e:

#         return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
     app.run(debug=True)
 