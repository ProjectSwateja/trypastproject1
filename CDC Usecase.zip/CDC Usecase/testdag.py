

from datetime import timedelta, datetime

from airflow import DAG
from airflow import models
from airflow.contrib.operators.dataflow_operator import DataflowTemplateOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.models import Variable
from airflow.contrib.operators import bigquery_get_data
from airflow.contrib.operators import bigquery_operator
from airflow.contrib.operators import bigquery_to_gcs
from airflow.operators import bash_operator
from airflow.operators import email_operator
from airflow.utils import trigger_rule

## Requires these variables to be setup on composer (airflow)

PROJECT = models.Variable.get('gcp_project')
TEMP_BUCKET = models.Variable.get('gcs_bucket')
ZONE = models.Variable.get("gce_zone")
REGION = models.Variable.get("gce_region")
EMAIL = models.Variable.get("email")
BQ_DATASET = models.Variable.get("dataset_id")

## Dataflow template to be used
## Update it according to your deployment region. Example: gs://dataflow-templates-us-central1/latest/Jdbc_to_BigQuery

TEMPLATE = 'gs://dataflow-templates-us-central1/latest/Jdbc_to_BigQuery'

### <CHANGEME> needs to be replaced by your own value

ENVIRONMENT = {
    "bypassTempDirValidation": "false",
    "maxWorkers": "20",
    "numWorkers": "1",
    "serviceAccountEmail": "<CHANGEME>",
    "tempLocation": "gs://<CHANGEME>",
    "ipConfiguration": "WORKER_IP_UNSPECIFIED",
    "additionalExperiments": [
    "sideinput_io_metrics"
    ]
}

PARAMETERS = {
    "connectionURL": "jdbc:sqlserver://127.0.0.1:1433;databaseName=cdcsourcedb;socketFactoryClass=com.google.cloud.sql.sqlserver.SocketFactory;socketFactoryConstructorArg=di-gcp-351221:us-central1:cdc-poc-sqlserver;user=sqlserver;password=root",
    "driverClassName": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
    "query": "SELECT * FROM `di-gcp-351221.cdc_poc_dataset.cdc_poc_test_table1` ",
    "outputTable":"di-gcp-351221.cdc_poc_dataset.cdc_poc_test_table1_staging",
    "driverJars": "gs://cdc-poc-bucket/cloud-sql-connector-jdbc-sqlserver-1.6.0-jar-with-driver-and-dependencies.jar",
    "bigQueryLoadingTemporaryDirectory": "gs://cdc-poc-bucket/temp",
    "username": "sql",
    "password": "root"
 }

TODAY = datetime.today()
TODAY_STRING = datetime.today().strftime('%Y%m%d')

DEFAULT_DAG_ARGS = {
    'owner': '<CHANGEME>',
    'depends_on_past': False,
    'start_date': TODAY,
    'email': EMAIL,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1),
    'schedule_interval': '@daily',
    'dataflow_default_options': {
               'project': PROJECT,
               'region': REGION,
               'zone': ZONE,
               'stagingLocation': TEMP_BUCKET
           }
}

dag = DAG(
    'CDC-DAG-v1',
    default_args=DEFAULT_DAG_ARGS,
    dagrun_timeout=timedelta(hours=3),
    schedule_interval='00 * * * *'
)

start = DummyOperator(task_id='Start', dag=dag)
end = DummyOperator(task_id='End', dag=dag)


bq_trunc_table1_staging = bigquery_operator.BigQueryOperator(
        task_id='bq_truncate_table1_staging',
        bql="""
        TRUNCATE TABLE 
          `{table}`
        """.format(table="di-gcp-351221.cdc_poc_dataset.cdc_poc_test_table1_staging"),
        use_legacy_sql=False,
        dag=dag)



start >> bq_trunc_table1_staging
