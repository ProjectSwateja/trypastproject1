import os
import base64
import sys
import yaml
from pathlib import Path
from yaml.loader import SafeLoader
import google.generativeai as genai
from PIL import Image
from vertexai.generative_models import GenerationConfig, GenerativeModel, Part
from google.generativeai import caching
import json
import warnings
import google.ai.generativelanguage as glm
import datetime
import cv2
import shutil
from pprint import pprint
from google.cloud import storage
import tempfile
import googleapiclient.discovery
from google.oauth2 import service_account
import io


# configのロード
with open(Path(__file__).parent.joinpath("../../config.yaml")) as file:
    config = yaml.load(file, Loader=SafeLoader)

# API-KEYの設定
GOOGLE_API_KEY=config["gemini"]["api_key"]
genai.configure(api_key=GOOGLE_API_KEY)
GEMINI_MODEL=config["gemini"]["model"]

response_schema1 = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "事故の場所": {
                "type": "boolean"
            },
            "事故の状況": {
                "type": "string"
            }
        },
        "required": ["事故の場所","事故の状況"]
    }
}

response_schema2 = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "信号機": {
                "type": "boolean"
            },
            "A車とB車の車線関係": {
                "type": "string"
            },
            "A車とB車の走行方向": {
                "type": "string"
            },
            "B車から見たA車の位置": {
                "type": "string"
            },
            "A車から見たB車の位置": {
                "type": "string"
            }
        },
        "required": ["信号機","A車とB車の車線関係", "A車とB車の走行方向", "B車から見たA車の位置", "A車から見たB車の位置"]
    }
}

response_schema3 = {
  "type": "array",
  "items": {
    "type": "object",
    "properties": {
      "事故の場所": {
        "type": "string"
      },
      "事故の状況": {
        "type": "string"
      },
      "A車": {
        "type": "object",
        "properties": {
          "車両の種類": {"type": "string"},
          "信号": {"type": "string"},
          "走行方向": {"type": "string"},
          "一方通行違反": {"type": "boolean"},
          "一方道路車両用信号赤色表示": {"type": "boolean"},
          "押しボタン式歩行者信号青色表示": {"type": "boolean"},
          "センターオーバー": {"type": "boolean"},
          "追い越し禁止": {"type": "boolean"},
          "進路変更": {"type": "boolean"},
          "転回運転": {"type": "string"},
          "道路交通法24条違反": {"type": "boolean"},
          "右折前挙動": {"type": "string"},
          "左折前挙動": {"type": "string"},
          "渋滞": {"type": "boolean"}
        },
        "required": [
          "車両の種類", "信号", "走行方向", "一方通行違反", "一方道路車両用信号赤色表示", 
          "押しボタン式歩行者信号青色表示", "センターオーバー", "追い越し禁止", "進路変更", 
          "転回運転", "道路交通法24条違反", "右折前挙動", "左折前挙動", "渋滞"
        ]
      },
      "B車": {
        "type": "object",
        "properties": {
          "車両の種類": {"type": "string"},
          "信号": {"type": "string"},
          "走行方向": {"type": "string"},
          "一方通行違反": {"type": "boolean"},
          "一方道路車両用信号赤色表示": {"type": "boolean"},
          "押しボタン式歩行者信号青色表示": {"type": "boolean"},
          "センターオーバー": {"type": "boolean"},
          "追い越し禁止": {"type": "boolean"},
          "進路変更": {"type": "boolean"},
          "転回運転": {"type": "string"},
          "道路交通法24条違反": {"type": "boolean"},
          "右折前挙動": {"type": "string"},
          "左折前挙動": {"type": "string"},
          "渋滞": {"type": "boolean"}
        },
        "required": [
          "車両の種類", "信号", "走行方向", "一方通行違反", "一方道路車両用信号赤色表示", 
          "押しボタン式歩行者信号青色表示", "センターオーバー", "追い越し禁止", "進路変更", 
          "転回運転", "道路交通法24条違反", "右折前挙動", "左折前挙動", "渋滞"
        ]
      }
    },
    "required": ["事故の場所", "事故の状況", "A車", "B車"]
  }
}



safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_NONE"
    }
]

generation_config1= {
"temperature": 0,  # 生成するテキストのランダム性を制御
#"top_p": 1,          # 生成に使用するトークンの累積確率を制御
"top_k": 1,          # 生成に使用するトップkトークンを制御
"max_output_tokens": 8192,  # 最大出力トークン数を指定`
"response_mime_type": "application/json",
"response_schema": response_schema1
}

generation_config2= {
"temperature": 0,  # 生成するテキストのランダム性を制御
#"top_p": 1,          # 生成に使用するトークンの累積確率を制御
"top_k": 1,          # 生成に使用するトップkトークンを制御
"max_output_tokens": 8192,  # 最大出力トークン数を指定`
"response_mime_type": "application/json",
"response_schema": response_schema2
}

generation_config3= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema3
}

BUCKET_NAME = "firstbucket-storage-1"
KEY_FILE_PATH = "./storagefile.json"

FRAME_EXTRACTION_DIRECTORY = "frames/"
FRAME_PREFIX = "_frame"

#画像ファイルをコンテキストキャッシュにアップロード
def context_cache(accident_id):
    # サービスアカウントの認証情報を作成
    credentials = service_account.Credentials.from_service_account_file(KEY_FILE_PATH)
    client = googleapiclient.discovery.build("storage", "v1", credentials=credentials, cache_discovery=False)

    # フォルダパスを指定
    folder_path = f"{accident_id}/frames/"

    # 画像ファイルを格納する辞書
    image_files_dict = {}

    # GCS内のフォルダリストを取得
    req = client.objects().list(bucket=BUCKET_NAME, prefix=folder_path)
    while req is not None:
        response = req.execute()

        if "items" in response:
            for item in response["items"]:
                # ファイル名を取得
                file_name = item["name"].split("/")[-1]  # フォルダ階層を除いたファイル名
                if file_name:  # ファイル名が空でない場合
                    # ファイルを一時的にダウンロードして辞書に格納
                    req_media = client.objects().get_media(bucket=BUCKET_NAME, object=item["name"])
                    file_data = io.BytesIO()
                    downloader = googleapiclient.http.MediaIoBaseDownload(file_data, req_media)

                    done = False
                    while not done:
                        _, done = downloader.next_chunk()

                    image_files_dict[file_name] = file_data.getvalue()

        # 次のページがある場合のリクエストを取得
        req = client.objects().list_next(previous_request=req, previous_response=response)

    FRAME_EXTRACTION_DIRECTORY = "frames/"
    FRAME_PREFIX = "_frame"

    # Fileクラスの定義
    class File:
        def __init__(self, file_path: str, display_name: str = None):
            self.file_path = file_path
            if display_name:
                self.display_name = display_name
            self.timestamp = get_timestamp(file_path)

        def set_file_response(self, response):
            self.response = response

    # timestampの取得
    def get_timestamp(filename):
        parts = filename.split(FRAME_PREFIX)
        if len(parts) != 2:
            return None
        return parts[1].split('.')[0]


    # ファイルのアップロード
    uploaded_files = []
    for file_name, file_data in image_files_dict.items():
        # 一時ファイルとして保存
        with tempfile.NamedTemporaryFile(delete=False, suffix=f"_{file_name}") as temp_file:
            temp_file.write(file_data)
            temp_file_path = temp_file.name  # 一時ファイルのパスを取得
        
        try:
            # 一時ファイルをアップロード
            response = genai.upload_file(temp_file_path)  # 一時ファイルパスを渡す
            uploaded_files.append(response.name)
            print(f"Uploaded {file_name} as {file_name}")
        except Exception as e:
            print(f"Error uploading {file_name}: {e}")
        finally:
            # アップロード後に一時ファイルを削除
            os.remove(temp_file_path)

    # キャッシュを作成
    cachetime = config["gemini"]["cachetime"]

    cache = caching.CachedContent.create(
        model=GEMINI_MODEL,
        display_name=accident_id,
        system_instruction="交通事故のドライブレコーダー動画のスライスされた画像に基づいて回答する役割を持っています。",
        contents=uploaded_files,
        ttl=datetime.timedelta(cachetime),
    )

    return cache

def process_gemini_step2(step2_json):

    accident_id = step2_json["accident_id"]

    cached_contents = caching.CachedContent.list()

    cache_flg = 0

    for content in cached_contents:
        print(content)
        # content.display_nameとaccident_idを比較
        if content.display_name == accident_id:
            cache = content
            cache_flg = 1


    if cache_flg == 0:
        cache = context_cache(accident_id)


    # 作成したキャッシュを使用する
    model = genai.GenerativeModel.from_cached_content(cached_content=cache,generation_config=generation_config1, safety_settings=safety_settings)
    model2 = genai.GenerativeModel.from_cached_content(cached_content=cache,generation_config=generation_config2, safety_settings=safety_settings)
    model3 = genai.GenerativeModel.from_cached_content(cached_content=cache,generation_config=generation_config3, safety_settings=safety_settings)

    prompt = """
    交通事故のドライブレコーダー動画が渡されます。
    ドライブレコーダーを搭載している車をA車、事故の相手をB車として、事実のみ箇条書きで教えてください。

    ＜車同士がぶつかった場所の状況を記載すること＞
    ・事故の場所：交差点（十字路）、Ｔ字路（丁字路）、直線
    ・事故の状況：直進車と直進車、右折車と直進車、左折車と直進車、右折車同士、左折車と直進車

    判断する順番は以下の通りです。
    １．衝突が起きた場所の道路の状況を確認
    ２．ドライブレコーダーを搭載している車の動きを確認
    ３．衝突した相手の車の動きを確認
    ４．道路標識が存在するか
    ５．道路標示が存在するか

    ・十字路交差点(四つ角、交差道路)
        - 4つの道路がほぼ同じ角度で交わっているため、道路の接続数も確認すること
        - 2本の道路がほぼ直角に交わる十字の形をしているため、道路の形状も確認すること
        - 交差点クロスマークが交差点にある場合は十字路交差点と判断すること
        - 他車両が反対車線や対向車線を走っている場合、道路が見え辛い可能性もあるので、より正確な形状を確認すること
        - 丁字路(T字路)のように見える箇所もあるので、より正確な形状を確認し、十字路を判断すること

    ・丁字路(T字路)交差点
        - 3つの道路がT字型に交わっているため、道路の接続数と形状も確認すること
        - 交差点Tマークが交差点にある場合は丁字路(T字路)交差点と判断すること
        - 十字路のように見える箇所もあるので、より正確な形状を確認し、丁字路(T字路)を判断すること
        - A車とB車がともに丁字路(T字路)交差点の直進路を走行している場合は直線道路(曲線道路も含む)を選択すること

    ・直線道路(曲線道路も含む)
        - 他道路との交わりはないため、道路の接続数と形状も確認すること
        - 信号はないため、街灯を信号機と間違えないようにすること
        - 丁字路(T字路)のように見える箇所もあるので、より正確な形状を確認し、直線道路を判断すること
        - 十字路のように見える箇所もあるので、より正確な形状を確認し、直線道路を判断すること
        - A車とB車がともに丁字路(T字路)交差点の直進路を走行している場合は直線道路(曲線道路も含む)を選択すること

    ・道路外入出
        - A車とB車の片方が道路外から侵入、もしくは道路外に退出する
        - 信号はないため、街灯を信号機と間違えないようにすること
        - 道路と道路外の境界には車道外側線があることが多いため、それを正確に確認して、道路外を判断すること
    """

    request = []
    request.append(prompt)


    history2 = []
    history2.append({'role':'user', 'parts': request})

    # 推論の実行
    response = model.generate_content(
        history2
    )
    print(response.text) 

    history2.append({'role':'model','parts': response.text})

    prompt2 = """
    続いて、以下の内容を答えてください。

    ・信号機（ありorなし）
    ・A車とB車の車線関係
    ・A車とB車の走行方向
    ・B車から見たA車の位置
    ・A車から見たB車の位置

    """

    request2 = []
    request2.append(prompt2)


    history2.append({'role':'user', 'parts': request2})

    # 推論の実行
    response2 = model2.generate_content(
        history2
    )
    print(response2.text) 

    history2.append({'role':'model', 'parts': response2.text})

    prompt3 = """
    続いて、以下の内容を答えてください。
    A車、B車それぞれの状況を出力すること。

    ・車両の種類 : 小型車
                    大型車
                    緊急車両(緊急車両の場合は、小型車、大型車に関わらず緊急車両と回答すること)
                    不明

    ・信号:     青
                黄
                赤
                青矢印
                なし
                不明

    ・走行方向 : 直進
                    右折
                    左折
                    転回
                    駐停車
                    不明

    ・走行状況 : 交差道路を直進
                    交差道路を右折
                    交差道路を左折
                    丁字路(T字路)交差点の直進路直進
                    丁字路(T字路)交差点の直進路右折
                    丁字路(T字路)交差点の突き当たり路右折
                    丁字路(T字路)交差点の突き当たり路左折
                    道路外から道路に侵入
                    道路から道路外へ出る
                    転回
                    駐停車
                    不明

        ・一方通行違反 : あり
                        なし
                        不明

        ・一方道路車両用信号赤色表示 : あり
                                        なし
                                        不明

        ・押しボタン式歩行者信号青色表示 : あり

                                        なし
                                        不明

        ・センターオーバー : あり
                            なし
                            不明

        ・追い越し禁止 : あり
                        なし
                        不明

        ・進路変更 : あり
                    なし
                    不明

        ・転回運転 : 転回中
                    転回終了時
                    なし
                    不明

        ・道路交通法24条違反 : あり
                                なし
                                不明

        ・右折前挙動 : 予め中央によっている
                        予め中央によっていない
                        右折していない
                        十字路交差点ではない
                        同一車線ではない
                        不明

        ・左折前挙動 : 予め左側端によっている
                        予め左側端によっていない
                        左折していない
                        十字路交差点ではない
                        同一車線ではない
                        不明

        ・渋滞 : あり
                なし

    """

    request3 = []
    request3.append(prompt3)


    history2.append({'role':'user', 'parts': request3})

    # 推論の実行
    response3 = model3.generate_content(
        history2
    )

    print(response3.text)

    return response3.text
    

process_gemini_step2({"accident_id":"101_001"})