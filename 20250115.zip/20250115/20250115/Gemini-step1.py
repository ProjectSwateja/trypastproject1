import os
import base64
import sys
import yaml
from pathlib import Path
from yaml.loader import SafeLoader
import google.generativeai as genai
from PIL import Image
from vertexai.generative_models import GenerationConfig, GenerativeModel, Part
import json
import warnings
import cv2
import shutil
import tempfile
import googleapiclient.discovery
from google.cloud import storage
from google.oauth2 import service_account
import io

# configのロード
with open(Path(__file__).parent.joinpath("config.yaml"), encoding="utf-8") as file:
    config = yaml.load(file, Loader=SafeLoader)

# API-KEYの設定
GOOGLE_API_KEY=config["gemini"]["api_key"]
genai.configure(api_key=GOOGLE_API_KEY)
GEMINI_MODEL=config["gemini"]["model"]


# Generation Config
config = {
"max_output_tokens": 8192,
"temperature": 0,
"top_p": 1
}



safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_NONE"
    }
]

# Generation Config
generation_config= {
"temperature": 0,  # 生成するテキストのランダム性を制御
#"top_p": 1,        # 生成に使用するトークンの累積確率を制御
"top_k": 1,        # 生成に使用するトップkトークンを制御
"max_output_tokens": 8192,  # 最大出力トークン数を指定`
}

# GCSに保存する処理
BUCKET_NAME = "firstbucket-storage-1"
KEY_FILE_PATH = "storagefile.json"


# モデルの準備
model = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config, safety_settings=safety_settings)

def read_video_files_from_gcs_to_variable(bucket_name, cred_file_path, remote_file_path):
    """
    GCSフォルダ内の動画ファイルを読み込み、変数に保管する関数
    """
    # サービスアカウント認証
    credentials = service_account.Credentials.from_service_account_file(cred_file_path)
    client = googleapiclient.discovery.build("storage", "v1", credentials=credentials, cache_discovery=False)

    # GCSオブジェクトを取得
    req = client.objects().get_media(bucket=bucket_name, object=remote_file_path)

    # 一時ファイルを作成してバイナリデータを書き込み
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".mp4")
    downloader = googleapiclient.http.MediaIoBaseDownload(temp_file, req)
    done = False
    while not done:
        status, done = downloader.next_chunk()
        print(f"Download progress: {int(status.progress() * 100)}%")

    print(f"Video file downloaded successfully to temporary file: {temp_file.name}")
        
    # OpenCVで動画を処理
    vidcap = cv2.VideoCapture(temp_file.name)
    if not vidcap.isOpened():
        raise Exception("Failed to open video file.")

    return vidcap




def upload_file_to_bucket(bucket_name, cred_file_path, local_file_path, remote_file_path):
    """

    """
    # サービスアカウントからクライアントの初期化
    credentials = service_account.Credentials.from_service_account_file(cred_file_path)
    client = googleapiclient.discovery.build("storage", "v1", credentials=credentials, cache_discovery=False)

    # ファイルをバイナリモードで読み込む
    with open(local_file_path, "rb") as file:
        file_content_bytes = file.read()

    # Create media object for upload
    media_body = googleapiclient.http.MediaIoBaseUpload(
        io.BytesIO(file_content_bytes),
        mimetype="image/jpeg",  # jpegのMIMEタイプ
        chunksize=1024 * 1024,  # チャンクサイズを設定
        resumable=True
    )

    # バケットにアップロード
    req = client.objects().insert(bucket=bucket_name, name=remote_file_path, media_body=media_body)
    res = req.execute()

    print(f"Uploaded  to gs:///")


# 動画からのフレーム抽出
def extract_frame_from_video(vidcap, output_dir,accident_id):

    fps_slice = 1
    
    # フォルダの準備
    FRAME_EXTRACTION_DIRECTORY = "frames/"
    FRAME_PREFIX = "_frame"

    # create_frame_output_dir(FRAME_EXTRACTION_DIRECTORY)
    fps = vidcap.get(cv2.CAP_PROP_FPS)
    frame_duration = 1 / fps  # フレーム間の時間間隔 (秒単位)
    output_file_prefix = os.path.basename(accident_id).replace('.', '_')
    frame_count = 0
    count = 0
    
    while vidcap.isOpened():
        success, frame = vidcap.read()
        if not success:  # 動画が終了した場合
            break
        
        # 毎秒2フレームの間隔でフレームを保存
        if count % int(fps // fps_slice) == 0:  # FPSの半分の間隔でフレームを抽出
            min = frame_count // (fps_slice * 60)  # 
            sec = (frame_count // fps_slice) % 60  # 秒単位の計算
            msec = count % int(fps // fps_slice)  # フレームが同じ秒内で重複しないようにフレームのインデックスを追加
            time_string = f"{min:02d}:{sec:02d}_{frame_count:03d}"  # フレームカウントを追加して重複を防止
            
            image_name = f".jpg"
            
            # 一時ファイルとして保存
            with tempfile.NamedTemporaryFile(delete=False, suffix=".jpg") as temp_file:
                remote_file_path = f"frames/{accident_id}/{time_string}{image_name}"
                temp_filename = temp_file.name
                cv2.imwrite(temp_filename, frame)  # フレームを一時ファイルに保存

            # GCSにアップロード
            upload_file_to_bucket(BUCKET_NAME, KEY_FILE_PATH, temp_filename, remote_file_path)


            frame_count += 1
        
        count += 1
    
    vidcap.release()  # VideoCaptureオブジェクトを解放

def process_gemini_step1(step1_json):

    FILE_PATH = f"{step1_json['accident_id']}/video/{step1_json['accident_id']}.mp4"  # 読み込むフォルダ

    # GCSフォルダ内の動画ファイルを変数に保管
    vidcap = read_video_files_from_gcs_to_variable(BUCKET_NAME, KEY_FILE_PATH,FILE_PATH)

    # 1秒間の画像スライス枚数
    fps_slice = 1

    accident_id = step1_json['accident_id']

    output_dir = f"frames/{step1_json['accident_id']}"
    # 動画からのフレーム抽出の実行
    extract_frame_from_video(vidcap,output_dir,accident_id)



    # Fileクラスの定義
    class File:
        def __init__(self, file_path: str, display_name: str = None):
            self.file_path = file_path
            if display_name:
                self.display_name = display_name
            self.timestamp = get_timestamp(file_path)

        def set_file_response(self, response):
            self.response = response

    return step1_json
def get_timestamp(file_path):
        return "timestamp"
process_gemini_step1({"accident_id":"101_002"})