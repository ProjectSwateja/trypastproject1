
from flask import Flask, render_template, request, jsonify
import os
import google.ai.generativelanguage as glm
import pandas as pd
import requests
from dotenv import load_dotenv
import google.generativeai as genai
from google.generativeai.types import ContentType
from PIL import Image
from IPython.display import Markdown
import time
import cv2
import json
from pathlib import Path
import yaml
from yaml.loader import SafeLoader

load_dotenv()

UPLOAD_FOLDER = 'uploaded_video'
os.makedirs(UPLOAD_FOLDER, exist_ok = True)
# configのロード
with open(Path(__file__).parent.joinpath("config2.yaml"), encoding="utf-8") as file:
    config = yaml.load(file, Loader=SafeLoader)

app = Flask(__name__)

# API-KEYの設定
GOOGLE_API_KEY=config["gemini"]["api_key"]
genai.configure(api_key=GOOGLE_API_KEY)
GEMINI_MODEL=config["gemini"]["model"]

safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_NONE"
    }
]

response_schema1 = {
    "type": "string"
}

response_schema2 = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "判例番号": {
                "type": "string"
            },
            "事故内容": {
                "type": "string"
            },
            "A車": {
                "type": "string"
            },
            "B車": {
                "type": "string"
            },
            "理由": {
                "type": "string"
            },
        },
        "required": ["判例番号","事故内容", "A車", "B車", "理由"]
    }
}

response_schema3 = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "修正要素": {
                "type": "string"
            },
            "数値": {
                "type": "number"
            },
            "該当ありorなし": {
                "type": "boolean"
            },
            "該当理由": {
                "type": "string"
            },
            "秒数": {
                "type": "number"
            }
        },
        "required": ["修正要素","数値", "該当ありorなし", "該当理由", "秒数"]
    }
}


# Generation Config
generation_config= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
}

generation_config1= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema1
}

generation_config2= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema2
}

generation_config3= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema3
}

generation_config4= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema3
}

model = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config, safety_settings=safety_settings)
model1 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config1, safety_settings=safety_settings)
model2 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config2, safety_settings=safety_settings)
model3 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config3, safety_settings=safety_settings)
model4 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config4, safety_settings=safety_settings)

# GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')

# GEMINI_MODEL = os.getenv('GEMINI_MODEL')

safety_settings = [

    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},

]

generation_config = {

    "temperature": 0.2,

    "top_k": 1,

    "max_output_tokens": 8192,

    #"response_mime_type": "application/json",

}

@app.route('/')
def index():
    return render_template('index.html')

#Some Globally in code required files
file_path = '序章.txt'
with open(file_path, 'r', encoding='utf-8') as file:
    josho = file.read()
			
file_path = '本章序文.txt'
with open(file_path, 'r', encoding='utf-8') as file:
    honsho = file.read()
			
file_path = '104-1.txt'
with open(file_path, 'r', encoding='utf-8') as file:
    hanrei = file.read()

# 基本割合を算出
hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。基本割合を数値も含めて出力してください。
    {hanrei}"""

kihon_wariai = model.generate_content(hanrei_prompt)
    #print(kihon_wariai.text)

# 修正要素を算出
hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。修正要素と数値を1行ずつ数値も含めて出力してください。
{hanrei}"""
shusei_youso = model.generate_content(hanrei_prompt)
    #print(shusei_youso.text)

@app.route('/upload_video', methods = ['POST'])
def upload_video():
    video = request.files.get('videoInput')
    if video:
        video_path = os.path.join(UPLOAD_FOLDER, video.filename)
        video.save(video_path)
        video_file = genai.upload_file(path='JP_Video1-2-1_車対車（一時停止）_104_short.mp4')
        time.sleep(12)
        with open(f"josho_prompt.txt", 'r', encoding='utf-8') as file:
            josho_prompt1 = file.read()
            josho_prompt= josho_prompt1.format(josho=josho)

        history1 = [
        {'role':'user','parts': [josho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        ]

        text = """交通事故のドライブレコーダー動画が渡されます。
        以下のどの状況に当てはまるか、もっとも近いものを1つだけ番号で回答してください。

            1　歩行者と自動車orバイク
            2　歩行者と自転車
            3　自動車と自動車
            4　バイクと自動車
            5　自転車と自動車orバイク
            6　高速道路上
            7　駐車場内
            0　該当なし


        ##回答例
            3
        """
        history1.append({'role':'user','parts':text})
        history1.append({'role':'user', 'parts': [video_file]})
        response = model1.generate_content(history1)
        result1 = response.text
        print(result1)
        print("------------------------------------------------------")

        # Step2: CarA CArB Details じこしゃ の しょうさい
        file_path = '事故車の詳細.txt'
        with open(file_path, 'r', encoding='utf-8') as file:
            prompt = file.read()
        
        honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
        {honsho}"""

        history2 = [
        {'role':'user','parts': [josho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        {'role':'user','parts': [honsho_prompt]},
        {'role':'model','parts': ["理解しました"]},
        ]

        history2.append({'role':'user','parts':prompt})
        history2.append({'role':'user', 'parts': [video_file]})
        response = model.generate_content(history2)
        result2 = response.text
        print(result2)
        
        #Scenario Selection

        #Step3: Finding 3 matching scenarios
        #3シナリオ.txt Prompt file
        file_path = 'car_car.csv'

        with open(file_path, 'r', encoding='utf-8') as file:
            hanrei = file.read()

        with open(f"3シナリオ.txt", 'r', encoding='utf-8') as file:
            scenario3 = file.read()
            query2= scenario3.format(result2=result2, hanrei=hanrei)
            scenarios = model2.generate_content(query2).text
            print(scenarios)
            csv_path = 'car_car.csv'
            df = pd.read_csv(csv_path)
            first_column_data = df.iloc[:, 0].tolist()
            # return scenarios
            # return scenarios 
            return jsonify(success=True, scenarios=scenarios, dropdownOptions = first_column_data)

@app.route('/analyze_scenario', methods=['GET'])
def analyze_scenario():
    scenario_num = request.args.get('scenarioNum')

    result = f'Selected scenario {scenario_num}'
    return jsonify(result=result)


@app.route('/shusei_yousou', methods=['POST'])
def shusei_yousou():
    video = request.files.get('videoInput')
    if video:
        video_path = os.path.join(UPLOAD_FOLDER, video.filename)
        video.save(video_path)
     
        video_file2 = genai.upload_file(path=video_path)
        time.sleep(10)
    prompt = f"""
    与えられた文章のみを利用して出力してください。
    以下の修正要素に「参照」というワードが含まれている場合で、【】で囲まれている番号をすべて数値で表示してください。
    ()や（）で囲まれている番号は表示しないでください。
    空白や改行や数字以外の文字は含めないでください。

    修正要素：
    {hanrei}

    """
    response = model1.generate_content(prompt)
    file_names = json.loads(response.text)
    # 各辞書から 'hanrei_num' の値を取得してリストにする
    #print(file_names)


    hoka = ""

    # 各ファイル名に対して処理を行う
    for sansho in file_names:
        # ファイル名が空でない場合のみ処理を行う
        if sansho.strip():
            file_path = 'sansho.txt'
            
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    hoka_text = file.read()
                hoka = hoka + hoka_text
            except FileNotFoundError:
                print(f"File not found: {file_path}")


    hanrei_prompt = f"""以下は「他の判例」の資料です。修正要素を算出する際に、参照が必要な場合に利用してください。
    {hoka}"""

    josho_prompt=f"""あなたは事故の状況から、過失割合の修正要素が該当するかどうか判断する保険会社の担当者です。
    まずは以下の「序章」の用語や考え方を覚えてください。
    {josho}"""
    
    honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
    {honsho}"""

    query3 = f"""
        交通事故の動画が渡されます。

        [出力内容]
        以下に渡される[修正要素]の内容を1行ずつ、今回の交通事故に該当するか数値も含めて表示してください。
        A車を青い車、B車を白い車とする。そして、それに応じて修正ファクターを更新する。
        渡される[修正要素]以外の内容は表示しないでください。修正要素の数値は変更しないでください。
        修正要素の内容は、過去の会話履歴の「本章序文」の用語を参考に判断してください。
        修正要素が該当する場合「該当あり」として、その修正要素の内容と数値と算出理由を1行で教えてください。
        算出理由となった内容が、動画の開始から何秒時点かも表示してください。
        法定速度を超過している場合は、根拠となる情報も表示してください。
        修正要素が該当しない場合「該当なし」として表示してください。


        【】で囲まれた数字の判例番号の参照が必要な場合、過去の会話で与えられた「他の判例」を参照してください。

        最終的な過失割合はここでは算出しないで、基本割合と修正要素と修正要素の理由だけを出力してください。

        [修正要素]
        {shusei_youso}
    """

    history3 = [
    {'role':'user','parts': [josho_prompt]},
    {'role':'model','parts': ["理解しました"]},
    {'role':'user','parts': [honsho_prompt]},
    {'role':'model','parts': ["理解しました"]},
    {'role':'user','parts': [hanrei_prompt]},
    {'role':'model','parts': ["理解しました"]},
    ]
    history3.append({'role':'user', 'parts': [video_file2]})
    history3.append({'role':'user','parts':query3})
    result4 = model3.generate_content(history3).text
    # print(result4)
    data1 = json.loads(result4)
    df1 = pd.DataFrame(data1)
    print("**********Shyuseiyouso method gemini modifier******************")
    print(df1)
    return result4


@app.route('/process_data', methods = ['POST'])
def process_data():
    #response = request.get_json()
    video = request.files.get('videoInput')
    response = request.form.get('data')
    response = json.loads(response)
    data = shusei_yousou()
    data = json.loads(data)
    result41=data

#     default_response = [
#         {'firstColumn': 'Bの明らかな先入', 'action': 'False'}, 
#         {'firstColumn': 'Aの著しい過失', 'action': 'False'},
#         {'firstColumn': 'Aの重過失', 'action': 'False'},
#         {'firstColumn': 'Bの著しい過失', 'action': 'False'},
#         {'firstColumn': 'Bの重過失', 'action': 'False'}
#         ]

#     for item in response: 
#         if item['action'] == 'Yes': item['action'] = True
#     print(response)
#     print("********User data and gemini data recived************")

#     for res in response:
#         for default_res in default_response:
#             if res['firstColumn'] == default_res['firstColumn']:
#                 default_res['action'] = res['action']

#     print(default_response)

#     for d in data:
#         for dr in default_response:
#             if d["修正要素"] == dr["firstColumn"]:
#                 d["該当ありorなし"] = dr["action"]
#             #d["該当理由"] = r["action"]

# #print(data)
    
#     data1 = json.dumps(data)
#     data2 = json.loads(data1)
#     df = pd.DataFrame(data2)
#     print("************Process data method updated modifier*****************")
#     print(df)
    #response = request.form['data']
    # response1 = request.form['videoInput']
    #print("User modified on UI:", data)
    #print("***********outer function called*******")
    #result4 = shusei_yousou()

    #result41=data2
    print("************fault prompt modifier***********")
    print(result41)
    file_path = '序章.txt'
    with open(file_path, 'r', encoding='utf-8') as file:
        josho = file.read()

    josho_prompt=f"""あなたは事故の状況から、過失割合の修正要素が該当するかどうか判断する保険会社の担当者です。
    まずは以下の「序章」の用語や考え方を覚えてください。
    {josho}"""

    # file_path = '本章序文.txt'
    # with open(file_path, 'r', encoding='utf-8') as file:
    #     honsho = file.read()
    
    honsho_prompt=f"""以下の「本章序文」の用語を覚えてください。
    {honsho}"""

    # 修正要素を算出
    #hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。修正要素と数値を1行ずつ数値も含めて出力してください。
    #{hanrei}"""

    def calculate_fault_ratio(base_a: int, base_b: int, factors_a: list[int], factors_b: list[int]) -> (int, int):
        """ 与えられた基本割合と修正要素から、交通事故過失割合を算出する 
        base_a:Aの基本割合
        base_b:Bの基本割合
        factors_a:Aの修正要素（配列）
        factors_b:Bの修正要素（配列）
        """
        
        # Aの基本割合を基準にして修正要素を加減
        adjusted_a = base_a + sum(factors_a) + sum(factors_b)
        
        # 過失割合の最大を100とする
        if adjusted_a > 100:
            adjusted_a = 100

        # 過失割合の最小を0とする
        if adjusted_a < 0:
            adjusted_a = 0
        
        
        # 最終的に100からAの値を減算した値がBの過失割合になる
        fault_ratio_a = adjusted_a
        fault_ratio_b = 100 - fault_ratio_a
        
        return fault_ratio_a, fault_ratio_b

    functions = {
        "calculate_fault_ratio": calculate_fault_ratio,
    }

    prompt = f"""与えられた基本割合と修正要素から、交通事故過失割合を算出してレポートを作成してください。最終的な過失割合の計算は必ず関数を使用してください。修正要素が渡されない場合は、修正要素は0として算出してください。
    修正要素の「著しい過失」と「重過失」の両方も該当する場合は、「重過失」だけを考慮する。
    #基本割合
    {kihon_wariai}
    #修正要素
    {result41}
    ##計算方法
    修正要素の「著しい過失」と「重過失」の両方も該当する場合は、「重過失」だけを考慮する。
    A車　最終過失割合　＝　＜A車 基本割合＞　+ ＜A車 該当する全ての修正要素＞ + ＜B車 該当する全ての修正要素＞
    # 過失割合の最小を0、最大を100とする（Aのみ計算）
    B車　最終過失割合　＝　100 - ＜A車　最終過失割合＞
    
    #以下の計算を正しく行い、各ステップを改行してください。

    ##出力テンプレート##
    （以下の内容を実際のアウトプットに上書きする。車Aと車Bの間にいつも改行する）
    ■ 基本割合:
    → A車：〇〇
    → B車：〇〇
    ■ 該当の修正要素
    → A車：修正要素〇〇 数値〇〇　
    → B車：修正要素〇〇 数値〇〇
    ■ 過失割合計算
    → A車　最終過失割合 = 〇〇 + 〇〇 + 〇〇
    → B車　最終過失割合 = 100 - 〇〇
    ■　計算の説明
    →　〇〇
    
    ■ 最終過失割合
    → A車：〇〇
    → B車：〇〇
    
    """

    #st.markdown(prompt)
    model5 = genai.GenerativeModel(model_name="gemini-1.5-pro-002",generation_config=generation_config, safety_settings=safety_settings,tools=functions.values(),)

    response = model5.generate_content(prompt)

    # 関数呼び出し
    def call_function(function_call, functions):
        function_name = function_call.name
        function_args = function_call.args
        return functions[function_name](**function_args)

    # 関数レスポンス群の生成
    function_responses = []
    for part in response.parts:
        # 関数の使用を選択したかどうかの確認
        if part.function_call:
            # 関数呼び出しの実行
            result = call_function(part.function_call, functions)

            # 関数レスポンスの生成
            function_response = glm.Part(function_response=glm.FunctionResponse(
                name=part.function_call.name, 
                response={"result": result}
            ))
            function_responses.append(function_response)


    # 会話履歴の作成
    messages = [
        {'role':'user',
        'parts': [prompt]},
        {'role':'model',
        'parts': response.candidates[0].content.parts},
        {'role':'user',
        'parts': function_responses}
    ]

    for content in messages:
        if 'parts' in content and not content['parts']:
            raise ValueError("content.parts must not be empty")

    # 質問応答
    response = model.generate_content(messages)

    print("-----------------------------------------------")
    print(response.text)
    fault_fimal=response.text
    #return fault_final
    return jsonify(data)


if __name__ == '__main__':
     app.run(debug=True)
 