
import os
import zipfile
from googleapiclient.discovery import build
from google.oauth2 import service_account
from google.api_core.exceptions import NotFound
import pathlib
import platform

def get_download_folder():

    system = platform.system()

    if system == "Windows":
       # Option 1: Try environment variables (most reliable)
        downloads_path = os.path.join(os.environ.get("USERPROFILE"), "Downloads")
        if os.path.exists(downloads_path):
            return downloads_path

        # Option 2: Use CSIDL for older Windows versions
        try:
            import ctypes.wintypes
            CSIDL_DOWNLOADS = 0x0016  #CSIDL_DOWNLOADS  is not defined in older windows
            buf = ctypes.create_unicode_buffer(ctypes.wintypes.MAX_PATH)
            ctypes.windll.shell32.SHGetFolderPathW(None, CSIDL_DOWNLOADS, None, 0, buf)
            if os.path.exists(buf.value):
                 return buf.value
        except:
            return None # not available
    elif system == "Darwin":  # macOS
        downloads_path = os.path.join(os.path.expanduser("~"), "Downloads")
        if os.path.exists(downloads_path):
            return downloads_path
        
    elif system == "Linux":
        # Option 1: Environment variables
        downloads_path = os.environ.get("XDG_DOWNLOAD_DIR")
        if downloads_path and os.path.exists(downloads_path):
            return downloads_path
         
        # Option 2: Home directory, fallback 
        downloads_path = os.path.join(os.path.expanduser("~"), "Downloads")
        if os.path.exists(downloads_path):
            return downloads_path
           
    return None # Could not determine path


def download_gcs_folder_as_zip(
    bucket_name, folder_path, local_zip_path, credentials_path
):
    """Downloads an entire folder from GCS as a zip file
    using googleapiclient.discovery.
    """
    
    folder_path = str(folder_path) + "/processed_images/"
    
    try:
        creds = service_account.Credentials.from_service_account_file(
            credentials_path
        )
        service = build("storage", "v1", credentials=creds)


        # List objects in the specified folder
        objects = (
            service.objects()
            .list(bucket=bucket_name, prefix=folder_path)
            .execute()
        )

        if "items" not in objects:
            print(f"No files found in '{folder_path}'.")
            return

        with zipfile.ZipFile(local_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for item in objects["items"]:
                file_name = item["name"]

                if file_name == folder_path: # Skip the folder path itself
                    continue

                try:
                    print(f"Downloading: {file_name} ...")
                    request = service.objects().get_media(bucket=bucket_name, object=file_name)
                    response = request.execute()
                    
                    # Write to Zip
                    zipf.writestr(file_name.replace(folder_path, ''), response) # Use a relative path inside the zip
                    print(f"Added to ZIP: {file_name}")


                except NotFound:
                    print(f"Not found in bucket: {file_name}")
                except Exception as e:
                    print(f"Error downloading {file_name}: {e}")
        print(f"Zip file created at: {local_zip_path}")

    except Exception as e:
        print(f"An error occurred: {e}")


# if __name__ == "__main__":
#     BUCKET_NAME = "firstbucket-storage-2" # replace with your bucket name
#     CREDENTIALS_PATH = r"C:\Users\253289\Documents\POC\Gemini_project\sprint_21\Sprint20-v1-db-23 2\Sprint20-v1-db-23\storagefile.json" # replace with path to key file
#     FOLDER_PATH = "1003"  # replace with the folder name you want to download
#     local_download = get_download_folder()
    
#     LOCAL_ZIP_PATH = local_download + str(FOLDER_PATH) + ".zip" # replace with where you want to download the files.

#     download_gcs_folder_as_zip(BUCKET_NAME, FOLDER_PATH, LOCAL_ZIP_PATH, CREDENTIALS_PATH)