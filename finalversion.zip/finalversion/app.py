from flask import Flask, render_template, request, jsonify, send_from_directory, session,send_file
import google.ai.generativelanguage as glm
import json
import re
import os
import tempfile
import pandas as pd
import requests
import google.generativeai as genai
from google.generativeai.types import ContentType
from PIL import Image
from IPython.display import Markdown
import time
import cv2
import json
from pathlib import Path
import yaml
from yaml.loader import SafeLoader
import ast
import re
import numpy as np
import psycopg2
from googleapiclient.discovery import build
from google.oauth2 import service_account
from google.auth.transport.requests import Request
import io
from dotenv import load_dotenv
import googleapiclient.discovery
import google.auth
from google.oauth2 import service_account
import os
from delete_video_folder import *
from copyvideo import *
from Gemini_step1 import *
from Gemini_step2 import *
from Gemini_step3 import *
from Gemini_step4 import *
from Gemini_step5 import *
from download_images import *
from download_video import *

#from google.generativeai.client import GenerativeModel
# For downloading Imaged as zip
#Database Credentials
DB_HOST = "35.189.144.22"  # Replace with your instance's public IP
DB_NAME = "accident-data-db"
DB_USER = "postgres"
DB_PASSWORD  = "gemini123"
DB_PORT = 5432  # Default PostgreSQL port
cred_file_path = "storagefile.json"
bucket_name = "firstbucket-storage-2"
load_dotenv()
app = Flask(__name__)
app.secret_key = 'my_secret_key' # Replace with a strong random secret key, env variable is recommended
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
# os.makedirs(UPLOAD_FOLDER, exist_ok = True)
# configのロード
with open(Path(__file__).parent.joinpath("config.yaml"), encoding="utf-8") as file:
    config = yaml.load(file, Loader=SafeLoader)
# API-KEYの設定
GOOGLE_API_KEY=config["gemini"]["api_key"]
genai.configure(api_key=GOOGLE_API_KEY)
GEMINI_MODEL=config["gemini"]["model"]

safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_NONE"
    }
]
 
response_schema3 = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "修正要素": {
                "type": "string"
            },
            "数値": {
                "type": "number"
            },
            "該当ありorなし": {
                "type": "boolean"
            },
            "該当理由": {
                "type": "string"
            },
            "秒数": {
                "type": "number"
            }
        },
        "required": ["修正要素","数値", "該当ありorなし"]
    }
}

# Generation Config
generation_config= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
}
response_schema1 = {
    "type": "string"
}
generation_config1= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema1
}

generation_config2= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
#   "response_schema": response_schema2
}

generation_config3= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema3
}

generation_config4= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema3
}

model = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config, safety_settings=safety_settings)
model1 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config1, safety_settings=safety_settings)
model2 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config2, safety_settings=safety_settings)
model3 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config3, safety_settings=safety_settings)
model4 = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config4, safety_settings=safety_settings)


GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')

GEMINI_MODEL = os.getenv('GEMINI_MODEL')

safety_settings = [

    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},

    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},

]

generation_config = {

    "temperature": 0.2,

    "top_k": 1,

    "max_output_tokens": 8192,

    #"response_mime_type": "application/json",

}

@app.route('/')
def index():
    return render_template('index.html')

def load_from_table():
    data = []
    conn = None  # Initialize outside try
    cur = None # Initialize outside try
    try:
        # Establish a connection to the PostgreSQL database
        conn = psycopg2.connect(
            host=DB_HOST,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            port=DB_PORT
        )

        cur = conn.cursor()

        # Define the SQL SELECT statement
        sql = "SELECT * FROM accident_list ;"

        # Execute the SQL SELECT statement
        cur.execute(sql)

        # Fetch all rows from the result
        rows = cur.fetchall()

        # Store the result into a list
        data = [row for row in rows]

    except psycopg2.Error as e:
        print(f"Error loading data: {e}")
    
    finally:
      # Ensure the database connection is closed (cleanup)
        if cur:
          cur.close()
        if conn:
            conn.close()
    return data

def append_to_table(row):
    conn = None  # Initialize conn to None
    cur = None  # Initialize cur to None

    try:
        # Establish a connection to the PostgreSQL database
        conn = psycopg2.connect(
            host=DB_HOST,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            port=DB_PORT
        )
        cur = conn.cursor()

        # Define the SQL INSERT statement
        sql = """
            INSERT INTO accident_list(事故番号, 事故日, 契約者名, 登録番号, 事故動画, 加工, ビデオファイル)
            VALUES (%s, %s, %s, %s, %s, %s, %s);
        """

        # Execute the SQL INSERT statement with the provided row data
        cur.execute(sql, row)

        # Commit the transaction to save the changes to the database
        conn.commit()
        print("Data inserted successfully.")
        #return jsonify({'status': 'success'})  # Correct spelling of success
        return 0

    except psycopg2.IntegrityError as e:
        print("Duplicated ID")
        return 1
        #return jsonify({'status': 'error', 'message': 'Duplicate record: Record for this Id already exists!'})

    except psycopg2.Error as e:
        print(f"Error inserting data: {e}") # Log the actual exception
        return 1
        #return jsonify({'status': 'error', 'message': f'Database Error: {str(e)}'}) # Return error message

    finally:
        # Ensure the database connection is closed (cleanup)
        if cur:
            cur.close()
        if conn:
            conn.close()

@app.route('/add', methods=['POST'])
def add_data():
    
    data = request.get_json()
    accident_number = data['accidentNumber']
    
    new_row = [
            data['accidentNumber'],
            data['dateOfAccident'],
            data['name'],
            data['registrationNumber'],
            'なし',
            '未',
            '',
    ]
    append_status = append_to_table(new_row)
    if (append_status == 1):
        return jsonify({'status': 'Error'})
    else:
        accident_no = str(accident_number)       
        base_folder = f"{accident_no}/"
        original_video_folder = f"{base_folder}OriginalVideo/"
        processed_video_folder = f"{base_folder}processed_video/"
        processed_images_folder = f"{base_folder}processed_images/"
        folder_paths = [
                original_video_folder,
                processed_video_folder,
                processed_images_folder
        ]
        credentials = service_account.Credentials.from_service_account_file(cred_file_path)
        client = googleapiclient.discovery.build("storage", "v1", credentials=credentials, cache_discovery=False)
        for folder_path in folder_paths:
                    # Insert empty object to create a folder (GCS uses object paths for folders)
            media_body = googleapiclient.http.MediaIoBaseUpload(
                    io.BytesIO(b""),  # Empty content
                    mimetype="application/octet-stream",
                    chunksize=1024 * 1024,
                    resumable=True
                )
            req = client.objects().insert(bucket=bucket_name, name=folder_path, media_body=media_body)
            req.execute()
            print(f"Created folder: {folder_path}")

        return jsonify({'status': 'success'})
@app.route('/upload', methods=['POST'])
def upload(): 

    credentials = service_account.Credentials.from_service_account_file(cred_file_path)
    client = googleapiclient.discovery.build("storage", "v1", credentials=credentials, cache_discovery=False)
    accident_number = request.form['accidentNumber']
    session['accident_number'] = accident_number
    file = request.files['file']
    if not file:
        return jsonify({'status': 'error', 'message': 'No file provided'})
    # Use tempfile.gettempdir() to get the OS-specific temp directory path
    temp_dir = tempfile.gettempdir()
    temp_local_file = os.path.join(temp_dir, file.filename)
    gcs_file_path = f"{accident_number}/OriginalVideo/{accident_number}.mp4"

    try:
        # Save to temporary file. Moved here inside the try block
        file.save(temp_local_file)
        # Upload to GCS
        media_body = googleapiclient.http.MediaFileUpload(
            temp_local_file,
            mimetype="video/mp4",
            chunksize=1024 * 1024,
            resumable=True
        )
        req = client.objects().insert(bucket=bucket_name, name=gcs_file_path, media_body=media_body)
        res = req.execute()
        gcs_path = f"gs://{bucket_name}/{gcs_file_path}"
        session['gcp_path'] = gcs_path
        print (gcs_path)
        print("Uploaded file")
        video_path_url = gcs_path
   
        if video_path_url:
        
                # 1. Initialize Google Cloud Storage service using googleapiclient.discovery
            creds = None
            if 'GOOGLE_APPLICATION_CREDENTIALS' in os.environ:
                creds = service_account.Credentials.from_service_account_file(
                    os.environ['GOOGLE_APPLICATION_CREDENTIALS']
                )
            else:
                creds = service_account.Credentials.from_service_account_file(cred_file_path) # Replace with path to your service account

                # Build the storage service
            storage_service = build('storage', 'v1', credentials=creds)

                # 2. Download video from Google Cloud Storage
            blob_path = video_path_url.replace(f"gs://{bucket_name}/", "")

                # Download the file as a bytes object
            req = storage_service.objects().get_media(bucket=bucket_name, object=blob_path)
            response = req.execute()
                # Create a temporary local file to store the video
            temp_video_path = f"temp_{blob_path.replace('/', '_')}"
            with open(temp_video_path, 'wb') as f:
                f.write(response)

            print(f"Video downloaded to: {temp_video_path}")

        return jsonify({'status': 'success', 'filename': file.filename, 'filepath': gcs_path})

    except Exception as e:
        print(f"Error during GCS upload: {e}")
        return jsonify({'status': 'error', 'message': f'Error during GCS upload: {e}'})
        
    finally:
        # Clean up temporary file
        print("clean memory")
        #os.remove(temp_local_file)


def updatedatabase(accident_number):
    gcs_path = session['gcp_path']
    conn = psycopg2.connect(
            host=DB_HOST,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            port=DB_PORT
        )

    cur = conn.cursor()
    cur.execute(
            "UPDATE accident_list SET ビデオファイル = %s, 事故動画 = %s WHERE 事故番号 = %s",
            (gcs_path, 'あり', accident_number), # Assuming accident_number is same as id in database
    )
    conn.commit()

@app.route('/update_status', methods=['POST'])
def update_preprocessing_status(accident_number):
    try:
        #data = request.json
        #accident_number= data['accidentNumber']
        
        conn = psycopg2.connect(
            host=DB_HOST,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            port=DB_PORT
        )
        cur = conn.cursor()
        cur.execute(
            "UPDATE accident_list SET 加工 = %s WHERE 事故番号 = %s",
            ('済', accident_number), # Assuming accident_number is same as id in database
        )
        conn.commit()
        result = cur.fetchone()

        if result:
            processing_status = result[0]
            return jsonify({'status':'succes', 'preprocessingStatus': processing_status})
        else:
            return({'status': 'error', 'message': 'No data found'})
    except Exception as e:
        print(f"Error fetchingstatus:{e}")
        return jsonify({'status': 'error', 'message': 'Error'})

#Frames creation and process status update
@app.route('/gemini_step1', methods=['POST'])
def gemini_step1():
    accident_number = session['accident_number']
    updatedatabase(accident_number)
    source_bucket_name = bucket_name
    source_object_name = f"{accident_number}/OriginalVideo/{accident_number}.mp4"
    destination_bucket_name = bucket_name
    destination_object_name = f"{accident_number}/processed_video/{accident_number}.mp4"
    credentials_path = cred_file_path
    copy_video_in_gcs(source_bucket_name,source_object_name,destination_bucket_name,destination_object_name,credentials_path)
    process_gemini_step1({"accident_id":accident_number})
    #print('accident no from step 1')
    ############################################################
    #Save video to different bucket
    public_bucket_name = "video-preview-public"
    processed_source_path = f"{accident_number}/processed_video/{accident_number}.mp4"
    public_object_name = f"{accident_number}/{accident_number}.mp4"
    copy_video_in_gcs(source_bucket_name,processed_source_path,public_bucket_name,public_object_name,credentials_path)

    
    ############################################################
    update_preprocessing_status(accident_number)
    return jsonify({'status': 'success'})

@app.route('/uploads/<path:filename>')
def serve_uploads(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/delete', methods = ['POST'])
def delete_row():
    data = request.get_json()
    if not data or 'accidentNumber' not in data:
      return jsonify({'status': 'error', 'message': 'Invalid request, missing accidentNumber'})

    accident_number = data['accidentNumber']

    conn = None # Initialise outside try block
    cur = None # Initialise outside try block
    try:
        # Establish a connection to the PostgreSQL database
        conn = psycopg2.connect(
            host=DB_HOST,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            port=DB_PORT
        )
        cur = conn.cursor()
        # Define the SQL DELETE statement
        sql = "DELETE FROM accident_list WHERE 事故番号 = %s;"

        # Execute the SQL DELETE statement with the provided accident number
        cur.execute(sql, (accident_number,))

        # Commit the transaction to save the changes to the database
        conn.commit()

        folder_name = accident_number

        delete_folder_in_gcs(bucket_name, folder_name, cred_file_path)
        #Adding delete funcctionality for the public bucket as well.
        public_bucket_name='video-preview-public'
        delete_folder_in_gcs(public_bucket_name, folder_name, cred_file_path)

        if cur.rowcount == 0:
          return jsonify({'status': 'error', 'message': 'Accident Number not found'})
        print("Data deleted successfully.")

        return jsonify({'status': 'success', 'message': 'Accident record deleted'})

    except psycopg2.Error as e:
        print(f"Error deleting data: {e}")
        return jsonify({'status': 'error', 'message': f"Database error: {e}"})

    finally:
        # Ensure the database connection is closed (cleanup)
        if cur:
          cur.close()
        if conn:
          conn.close()

# video_path_url = None
@app.route('/process/<accident_number>')
def process(accident_number):
    # load data from csv
    data = load_from_table()
    accident_data = next((row for row in data if row[0] == accident_number), None)
    data = []
    conn = None  # Initialize outside try
    cur = None # Initialize outside try
    
        # Establish a connection to the PostgreSQL database
    conn = psycopg2.connect(
            host=DB_HOST,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            port=DB_PORT
    )
    cur = conn.cursor()
    cur.execute(
        'SELECT 事故日, 登録番号, 契約者名, ビデオファイル FROM accident_list WHERE 事故番号 = %s', (accident_number,)
     )
    #cur.execute(query, (accident_number,))
    result = cur.fetchone()

    if result:
        accident_date, vehicle_number, owner_name, video_path_url = result
        print(accident_date)
        print(owner_name)
        session['video_path_url'] = video_path_url
        #error in return type
        return render_template('index1.html',accident_number = accident_number, accident_date=accident_date, data = accident_data, video_path = video_path_url )


def extract_key_value_pairs(response_str):

    key_list = []
    value_list = []

    try:
        response_obj = json.loads(response_str)

        if isinstance(response_obj, list):  # Handling a list of dictionaries
            for item in response_obj:
               if isinstance(item, dict):
                    for key, value in item.items():
                       key_list.append(key)
                       value_list.append(value)

        elif isinstance(response_obj, dict):  # Handling a dictionary
            for key, value in response_obj.items():
                key_list.append(key)
                value_list.append(value)

        else:
          print("Invalid JSON structure. Expecting dict or list of dict")

    except json.JSONDecodeError:
        print("Error: Invalid JSON format")


    return key_list, value_list

@app.route('/get-identifiers-data', methods = ['POST'])
def get_identifiers_data():
    data = request.get_json()
    if 'data' in data and len(data['data'])>0:
            client_data_value = data['data'][0]
    accident_number = client_data_value
    print("Accident no for identifiers data ", accident_number)
    # # Example dynamic data
    # accident_number = session['accident_number']
    #dynamic_data = ["十字路", "有", "同一車線", "直進","直進" ,"前方", "後方", "無"]
    #response1_1,response2_2 = process_gemini_step2({"accident_id":"2001"})
    session['selected_accident_number'] = accident_number
    response1_1,response2_2 = process_gemini_step2({"accident_id":accident_number})

# # Process response1
    keys1, values1 = extract_key_value_pairs(response1_1)
    # print("Response 1:")
    print("Keys:", keys1)
    print("Values:", values1)
    # # Process response2
    keys2, values2 = extract_key_value_pairs(response2_2)
    combined_list = values1 + values2
    combined_keys = keys1 + keys2
    print("combined keys")
    print(combined_keys)
    print("combined list values")
    print(combined_list)
    return jsonify(combined_list)

@app.route('/data', methods=['GET'])
def get_data():
    data = load_from_table()
    return jsonify(data)

#This is for preview
@app.route('/videodata', methods=['GET'])
def get_path():
    #video_path = session['video_path_url']
    video_path = "C:/Users/262306/Desktop/Sprint-20/Sprint20-v1-db/temp_1_OriginalVideo_JP_Video1-2-1_車対車（一時停止）_104_short.mp4"
    print(video_path)
    return jsonify(data=video_path)


@app.route('/process_video', methods = ['POST'])
def process_video():
    accident_number = session['selected_accident_number'] 
    data_new = request.json.get('updatedData', [])
    print("Received updated data")
    print("printing received data",data_new)
    #for item in data_new:
        #print(f"{item['key']}: {item['value']}")
    values_list = []
    for item in data_new:
        if isinstance(item, dict) and 'value' in item:  # Check if 'item' is a dictionary AND has a 'value' key
            values_list.append(item['value'])
    print("Step3 started")
    step2_user_selection = values_list
    file_path = "response_step2.txt"

    with open(file_path, 'w', encoding='utf-8') as file:

        file.write(str(step2_user_selection ))
    print(step2_user_selection)
    #step2_user_selection = ["交差点（十字路", False , "右方", "道路外出入", "直進", "左方",  "右折", "一方が優先道路"]
    scenario_data, detail_table = process_gemini_step3({
            "accident_id": accident_number,
            "step2_param": {
                #"basic_judgment_items1": {"事故の場所": "交差点（十字路）"},
                #"basic_judgment_items2": {"信号の有無": False, "契約者から見た相手方の位置": "右方", "契約者と相手方の車線関係": "道路外出入", "契約者の走行方向": "直進", "相手方から見た契約者の位置": "左方", "相手方の走行方向": "右折", "道路の優先関係": "一方が優先道路"},
                "basic_judgment_items1": {"事故の場所": step2_user_selection[0]},
                "basic_judgment_items2": {"信号の有無": step2_user_selection[1], "契約者から見た相手方の位置": step2_user_selection[2], "契約者と相手方の車線関係": step2_user_selection[3], "契約者の走行方向": step2_user_selection[4], "相手方から見た契約者の位置": step2_user_selection[5], "相手方の走行方向": step2_user_selection[6], "道路の優先関係": step2_user_selection[7]}
                }
            }
    )
    session['detail_table'] = detail_table
    print(scenario_data)
    #return jsonify(success = True, scenarios = scenario_data)       
    print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
    csv_path = 'car_car.csv'
    df = pd.read_csv(csv_path) 
    first_column_data = df.iloc[:, 0].tolist()
    first_column_data = [str(option).replace('【', '').replace('】','') for option in first_column_data]
    return jsonify(success=True,scenarios = scenario_data, dropdownOptions = first_column_data)

@app.route('/details_table', methods = ['POST'])
def details_table():
    data = request.get_json()
    accident_number = data.get('data')[0]
    selected_scenario = data.get('selectedScenario')
    session['selected_scenario'] = selected_scenario
    print(f"Accident no for deatils table {accident_number} ")
    print(f"Selected scenario: {selected_scenario}")

    detail_table = session['detail_table'] 
    data1 = detail_table 
    #data1 = '[{"A車": {"センターオーバー": false, "一方通行違反": false, "一方道路車両用信号赤色表示": "なし", "信号の色": "なし", "右折前挙動": "中央によっていない", "左折前挙動": "左側端によっていない", "押しボタン式歩行者信号青色表示": false, "車両の種類": "緊急車両以外", "追越": false, "追越禁止": false, "進路変更": false, "道路交通法24条違反": false}, "B車": {"センターオーバー": false, "一方通行違反": false, "一方道路車両用信号赤色表示": "なし", "信号の色": "なし", "右折前挙動": "中央によっていない", "左折前挙動": "左側端によっていない", "押しボタン式歩行者信号青色表示": false, "車両の種類": "緊急車両以外", "追越": false, "追越禁止": false, "進路変更": false, "道路交通法24条違反": false}, "事故の場所": "道路外進入", "事故の状況": "契約者と相手方の車線関係：道路外出入\\n契約者の走行方向：直進\\n相手方の走行方向：左折\\n相手方から見た契約者の位置：前方\\n契約者から見た相手方の位置：前方\\n道路の優先関係：無"}]'
# Parse the JSON string into a Python list of dictionaries
    # firstColumn = [
    #       '車両種類',
    #       '信号の色',
    #       '一方通行違反',
    #       '一方道路車両用信号赤色',
    #       '押しボタン式歩行者信号青色表示',
    #       'センターオーバー',
    #       '追越',
    #       '追越禁止',
    #       '右折前の挙動',
    #       '左折前の挙動',
    #       '進路変更',
    #       '道路交通法24条違反',
    #     ]
    data1 = json.loads(data1)
    first_dict = data1[0]
    a_car_data = first_dict.get("A車", {})
    b_car_data = first_dict.get("B車", {})
    first_column = list(a_car_data.keys())
    print(first_column)
    # Create lists to store A車 and B車 values
    second_column = list(a_car_data.values())
    fourth_column = list(b_car_data.values())
    for i in range(len(second_column)):
        if second_column[i] == False:
            second_column[i] = 'なし'
        elif second_column[i] == True:  # Added elif to handle True cases
            second_column[i] = 'あり'

    for i in range(len(fourth_column)):
        if fourth_column[i] == False:
            fourth_column[i] = 'なし'
        elif fourth_column[i] == True:  # Added elif to handle True cases
            fourth_column[i] = 'あり'
    print(second_column)
    print(fourth_column)

    # Load CSV
    df = pd.read_csv("判例情報（中項目）.csv", encoding="utf-8")

    # Check if scenario number exists in CSV
    if selected_scenario in df.iloc[:, 0].astype(str).values:
        scenario_row = df[df.iloc[:, 0].astype(str) == selected_scenario].iloc[:, 1:].values[0] # Get values except first column
        editable_rows = [val == '〇' for val in scenario_row] # Convert to boolean list
    else:
        editable_rows = [False] * len(first_column) # Default: all non-editable if scenario not found

    return jsonify(success = True,first_column=first_column, second_column = second_column, fourth_column = fourth_column, editable_rows=editable_rows)

@app.route('/confirm_scenario',methods=['POST'])
def confirm_scenario():
    # accident_number =  session['accident_number']
    accident_number = session['selected_accident_number']
    selected_scenario = session['selected_scenario'].replace("【", "").replace("】","")
    print('selected scenario in confirm scenario is', selected_scenario)
    print('accident no in confirm scenario', accident_number)
    # accident_number = "test2"
    data = request.get_json()
    print("data", data)
    aCar = data.get('aCar') #car Id from dropdown
    session['aCar'] = aCar
    bCar = data.get('bCar') #car Id from dropdown
    session['bCar'] = bCar
    details_data = data.get('detailData')
    print('----------------------------------------------------------------------------------------------')
    print('Details table data', details_data)
    print(type(details_data))
    session['details_data'] = details_data
    # aCar = 20
    # bCar = 80
    # a_basic_fault = 20
    # b_basic_fault = 80
    print(f"Acar: {aCar}")
    print(f"BCar: {bCar}")
    file_path = 'response_step3.txt'
    with open(file_path, 'r', encoding='utf-8') as file:
        data = file.read()
    data = json.loads(data)
 
    # Access the first dictionary in the list
    first_dict = data[0]
    print('------------------------------------------------------------------------------------------------')
    print('first_dict', first_dict)
 
    # Extract A車 and B車 dictionaries
    a_car_data = first_dict.get("A車", {})
    b_car_data = first_dict.get("B車", {})
 
    print("A車:", a_car_data)
    print("B車:", b_car_data)
    # accident_number = "test1"
    file_path = "response_step2.txt"

    with open(file_path, 'r', encoding='utf-8') as file:

        list_string = file.read().strip()

        step2_list = ast.literal_eval(list_string)

    print("***************step2 data*******",step2_list)

    print(type(step2_list))
    jiko_jokyo,modification_answer,carA_basic_fault, carB_basic_fault = process_gemini_step4({
    "accident_id": accident_number,
    "step2_param": {
        #deetail_table_user selection=
         "basic_judgment_items1": {"事故の場所": step2_list[0]},

        "basic_judgment_items2": {"信号の有無": step2_list[1], "契約者から見た相手方の位置": step2_list[2], "契約者と相手方の車線関係": step2_list[3], "契約者の走行方向": step2_list[4], "相手方から見た契約者の位置": step2_list[5], "相手方の走行方向": step2_list[6], "道路の優先関係": step2_list[7]},
        },
    "step3_param": {
        "basic_judgment_items3": {
            "A車": a_car_data,
            "B車": b_car_data,
        },
        "precedent_id": selected_scenario,
        "A車": aCar,
        "B車": bCar
        }
    }
    )
    formatted_faultA = {aCar: carA_basic_fault}
    formatted_faultB =  {bCar: carB_basic_fault}
    session['formattedA'] = formatted_faultA
    session['formattedB'] = formatted_faultB
    session['carA_basic_fault'] = carA_basic_fault
    session['carB_basic_fault'] = carB_basic_fault
    modification_answer = [
        {**modification,"修正要素内容": re.sub(r'A車', aCar, modification["修正要素内容"])} for modification in modification_answer
    ]
    modification_answer = [
        {**modification,"該当理由": re.sub(r'A車', aCar, modification["該当理由"])} for modification in modification_answer
    ]
    modification_answer = [
        {**modification,"修正要素内容": re.sub(r'車A', aCar, modification["修正要素内容"])} for modification in modification_answer
    ]
    modification_answer = [
        {**modification,"該当理由": re.sub(r'車A', aCar, modification["該当理由"])} for modification in modification_answer
    ]
    modification_answer = [
        {**modification,"修正要素内容": re.sub(r'A', aCar, modification["修正要素内容"])} for modification in modification_answer
    ]
    modification_answer = [
        {**modification,"該当理由": re.sub(r'A', aCar, modification["該当理由"])} for modification in modification_answer
    ]
    modification_answer = [
        {**modification, "修正要素内容": re.sub(r'B車', bCar, modification["修正要素内容"])} for modification in modification_answer
    ]
    modification_answer = [
        {**modification, "該当理由": re.sub(r'B車', bCar, modification["該当理由"])} for modification in modification_answer
    ]
    modification_answer = [
        {**modification, "修正要素内容": re.sub(r'車B', bCar, modification["修正要素内容"])} for modification in modification_answer
    ]
    modification_answer = [
        {**modification, "該当理由": re.sub(r'車B', bCar, modification["該当理由"])} for modification in modification_answer
    ]
    modification_answer = [
        {**modification, "修正要素内容": re.sub(r'B', bCar, modification["修正要素内容"])} for modification in modification_answer
    ]
    modification_answer = [
        {**modification, "該当理由": re.sub(r'B', bCar, modification["該当理由"])} for modification in modification_answer
    ]
    print(modification_answer)
    print(type(modification_answer))
    jiko_jokyo = jiko_jokyo.replace("A車", aCar).replace('B車', bCar)
    print(jiko_jokyo)
    return jsonify(success=True,modification_answer = modification_answer, car_a_fault = carA_basic_fault, car_b_fault = carB_basic_fault, case_explanation = jiko_jokyo)
    # return (modification_answer)


def transform_data(data):
  
  a_car = {}
  b_car = {}

  for key, values in data.items():
    # Extract the descriptive part of the key
    description = key[3:].strip()  # Remove "01." and leading/trailing spaces

    # Transform values based on the presence of "なし"
    a_value = values['A']
    b_value = values['B']
    
    # Apply transformations based on the description and values
    if "なし" in a_value:
      a_value = False
    elif a_value == "赤" or a_value == "青":
      pass #keep original value
    elif "寄り" in a_value:
      a_value = "中央によっていない" if a_value != "中央寄り" else "中央によっていない"
      a_value = "左側端によっていない" if a_value != "左端寄り" else "左側端によっていない"

    if "なし" in b_value:
      b_value = False
    elif b_value == "赤" or b_value == "青":
      pass #keep original value
    elif "寄り" in b_value:
      b_value = "中央によっていない" if b_value != "中央寄り" else "中央によっていない"
      b_value = "左側端によっていない" if b_value != "左端寄り" else "左側端によっていない"

    a_car[description] = a_value
    b_car[description] = b_value
    # print("*****************************")
    # print (a_car)
    # print("*****************************")
    # print (b_car)

  return {"A車": a_car, "B車": b_car}



@app.route('/fault_calculation', methods=['POST'])
def fault_calculation():
    data = request.get_json()
    print("data", data)
    fault = data.get('rowData')
    print('row data from frontend', fault) 
    fault_a = fault['faultA']
    fault_b = fault['faultB']
    print('############################################################################################')
    mod_data = data.get('modData')
    print('modification data from user', mod_data)
    print(type(mod_data))
    for item in mod_data:
    # Remove 'CarA' and 'CarB' keys
        item.pop('CarA', None)  # Use pop with None to avoid KeyError if the key doesn't exist
        item.pop('CarB', None)

    # Update 'AI出力結果' based on '訂正'
        if item['訂正'] == '〇':
            item['AI出力結果'] = True
        elif item['訂正'] == '✕':
            item['AI出力結果'] = False
        elif item['訂正'] == '-':
            if item['AI出力結果'] == '〇':
                item['AI出力結果'] = True
            elif item['AI出力結果'] == '✕':
                item['AI出力結果'] = False

    print(mod_data)
    print(type(mod_data))
    accident_number = session['selected_accident_number']
    file_path = "response_step2.txt"
    aCar = session['aCar']
    bCar = session['bCar']
    with open(file_path, 'r', encoding='utf-8') as file:
        list_string = file.read().strip()
        step2_list = ast.literal_eval(list_string)
    selected_scenario = session['selected_scenario'].replace("【", "").replace("】","")
    formattedA  = session['formattedA']
    formattedB = session['formattedB']
    carA_basic_fault =  session['carA_basic_fault'] 
    carB_basic_fault =  session['carB_basic_fault'] 
    details_data = session['details_data']
    transformed_data = transform_data(details_data)
    print(transformed_data)

    final_fault = process_gemini_step5({
    "accident_id": accident_number ,
     "step2_param": {
         "basic_judgment_items1": {"事故の場所": step2_list[0]},
        "basic_judgment_items2": {"信号の有無": step2_list[1], "契約者から見た相手方の位置": step2_list[2], "契約者と相手方の車線関係": step2_list[3], "契約者の走行方向": step2_list[4], "相手方から見た契約者の位置": step2_list[5], "相手方の走行方向": step2_list[6], "道路の優先関係": step2_list[7]},
     },
    "step3_param": {
        "basic_judgment_items3": #{
            #"A車": {"センターオーバー": False, "一方通行違反": False, "一方道路車両用信号赤色表示": "なし", "信号の色": "なし", "右折前挙動": "中央によっていない", "左折前挙動": "左側端によっていない", "押しボタン式歩行者信号青色表示": False, "車両の種類": "緊急車両以外", "追越": False, "追越禁止": False, "進路変更": False, "道路交通法24条違反": False}, 
            #"B車": {"センターオーバー": False, "一方通行違反": False, "一方道路車両用信号赤色表示": "なし", "信号の色": "なし", "右折前挙動": "中央によっていない", "左折前挙動": "左側端によっていない", "押しボタン式歩行者信号青色表示": False, "車両の種類": "緊急車両以外", "追越": False, "追越禁止": False, "進路変更": False, "道路交通法24条違反": False}, 
            transformed_data,
        #},
        "precedent_id": selected_scenario,
        "A車": aCar,
        "B車": bCar
    },
    "step4_param": {
            "basic_negligence": {
             "basic_negligence_vehicle_a": carA_basic_fault,
             "basic_negligence_vehicle_b": carA_basic_fault
         },
            "modification_elements": mod_data,
         "final_negligence": {
             "final_negligence_vehicle_a": fault_a,
             "final_negligence_vehicle_b": fault_b
         }
    }
     })
     
    report_data = final_fault
    
    match = re.search(r"#事故原因\n(.*?)\n#", report_data, re.DOTALL)

    if match:
        potential_cause = match.group(1).strip()  # Extract the text and remove leading/trailing whitespace
        print(potential_cause)
    else:
        potential_cause = None
        print("事故原因 not found in the report.")

    match2 = re.search(r"#事故概要\n(.*?)\n#", report_data, re.DOTALL)

    if match2:
        accident_summary = match2.group(1).strip()  # Extract the text and remove leading/trailing whitespace
        print(accident_summary)
    else:
        accident_summary = None
        print("事故原因 not found in the report.") 
        
    potential_cause = re.sub(r"A車", aCar, potential_cause)
    potential_cause = re.sub(r"B車", bCar, potential_cause)
    accident_summary = re.sub(r"A車", aCar, accident_summary)
    accident_summary = re.sub(r"B車", bCar, accident_summary)
    print(potential_cause,accident_summary)
    return jsonify(final_fault = final_fault, 
                   potential_cause = potential_cause, 
                   accident_summary = accident_summary,
                   carA_basic_fault = carA_basic_fault, 
                   carB_basic_fault = carB_basic_fault,
                   formattedA = formattedA,
                   formattedB = formattedB,
                   aCar = aCar,
                   bCar = bCar)

@app.route('/download_images', methods=['POST'])
def download():
    try:
        data = request.get_json()
        if 'data' in data and len(data['data'])>0:
            
            client_data_value = data['data'][0]
            #client_data_value = "1003"
            print(client_data_value)
            # Call your download function with the client data received
            BUCKET_NAME = "firstbucket-storage-2" # replace with your bucket name
            CREDENTIALS_PATH = r"storagefile.json" # replace with path to key file
            FOLDER_PATH = client_data_value  # replace with the folder name you want to download
            LOCAL_ZIP_PATH = str(client_data_value) + ".zip" # replace with where you want to download the files.
            local_download = get_download_folder()
            
            local_download="."
            LOCAL_ZIP_PATH = FOLDER_PATH +".zip" # replace with where you want to download the files.

            download_gcs_folder_as_zip( BUCKET_NAME, FOLDER_PATH, LOCAL_ZIP_PATH, CREDENTIALS_PATH)
            
            #print("downloaded")
           

            return jsonify({"status": "success", "filename":LOCAL_ZIP_PATH}) # Sending filename which will be used for downloding file
        else:
            return jsonify({"status":"error","message":"No data provided"})
    except Exception as e:
        print(e)
        return jsonify({"status":"error","message":str(e)})


@app.route('/download_video', methods=['POST'])
def downloadvideo():
    try:
        data = request.get_json()
        if 'data' in data and len(data['data'])>0:
            client_data_value = data['data'][0]
            #client_data_value = "1003"
            print(client_data_value)
            # Call your download function with the client data received
            BUCKET_NAME = "firstbucket-storage-2" # replace with your bucket name
            CREDENTIALS_PATH = r"storagefile.json" # replace with path to key file
            FOLDER_PATH = client_data_value  # replace with the folder name you want to download
            LOCAL_ZIP_PATH = str(client_data_value) + ".zip" # replace with where you want to download the files.
            local_download = get_download_folder()

            local_download="."
            LOCAL_ZIP_PATH = local_download+"/ " + FOLDER_PATH + ".zip" # replace with where you want to download the files.

            download_gcs_video_as_zip( BUCKET_NAME, FOLDER_PATH, LOCAL_ZIP_PATH, CREDENTIALS_PATH)
            # download_video_from_gcp_apiclient(BUCKET_NAME, FOLDER_PATH, LOCAL_ZIP_PATH)
            #print("downloaded")
           

            return jsonify({"status": "success", "filename":LOCAL_ZIP_PATH}) # Sending filename which will be used for downloding file
        else:
            return jsonify({"status":"error","message":"No data provided"})
    except Exception as e:
        print(e)
        return jsonify({"status":"error","message":str(e)})



@app.route('/download_file',methods=['GET'])
def download_file():
    filename = request.args.get('filename')
    if filename and os.path.exists(filename):
        return send_file(filename,as_attachment=True)
    else:
        return "file not found"


if __name__ == '__main__':
     app.run()
 

      
 