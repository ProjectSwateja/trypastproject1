data = {'01.車両の種類': {'A': '緊急車両以外', 'B': '緊急車両以外'}, '02.信号の色': {'A': '赤', 'B': '青'}, '03.一方通行違反': {'A': 'なし', 'B': 'なし'}, '04.一方道路車両用信号赤色表示': {'A': 'なし', 'B': 'なし'}, '05.押しボタン式歩行者信号青色表示': {'A': 'なし', 'B': 'なし'}, '06.センターオーバー': {'A': 'なし', 'B': 'なし'}, '07.追越': {'A': 'なし', 'B': 'なし'}, '08.追越禁止': {'A': 'なし', 'B': 'なし'}, '09.右折前挙動': {'A': '中央寄り', 'B': '中央寄り'}, '10.左折前挙動': {'A': '左端寄り', 'B': '左端寄り'}, '11.進路変更': {'A': 'なし', 'B': 'なし'}, '12.道路交通法24条違反': {'A': 'なし', 'B': 'なし'}}

def transform_data(data):
  
  a_car = {}
  b_car = {}

  for key, values in data.items():
    # Extract the descriptive part of the key
    description = key[3:].strip()  # Remove "01." and leading/trailing spaces

    # Transform values based on the presence of "なし"
    a_value = values['A']
    b_value = values['B']
    
    # Apply transformations based on the description and values
    if "なし" in a_value:
      a_value = False
    elif a_value == "赤" or a_value == "青":
      pass #keep original value
    elif "寄り" in a_value:
      a_value = "中央によっていない" if a_value != "中央寄り" else "中央によっていない"
      a_value = "左側端によっていない" if a_value != "左端寄り" else "左側端によっていない"

    if "なし" in b_value:
      b_value = False
    elif b_value == "赤" or b_value == "青":
      pass #keep original value
    elif "寄り" in b_value:
      b_value = "中央によっていない" if b_value != "中央寄り" else "中央によっていない"
      b_value = "左側端によっていない" if b_value != "左端寄り" else "左側端によっていない"

    a_car[description] = a_value
    b_car[description] = b_value
    # print("*****************************")
    # print (a_car)
    # print("*****************************")
    # print (b_car)

  return {"A車": a_car, "B車": b_car}

transformed_data = transform_data(data)
print(transformed_data)
print(type(transformed_data))