from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from google.oauth2 import service_account
 
def delete_folder_in_gcs(bucket_name, folder_name, credentials_path):
    """
    Deletes a folder in a GCP bucket by deleting all objects under that folder.
    
    :param bucket_name: Name of the GCS bucket
    :param folder_name: Name of the folder to delete (should end with a "/")
    :param credentials_path: Path to the service account key file (JSON)
    """
    try:
        # Authenticate and build the service
        credentials = service_account.Credentials.from_service_account_file(credentials_path)
        service = build('storage', 'v1', credentials=credentials)
 
        # List objects in the folder
        objects = service.objects().list(bucket=bucket_name, prefix=folder_name).execute()
 
        if 'items' in objects:
            for obj in objects['items']:
                object_name = obj['name']
                # Delete each object
                service.objects().delete(bucket=bucket_name, object=object_name).execute()
                print(f"Deleted: {object_name}")
            print(f"Folder '{folder_name}' deleted successfully.")
        else:
            print(f"No objects found in folder '{folder_name}'. It might already be empty or not exist.")
    
    except HttpError as e:
        print(f"An error occurred: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
 
# Example usage

#bucket_name = "firstbucket-storage-2"
#folder_name = "2"  # Ensure the folder name ends with a "/"
#credentials_path = "storagefile.json"
 
#delete_folder_in_gcs(bucket_name, folder_name, credentials_path)