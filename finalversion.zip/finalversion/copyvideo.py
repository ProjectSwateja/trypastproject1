
from googleapiclient.discovery import build
from google.oauth2 import service_account
import os
import io
import tempfile
from googleapiclient.http import MediaIoBaseDownload, MediaFileUpload, MediaIoBaseUpload
from flask import Flask, request, session, jsonify

app = Flask(__name__)
#app.secret_key = 'your_secret_key' # Replace with a real secret key

# Replace with your actual values
# BUCKET_NAME = "firstbucket-storage-2"  # Replace with your GCS bucket name
# CREDENTIALS_FILE_PATH = "storagefile.json"  # Replace with path to your service account JSON file

# destination_object_name = f"ProcessedVideo/13.mp4"
# gcs_file_path = "firstbucket-storage-2/13/OriginalVideo"

# source_bucket_name   
# source_object_name    
# destination_bucket_name
# destination_object_name 
# credentials_path    
def copy_video_in_gcs(source_bucket_name,source_object_name,destination_bucket_name,destination_object_name,credentials_path):


    # source_bucket_name = "firstbucket-storage-2"
    # source_object_name = "13/OriginalVideo/13.mp4"
    # destination_bucket_name = "firstbucket-storage-2"
    # destination_object_name = f"13/Processed_Video/13.mp4"
    # credentials_path = "storagefile.json"

    
    """Copies a video within a Google Cloud Storage bucket.

    Args:
        source_bucket_name: The name of the source bucket.
        source_object_name: The full path of the source object in GCS.
        destination_bucket_name: The name of the destination bucket.
        destination_object_name: The full path of the destination object in GCS.
        credentials_path: The path to the Google Cloud service account credentials JSON file.
    """

    try:
        # Authenticate with Google Cloud using service account credentials
        creds = service_account.Credentials.from_service_account_file(credentials_path)
        service = build("storage", "v1", credentials=creds)

        print(f"Copying {source_object_name} from {source_bucket_name} to {destination_object_name} in {destination_bucket_name}")


        # Check if source object exist
        try:
          service.objects().get(bucket=source_bucket_name, object=source_object_name).execute()
        except Exception as e:
           print(f"Error finding source object {source_object_name} in {source_bucket_name}. Details: {e}")
           return False

        # Download the video from the source bucket
        req = service.objects().get_media(bucket=source_bucket_name, object=source_object_name)
        fh = io.BytesIO()
        downloader = MediaIoBaseDownload(fh, req)
        done = False
        while not done:
            status, done = downloader.next_chunk()
            print(f"Download progress {int(status.progress()*100)}%")
        print("Download complete")

        # Upload the video to the destination bucket
        fh.seek(0) # Reset stream to beginning for upload
        #media = MediaIoBaseUpload(fh, mimetype="video/*")  # Set appropriate mimetype, replace if you know specific one
        media = MediaIoBaseUpload(fh, mimetype="video/*", resumable=True)
        req = service.objects().insert(bucket=destination_bucket_name, name=destination_object_name, media_body=media)
        resp = None
        while resp is None:
           status, resp = req.next_chunk()
           if status:
                print(f"Upload progress {int(status.progress()*100)}%")
        print("Upload complete")


        print(f"Successfully copied video to {destination_object_name} in {destination_bucket_name}")
        return True

    except Exception as e:
        print(f"Error copying video: {e}")
        return False


#copy_video_in_gcs()