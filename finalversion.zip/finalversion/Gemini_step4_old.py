import os
import base64
import sys
import yaml
from pathlib import Path
from yaml.loader import SafeLoader
import google.generativeai as genai
from PIL import Image
from vertexai.generative_models import GenerationConfig, GenerativeModel, Part
from google.generativeai import caching
import json
import warnings
import google.ai.generativelanguage as glm
import datetime
import cv2
import re
import shutil
from pprint import pprint
import googleapiclient.discovery
from google.oauth2 import service_account
import io


# configのロード
with open(Path(__file__).parent.joinpath("config.yaml"), encoding="utf-8") as file:
    config = yaml.load(file, Loader=SafeLoader)
 

# API-KEYの設定
GOOGLE_API_KEY=config["gemini"]["api_key"]
genai.configure(api_key=GOOGLE_API_KEY)
GEMINI_MODEL=config["gemini"]["model"]

response_schema_step4_1 = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "修正要素内容": {
                "type": "string"
            },
            "数値": {
                "type": "number"
            }
        },
        "required": ["修正要素内容","数値"]
    }
}

response_schema_step4_2 = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "修正要素内容": {
                "type": "string"
            },
            "数値": {
                "type": "number"
            },
            "AI出力結果": {
                "type": "boolean"
            },
            "該当理由": {
                "type": "string"
            }
        },
        "required": ["修正要素内容","数値", "AI出力結果", "該当理由"]
    }
}



safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_NONE"
    }
]

generation_config = {
 
    "temperature": 0.2,
 
    "top_k": 1,
 
    "max_output_tokens": 8192,
 
    #"response_mime_type": "application/json",
 
}
 
model = genai.GenerativeModel(model_name=GEMINI_MODEL,generation_config=generation_config, safety_settings=safety_settings)
 
# Generation Config
generation_config_step4_1= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema_step4_1
}

generation_config_step4_2= {
  "temperature": 0,  # 生成するテキストのランダム性を制御
  #"top_p": 1,          # 生成に使用するトークンの累積確率を制御
  "top_k": 1,          # 生成に使用するトップkトークンを制御
  "max_output_tokens": 8192,  # 最大出力トークン数を指定`
  "response_mime_type": "application/json",
  "response_schema": response_schema_step4_2
}

FRAME_EXTRACTION_DIRECTORY = "processed_images/"
FRAME_PREFIX = "_frame"
KEY_FILE_PATH = "storagefile.json"
BUCKET_NAME = "firstbucket-storage-2"
 
#画像ファイルをコンテキストキャッシュにアップロード
def context_cache(accident_id):
    # サービスアカウントの認証情報を作成
    credentials = service_account.Credentials.from_service_account_file(KEY_FILE_PATH)
    client = googleapiclient.discovery.build("storage", "v1", credentials=credentials, cache_discovery=False)

    # フォルダパスを指定
    folder_path = f"{accident_id}/processed_images/"

    # 画像ファイルを格納する辞書
    image_files_dict = {}

    # GCS内のフォルダリストを取得
    req = client.objects().list(bucket=BUCKET_NAME, prefix=folder_path)
    while req is not None:
        response = req.execute()

        if "items" in response:
            for item in response["items"]:
                # ファイル名を取得
                file_name = item["name"].split("/")[-1]  # フォルダ階層を除いたファイル名
                if file_name:  # ファイル名が空でない場合
                    # ファイルを一時的にダウンロードして辞書に格納
                    req_media = client.objects().get_media(bucket=BUCKET_NAME, object=item["name"])
                    file_data = io.BytesIO()
                    downloader = googleapiclient.http.MediaIoBaseDownload(file_data, req_media)

                    done = False
                    while not done:
                        _, done = downloader.next_chunk()

                    image_files_dict[file_name] = file_data.getvalue()

        # 次のページがある場合のリクエストを取得
        req = client.objects().list_next(previous_request=req, previous_response=response)

    #FRAME_EXTRACTION_DIRECTORY = "frames/"
    #FRAME_PREFIX = "_frame"

    # Fileクラスの定義
    class File:
        def __init__(self, file_path: str, display_name: str = None):
            self.file_path = file_path
            if display_name:
                self.display_name = display_name
            self.timestamp = get_timestamp(file_path)

        def set_file_response(self, response):
            self.response = response

    # timestampの取得
    def get_timestamp(filename):
        parts = filename.split(FRAME_PREFIX)
        if len(parts) != 2:
            return None
        return parts[1].split('.')[0]

    # Fileリストの準備
    files = os.listdir(FRAME_EXTRACTION_DIRECTORY)
    files = sorted(files)
    files_to_upload = []
    for file in files:
        files_to_upload.append(
            File(file_path=os.path.join(FRAME_EXTRACTION_DIRECTORY, file)))


    # ファイルのアップロード
    uploaded_files = []
    for file in files_to_upload:
        print(f'Uploading: {file.file_path}...')
        response = genai.upload_file(path=file.file_path)
        file.set_file_response(response)
        #uploaded_files.append(file)
        uploaded_files.append(response.name)

    # キャッシュを作成
    cachetime = config["gemini"]["cachetime"]

    cache = caching.CachedContent.create(
        model=GEMINI_MODEL,
        display_name=accident_id,
        system_instruction="交通事故のドライブレコーダー動画のスライスされた画像に基づいて回答する役割を持っています。",
        contents=uploaded_files,
        ttl=datetime.timedelta(cachetime),
    )

    return cache

def process_gemini_step4(step4_json):

    accident_id = step4_json["accident_id"]

    cached_contents = caching.CachedContent.list()

    cache_flg = 0

    for content in cached_contents:
        print(content)
        # content.display_nameとaccident_idを比較
        if content.display_name == accident_id:
            cache = content
            cache_flg = 1

    if cache_flg == 0:
        cache = context_cache(accident_id)

    # 作成したキャッシュを使用する
    model_step4_1 = genai.GenerativeModel.from_cached_content(cached_content=cache,generation_config=generation_config_step4_1, safety_settings=safety_settings)
    model_step4_2 = genai.GenerativeModel.from_cached_content(cached_content=cache,generation_config=generation_config_step4_2, safety_settings=safety_settings)

    prompt = """
    交通事故のドライブレコーダー動画が渡されます。
    ドライブレコーダーを搭載している車をA車、事故の相手をB車として、事実のみ箇条書きで教えてください。

    ＜車同士がぶつかった場所の状況を記載すること＞
    ・事故の場所：交差点（十字路）、Ｔ字路（丁字路）、直線、道路外進入

    判断する順番は以下の通りです。
    １．衝突が起きた場所の道路の状況を確認
    ２．ドライブレコーダーを搭載している車の動きを確認
    ３．衝突した相手の車の動きを確認
    ４．道路標識が存在するか
    ５．道路標示が存在するか

    ・十字路交差点(四つ角、交差道路)
        - 4つの道路がほぼ同じ角度で交わっているため、道路の接続数も確認すること
        - 2本の道路がほぼ直角に交わる十字の形をしているため、道路の形状も確認すること
        - 交差点クロスマークが交差点にある場合は十字路交差点と判断すること
        - 他車両が反対車線や対向車線を走っている場合、道路が見え辛い可能性もあるので、より正確な形状を確認すること
        - 丁字路(T字路)のように見える箇所もあるので、より正確な形状を確認し、十字路を判断すること

    ・丁字路(T字路)交差点
        - 3つの道路がT字型に交わっているため、道路の接続数と形状も確認すること
        - 交差点Tマークが交差点にある場合は丁字路(T字路)交差点と判断すること
        - 十字路のように見える箇所もあるので、より正確な形状を確認し、丁字路(T字路)を判断すること
        - A車とB車がともに丁字路(T字路)交差点の直進路を走行している場合は直線道路(曲線道路も含む)を選択すること

    ・直線道路(曲線道路も含む)
        - 他道路との交わりはないため、道路の接続数と形状も確認すること
        - 信号はないため、街灯を信号機と間違えないようにすること
        - 丁字路(T字路)のように見える箇所もあるので、より正確な形状を確認し、直線道路を判断すること
        - 十字路のように見える箇所もあるので、より正確な形状を確認し、直線道路を判断すること
        - A車とB車がともに丁字路(T字路)交差点の直進路を走行している場合は直線道路(曲線道路も含む)を選択すること

    ・道路外入出
        - A車とB車の片方が道路外から侵入、もしくは道路外に退出する
        - 信号はないため、街灯を信号機と間違えないようにすること
        - 道路と道路外の境界には車道外側線があることが多いため、それを正確に確認して、道路外を判断すること
    """


    request = []
    request.append(prompt)

    history2 = []
    history2.append({'role':'user', 'parts': request})
    history2.append({'role':'model','parts': step4_json["step2_param"]["basic_judgment_items1"]})

    prompt2 = """
    続いて、以下の内容を答えてください。

    信号の有無（有 or 無）
    契約者と相手方の車線関係（直行車線、直線路と突き当たり路、同一車線、道路外出入、反対車線）
    契約者の走行方向（直進、右折、左折、転回）
    相手方の走行方向（直進、右折、左折、転回）
    相手方から見た契約者の位置（前方、後方、左方、右方）
    契約者から見た相手方の位置（前方、後方、左方、右方）
    道路の優先関係（無、一方が一時停止規制、一方が広い、一方が優先道路、同幅員）

    """

    request2 = []
    request2.append(prompt2)


    history2.append({'role':'user', 'parts': request2})
    history2.append({'role':'model', 'parts': step4_json["step2_param"]["basic_judgment_items2"]})

    prompt3 = """
    続いて、以下の内容を答えてください。
    A車、B車それぞれの状況を出力すること。

    ・車両の種類 : 緊急車両、緊急車両以外
    ・信号の色:  青、赤、黄
    ・一方通行違反 : あり、なし
    ・一方道路車両用信号 : あり（赤色）、あり（赤色以外）、なし
    ・押しボタン式歩行者信号 : あり（青色）、あり（青色以外）、なし
    ・センターオーバー : あり、なし
    ・追越 : あり、なし
    ・追越禁止 : あり、なし
    ・右折前挙動 : 中央によっている、中央によっていない
    ・左折前挙動 : 左側端によっている、左側端によっていない
    ・進路変更 : あり、なし
    ・道路交通法24条違反 : あり、なし
    """

    request3 = []
    request3.append(prompt3)


    history2.append({'role':'user', 'parts': request3})
    history2.append({'role':'model', 'parts': step4_json["step3_param"]["basic_judgment_items3"]})


    # step1（Geminiが推論した判定項目をユーザーが修正して、それをもとに判例番号の候補を推論する）
    # 目次一覧
    file_path = 'data/hanrei.txt'
    with open(file_path, 'r', encoding='utf-8') as file:
        hanrei = file.read()

    hanrei_prompt = f"""
    以下の内容は、交通事故判例の一覧です。次のステップで利用します。

    {hanrei}

    """

    query_step1 = f"""
    これまでの事故の状況から、与えられた交通事故判例の【】の判例番号を決めてください。
    出力内容は"判例番号", "ドラレコ車", "相手車"です。
    """

    #result1 =  "判例番号：" + step4_json["step3_param"]["precedent_id"] + ",ドラレコ車：" + step4_json["step3_param"]["dashcam_vehicle"] + ", 事故相手車：" + step4_json["step3_param"]["other_party_vehicle"]
    result1 =  "判例番号：" + str(step4_json["step3_param"]["precedent_id"]) + str(step4_json["step3_param"]["A車"]) + ":A車,"+ str(step4_json["step3_param"]["B車"]) + ":B車"

    history2.append({'role':'user', 'parts': hanrei_prompt})
    history2.append({'role':'user', 'parts': query_step1})
    history2.append({'role':'model', 'parts': result1})


    # step2 ユーザーが決定した判定番号をもとに、Geminiが判定項目詳細を推論する。
    # 本番はCloudSQLに変更
    file_path = f'data/{step4_json["step3_param"]["precedent_id"]}.txt'
    with open(file_path, 'r', encoding='utf-8') as file:
        hanrei = file.read()


    # 修正要素を算出
    hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。修正要素と数値を1行ずつ数値も含めて出力してください。
    {hanrei}"""

    shusei_youso = model_step4_1.generate_content(hanrei_prompt)

    query_step4 = f"""
    交通事故の動画が渡されます。

    [出力内容]
    以下に渡される[修正要素]の内容を1行ずつ、今回の交通事故に該当するか数値も含めて表示してください。
    渡される[修正要素]以外の内容は表示しないでください。修正要素の数値は変更しないでください。
    修正要素が該当する場合「該当あり」として、その修正要素の内容と数値と該当理由を1行で教えてください。
    修正要素が該当しない場合「該当なし」として表示してください。
    出力の順番は、「修正要素内容」「数値」「AI出力結果」「該当理由」です。

    [修正要素]
    {shusei_youso}

    """

    history2.append({'role':'user', 'parts': query_step4})

    # 推論の実行
    response_step4 = model_step4_2.generate_content(
        history2
    )

    #print(response_step4.text)
    # JSON文字列をPythonのリストに変換
    data = json.loads(response_step4.text)

    # 並び替え後の結果を保持するリスト
    ordered_data = []

    # 指定の順序に並び替え
    for item in data:
        ordered_item = {
            "修正要素内容": item.get("修正要素内容"),
            "数値": item.get("数値"),
            "AI出力結果": item.get("AI出力結果"),
            "該当理由": item.get("該当理由")
        }
        ordered_data.append(ordered_item)

    print(ordered_data)

    modified_data = []
    for item in ordered_data:
        new_item = item.copy()  # Create a copy to avoid modifying the original list
        del new_item['該当理由']
        modified_data.append(new_item)

    #print(modified_data)
    #print(type(modified_data))
    for item in ordered_data:
        if 'AI出力結果' in item:  # Check if the key exists
            if item['AI出力結果'] == True:
                item['AI出力結果'] = "〇"
            elif item['AI出力結果'] == False:
                item['AI出力結果'] = "✕"
 
    print (modified_data)
    pecedent_id_file = f'data/{step4_json["step3_param"]["precedent_id"]}.txt'
    with open( pecedent_id_file, 'r', encoding='utf-8') as file:
        hanrei = file.read()
 
    hanrei_prompt = f"""以下は「修正要素の算出基準」の資料です。基本割合を数値も含めて出力してください。
    {hanrei}
    """
 
    kihon_wariai = model.generate_content(hanrei_prompt)
    print(kihon_wariai.text)
    kihon_wariai = kihon_wariai.text
    kihon_wariai = re.findall(r'\d+', kihon_wariai)
 
    kihon_wariai = [int(x) for x in kihon_wariai]
    carA_basic_fault = kihon_wariai[0]
    carB_basic_fault = kihon_wariai[1]
    print(carA_basic_fault,carB_basic_fault)
    # return (modified_data, carA_basic_fault, carB_basic_fault)
    return (ordered_data, carA_basic_fault, carB_basic_fault)

    #return ordered_data


# file_path = 'response_step3.txt'
# with open(file_path, 'r', encoding='utf-8') as file:
#     data = file.read()
# data = json.loads(data)
 
# # Access the first dictionary in the list
# first_dict = data[0]
 
# # Extract A車 and B車 dictionaries
# a_car_data = first_dict.get("A車", {})
# b_car_data = first_dict.get("B車", {})
 
# print("A車:", a_car_data)
# print("B車:", b_car_data)
 
# aCar = "dashcam_vehicle"
# bCar = "other_party_vehicle"
# process_gemini_step4({
#   "accident_id": "20250129-01",
#   "step2_param": {
#     #deetail_table_user selection=
#     "basic_judgment_items1": {"事故の場所": "交差点（十字路）"},
#     "basic_judgment_items2": {"信号の有無": False, "契約者から見た相手方の位置": "右方", "契約者と相手方の車線関係": "道路外出入", "契約者の走行方向": "直進", "相手方から見た契約者の位置": "左方", "相手方の走行方向": "右折", "道路の優先関係": "一方が優先道路"},
#     },
#   "step3_param": {
#     "basic_judgment_items3": {
#         "A車": a_car_data,
#         "B車": b_car_data,
#     },
#     "precedent_id": "101-1",
#         "A車": aCar,
#         "B車": bCar
#     }
#   }
# )