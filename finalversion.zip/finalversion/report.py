import re
result_report = """#判例番号と判例概要
判例番号：109

#事故概要
ドラレコを搭載したA車は直進、B車は右折です。場所は信号のある十字路交差点です。A車から見て右方にB車が見えます。B車から見て左方にA車が見えます。 両者赤信号で交差点に進入し、衝突しました。

#事故原因
A車とB車は共に信号無視で交差点に進入しました。A車は直進、B車は右折でした。そのため、両者に過失があると判断しました。

#基本割合
A車:40 B車:40

#修正要素
法50条違反の交差点進入 10 ：A車とB車は、いずれも信号機が赤色のときに交差点に進入したため、道路交通法第50条違反に該当します。
#最終過失割合
A車:50 B車:50"""

match = re.search(r"#事故原因\n(.*?)\n#", result_report, re.DOTALL)

if match:
    potential_cause = match.group(1).strip()  # Extract the text and remove leading/trailing whitespace
    print(potential_cause)
else:
    potential_cause = None
    print("事故原因 not found in the report.")

match2 = re.search(r"#事故概要\n(.*?)\n#", result_report, re.DOTALL)

if match2:
    accident_summary = match2.group(1).strip()  # Extract the text and remove leading/trailing whitespace
    print(accident_summary)
else:
    accident_summary = None
    print("事故原因 not found in the report.")
