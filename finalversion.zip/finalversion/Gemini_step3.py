import os
import numpy as np
import base64
import sys
import yaml
from pathlib import Path
from yaml.loader import SafeLoader
import google.generativeai as genai
from PIL import Image
from vertexai.generative_models import GenerationConfig, GenerativeModel, Part
from google.generativeai import caching
import datetime
import shutil
from google.cloud import storage
import tempfile
import googleapiclient.discovery
from google.oauth2 import service_account
import io
import ast
import re
import pandas as pd
import json

# configのロード
with open(Path(__file__).parent.joinpath("config.yaml"), encoding="utf-8") as file:
    config = yaml.load(file, Loader=SafeLoader) 

# API-KEYの設定
GOOGLE_API_KEY=config["gemini"]["api_key"]
genai.configure(api_key=GOOGLE_API_KEY)
GEMINI_MODEL=config["gemini"]["model"]


response_schema1 = {
  "type": "array",
  "items": {
    "type": "object",
    "properties": {
      "事故の場所": {
        "type": "string"
      },
      "事故の状況": {
        "type": "string"
      },
      "A車": {
        "type": "object",
         "properties": {
          "01.車両の種類": {"type": "string"},
          "02.信号の色": {"type": "string"},
          "03.一方通行違反": {"type": "boolean"},
          "04.一方道路車両用信号赤色表示": {"type": "string"},
          "05.押しボタン式歩行者信号青色表示": {"type": "boolean"},
          "06.センターオーバー": {"type": "boolean"},
          "07.追越": {"type": "boolean"},
          "08.追越禁止": {"type": "boolean"},
          "09.右折前挙動": {"type": "string"},
          "10.左折前挙動": {"type": "string"},
          "11.進路変更": {"type": "boolean"},
          "12.道路交通法24条違反": {"type": "boolean"},
        },
        "required": [
          "01.車両の種類", "02.信号の色", "03.一方通行違反", "04.一方道路車両用信号赤色表示", 
          "05.押しボタン式歩行者信号青色表示", "06.センターオーバー", "07.追越", "08.追越禁止", "09.右折前挙動", 
          "10.左折前挙動","11.進路変更","12.道路交通法24条違反"
        ]
      },
      "B車": {
        "type": "object",
        "properties": {
          "01.車両の種類": {"type": "string"},
          "02.信号の色": {"type": "string"},
          "03.一方通行違反": {"type": "boolean"},
          "04.一方道路車両用信号赤色表示": {"type": "string"},
          "05.押しボタン式歩行者信号青色表示": {"type": "boolean"},
          "06.センターオーバー": {"type": "boolean"},
          "07.追越": {"type": "boolean"},
          "08.追越禁止": {"type": "boolean"},
          "09.右折前挙動": {"type": "string"},
          "10.左折前挙動": {"type": "string"},
          "11.進路変更": {"type": "boolean"},
          "12.道路交通法24条違反": {"type": "boolean"},
        },
        "required": [
          "01.車両の種類", "02.信号の色", "03.一方通行違反", "04.一方道路車両用信号赤色表示", 
          "05.押しボタン式歩行者信号青色表示", "06.センターオーバー", "07.追越", "08.追越禁止", "09.右折前挙動", 
          "10.左折前挙動","11.進路変更","12.道路交通法24条違反"
        ]
      },
    },
    "required": ["事故の場所", "事故の状況", "A車", "B車"]
  }
}

response_schema2 = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "判例番号": {
                "type": "string"
            },
        },
        "required": ["判例番号"]
    }
}



safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_NONE"
    }
]

generation_config1= {
"temperature": 0,  # 生成するテキストのランダム性を制御
#"top_p": 1,          # 生成に使用するトークンの累積確率を制御
"top_k": 1,          # 生成に使用するトップkトークンを制御
"max_output_tokens": 8192,  # 最大出力トークン数を指定`
"response_mime_type": "application/json",
"response_schema": response_schema1
}

generation_config2= {
"temperature": 0,  # 生成するテキストのランダム性を制御
#"top_p": 1,          # 生成に使用するトークンの累積確率を制御
"top_k": 1,          # 生成に使用するトップkトークンを制御
"max_output_tokens": 8192,  # 最大出力トークン数を指定`
"response_mime_type": "application/json",
"response_schema": response_schema2
}


BUCKET_NAME = "firstbucket-storage-1"
KEY_FILE_PATH = "./storagefile.json"

FRAME_EXTRACTION_DIRECTORY = "frames/"
FRAME_PREFIX = "_frame"

#画像ファイルをコンテキストキャッシュにアップロード
def context_cache(accident_id):
    # サービスアカウントの認証情報を作成
    credentials = service_account.Credentials.from_service_account_file(KEY_FILE_PATH)
    client = googleapiclient.discovery.build("storage", "v1", credentials=credentials, cache_discovery=False)

    # フォルダパスを指定
    folder_path = f"{accident_id}/frames/"

    # 画像ファイルを格納する辞書
    image_files_dict = {}

    # GCS内のフォルダリストを取得
    req = client.objects().list(bucket=BUCKET_NAME, prefix=folder_path)
    while req is not None:
        response = req.execute()

        if "items" in response:
            for item in response["items"]:
                # ファイル名を取得
                file_name = item["name"].split("/")[-1]  # フォルダ階層を除いたファイル名
                if file_name:  # ファイル名が空でない場合
                    # ファイルを一時的にダウンロードして辞書に格納
                    req_media = client.objects().get_media(bucket=BUCKET_NAME, object=item["name"])
                    file_data = io.BytesIO()
                    downloader = googleapiclient.http.MediaIoBaseDownload(file_data, req_media)

                    done = False
                    while not done:
                        _, done = downloader.next_chunk()

                    image_files_dict[file_name] = file_data.getvalue()

        # 次のページがある場合のリクエストを取得
        req = client.objects().list_next(previous_request=req, previous_response=response)

    FRAME_EXTRACTION_DIRECTORY = "frames/"
    FRAME_PREFIX = "_frame"

    # Fileクラスの定義
    class File:
        def __init__(self, file_path: str, display_name: str = None):
            self.file_path = file_path
            if display_name:
                self.display_name = display_name
            self.timestamp = get_timestamp(file_path)

        def set_file_response(self, response):
            self.response = response

    # timestampの取得
    def get_timestamp(filename):
        parts = filename.split(FRAME_PREFIX)
        if len(parts) != 2:
            return None
        return parts[1].split('.')[0]


    # ファイルのアップロード
    uploaded_files = []
    for file_name, file_data in image_files_dict.items():
        # 一時ファイルとして保存
        with tempfile.NamedTemporaryFile(delete=False, suffix=f"_{file_name}") as temp_file:
            temp_file.write(file_data)
            temp_file_path = temp_file.name  # 一時ファイルのパスを取得
        
        try:
            # 一時ファイルをアップロード
            response = genai.upload_file(temp_file_path)  # 一時ファイルパスを渡す
            uploaded_files.append(response.name)
            print(f"Uploaded {file_name} as {file_name}")
        except Exception as e:
            print(f"Error uploading {file_name}: {e}")
        finally:
            # アップロード後に一時ファイルを削除
            os.remove(temp_file_path)

    # キャッシュを作成
    cachetime = config["gemini"]["cachetime"]

    cache = caching.CachedContent.create(
        model=GEMINI_MODEL,
        display_name=accident_id,
        system_instruction="交通事故のドライブレコーダー動画のスライスされた画像に基づいて回答する役割を持っています。",
        contents=uploaded_files,
        ttl=datetime.timedelta(cachetime),
    )

    return cache

def hanrei_descend(params: dict, top_hanrei_numbers: list):
    df = pd.read_csv("data/hanrei.csv")

    # 比較するデータを1つの辞書に統合
    comparison_data = {**params["step2_param"]["basic_judgment_items1"], **params["step2_param"]["basic_judgment_items2"]}

    # 各行と比較し、一致する項目数をカウント
    match_counts = []
    for _, row in df.iterrows():
        match_count = sum(
            1 for key, value in comparison_data.items() if key in row and str(row[key]) == str(value)
        )
        match_counts.append(match_count)

    # 結果をデータフレームに追加
    df["match_count"] = match_counts
    df = df.sort_values(by=["match_count", "判例番号"], ascending=[False, True])
    
    # 指定した判例番号のフォーマットを統一（【】を削除）
    def clean_number(value):
        if value is None:
            return ""
        return re.sub(r"[【】]", "", str(value)).strip()
    

    # デバッグ: 各要素の型を確認
    for item in top_hanrei_numbers:
        if isinstance(item, dict) and "判例番号" in item:
            original = item["判例番号"]
            cleaned = clean_number(str(original))

    # `cleaned_hanrei_numbers` を作成（数値の場合に備えて `str()` を適用）
    cleaned_hanrei_numbers = [
        clean_number(str(item["判例番号"])) for item in top_hanrei_numbers 
        if isinstance(item, dict) and "判例番号" in item and item["判例番号"]
    ]

    # `df["判例番号"]` を文字列に統一し、`clean_number()` を適用
    df["判例番号"] = df["判例番号"].astype(str).apply(clean_number).str.strip()

    # `cleaned_hanrei_numbers` が空の場合にエラーを出す
    if not cleaned_hanrei_numbers:
        raise ValueError("cleaned_hanrei_numbers is empty. Check the input data.")

    # 指定した判例番号を優先して並び替え
    df["priority"] = df["判例番号"].apply(lambda x: cleaned_hanrei_numbers.index(x) if x in cleaned_hanrei_numbers else len(cleaned_hanrei_numbers))
    df = df.sort_values(by=["priority", "match_count"], ascending=[True, False]).drop(columns=["priority"])  
    df = df[["判例番号"]]

    #return df.to_dict(orient="records")
    return df.head(18).to_dict(orient="records")

def process_gemini_step3(step3_json):

    accident_id = step3_json["accident_id"]

    cached_contents = caching.CachedContent.list()

    cache_flg = 0

    for content in cached_contents:
        print(content)
        # content.display_nameとaccident_idを比較
        if content.display_name == accident_id:
            cache = content
            cache_flg = 1

    if cache_flg == 0:
        cache = context_cache(accident_id)

    model1 = genai.GenerativeModel.from_cached_content(cached_content=cache,generation_config=generation_config1, safety_settings=safety_settings)
    model2 = genai.GenerativeModel.from_cached_content(cached_content=cache,generation_config=generation_config2, safety_settings=safety_settings)


    prompt = """
    交通事故のドライブレコーダー動画が渡されます。
    ドライブレコーダーを搭載している車をA車、事故の相手をB車として、事実のみ箇条書きで教えてください。

    ＜車同士がぶつかった場所の状況を記載すること＞
    ・事故の場所：交差点（十字路）、Ｔ字路（丁字路）、直線、道路外進入

    判断する順番は以下の通りです。
    １．衝突が起きた場所の道路の状況を確認
    ２．ドライブレコーダーを搭載している車の動きを確認
    ３．衝突した相手の車の動きを確認
    ４．道路標識が存在するか
    ５．道路標示が存在するか

    ・十字路交差点(四つ角、交差道路)
        - 4つの道路がほぼ同じ角度で交わっているため、道路の接続数も確認すること
        - 2本の道路がほぼ直角に交わる十字の形をしているため、道路の形状も確認すること
        - 交差点クロスマークが交差点にある場合は十字路交差点と判断すること
        - 他車両が反対車線や対向車線を走っている場合、道路が見え辛い可能性もあるので、より正確な形状を確認すること
        - 丁字路(T字路)のように見える箇所もあるので、より正確な形状を確認し、十字路を判断すること

    ・丁字路(T字路)交差点
        - 3つの道路がT字型に交わっているため、道路の接続数と形状も確認すること
        - 交差点Tマークが交差点にある場合は丁字路(T字路)交差点と判断すること
        - 十字路のように見える箇所もあるので、より正確な形状を確認し、丁字路(T字路)を判断すること
        - A車とB車がともに丁字路(T字路)交差点の直進路を走行している場合は直線道路(曲線道路も含む)を選択すること

    ・直線道路(曲線道路も含む)
        - 他道路との交わりはないため、道路の接続数と形状も確認すること
        - 信号はないため、街灯を信号機と間違えないようにすること
        - 丁字路(T字路)のように見える箇所もあるので、より正確な形状を確認し、直線道路を判断すること
        - 十字路のように見える箇所もあるので、より正確な形状を確認し、直線道路を判断すること
        - A車とB車がともに丁字路(T字路)交差点の直進路を走行している場合は直線道路(曲線道路も含む)を選択すること

    ・道路外入出
        - A車とB車の片方が道路外から侵入、もしくは道路外に退出する
        - 信号はないため、街灯を信号機と間違えないようにすること
        - 道路と道路外の境界には車道外側線があることが多いため、それを正確に確認して、道路外を判断すること
    """


    request = []
    request.append(prompt)

    history2 = []
    history2.append({'role':'user', 'parts': request})
    history2.append({'role':'model','parts': step3_json["step2_param"]["basic_judgment_items1"]})

    prompt2 = """
    続いて、以下の内容を答えてください。

    信号の有無（有 or 無）
    契約者と相手方の車線関係（直行車線、直線路と突き当たり路、同一車線、道路外出入、反対車線）
    契約者の走行方向（直進、右折、左折、転回）
    相手方の走行方向（直進、右折、左折、転回）
    相手方から見た契約者の位置（前方、後方、左方、右方）
    契約者から見た相手方の位置（前方、後方、左方、右方）
    道路の優先関係（無、一方が一時停止規制、一方が広い、一方が優先道路、同幅員）

    """

    request2 = []
    request2.append(prompt2)

    history2.append({'role':'user', 'parts': request2})
    history2.append({'role':'model', 'parts': step3_json["step2_param"]["basic_judgment_items2"]})

    prompt3 = """
    続いて、以下の内容を答えてください。
    回答は以下の順番で、順番を入れ替えないでください。
    A車、B車それぞれの状況を出力すること。

    01.車両の種類 : 緊急車両、緊急車両以外
    02.信号の色:  青、赤、黄
    03.一方通行違反 : あり、なし
    04.一方道路車両用信号 : あり（赤色）、あり（赤色以外）、なし
    05.押しボタン式歩行者信号 : あり（青色）、あり（青色以外）、なし
    06.センターオーバー : あり、なし
    07.追越 : あり、なし
    08.追越禁止 : あり、なし
    09.右折前挙動 : 中央寄り、それ以外
    10.左折前挙動 : 左端寄り、 それ以外
    11.進路変更 : あり、なし
    12.道路交通法24条違反 : あり、なし
    """

    request3 = []
    request3.append(prompt3)

    history2.append({'role':'user', 'parts': request3})

    # 推論の実行
    response_step1 = model1.generate_content(
        history2
    )

    history2.append({'role':'user', 'parts': request3})
    history2.append({'role':'model', 'parts': response_step1.text})
    detail_table = response_step1.text

    file_path = '3prompt.txt'
    with open(file_path, 'r', encoding='utf-8') as file:
        prompt = file.read()


    history2.append({'role':'user','parts':prompt})
    response = model2.generate_content(history2)
    result2 = response.text
    history2.append({'role':'model', 'parts': result2})


    # 目次一覧
    file_path = '3hanrei.txt'
    with open(file_path, 'r', encoding='utf-8') as file:
        hanrei = file.read()


    query2 = f"""
    これまでの事故の状況から、与えられた交通事故判例の判例番号がどれになるか３つ候補を挙げてください。

    事故の状況：
    {result2}

    ## 交通事故判例一覧
    {hanrei}

    """


    result3 = model2.generate_content(query2).text
    # 文字列をリストに変換
    data_list = ast.literal_eval(result3)

    # 判例番号を大項目の一致する項目の降順に並べる
    result_hanrei = hanrei_descend(step3_json,data_list)
    step3_para = str(result_hanrei)
    response_step3 = response_step1.text
    filename = "response_step3.txt"  # Change filename if needed
    with open(filename, "w", encoding="utf-8") as f:
        f.write(response_step3)

    data = result_hanrei
    numbers_list = []
    for item in data:
        number = item['判例番号']
        numbers_list.append(str(number))
    scenario_json = numbers_list
    print("Scenarios_json", scenario_json)
    scenarios_format = [re.sub(r'【+|】+','',scenario) for scenario in scenario_json]
    scenarios_format = [f'【{scenario}】' for scenario in scenarios_format]
    print("scenario_format", scenarios_format)

#Map data from car_car.csv file
    csv_path = 'car_car.csv'
    df = pd.read_csv(csv_path)
    df = df.replace({np.nan:None})  #Replace NaNs *before* filtering.  Crucial for correct matching.

    # Ensure the first column is treated as strings for exact matching
    df.iloc[:, 0] = df.iloc[:, 0].astype(str)  # Crucially important

    # Create an empty list to store the data in the desired order
    scenario_data = []

    # Iterate through the scenarios_format list and find matching rows in the DataFrame
    for scenario in scenarios_format:
        filtered_df = df[df.iloc[:, 0] == scenario]  # Use direct equality for exact matching
        if not filtered_df.empty:
            selected_columns = filtered_df.iloc[:, [0, 5, 6, 8, 9]]  # Select the desired columns
            scenario_data.extend(selected_columns.to_dict(orient="records"))  # Add results.  Use extend as filtered_df can have multiple rows for the same scenario.
        else:
            print(f"Warning: Scenario '{scenario}' not found in the CSV.") # Add a warning when a scenario is not found

    print("scenario_data:", scenario_data)  # Print the resulting data
        #print(scenario_data)
        #return (response_step1.text,str(result_hanrei),scenario_data)
    print(detail_table)
    return (scenario_data, detail_table)

    #return (response_step1.text,str(result_hanrei))

# process_gemini_step3({
#   "accident_id": "101_001",
#   "step2_param": {
#     "basic_judgment_items1": {"事故の場所": "交差点（十字路）"},
#     "basic_judgment_items2": {"信号の有無": False, "契約者から見た相手方の位置": "右方", "契約者と相手方の車線関係": "道路外出入", "契約者の走行方向": "直進", "相手方から見た契約者の位置": "左方", "相手方の走行方向": "右折", "道路の優先関係": "一方が優先道路"},
#     }
#   }
# )