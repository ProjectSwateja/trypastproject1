let globalvideo = 'abc';
let aCar = '';
let bCar = '';
let scenariosSorted = '';
document.addEventListener('DOMContentLoaded', function () {
  const accidentNumberElement = document.querySelector(
    '.data-table tr:first-child td'
  );
  const accidentNumber = accidentNumberElement
    ? accidentNumberElement.textContent
    : null;
  console.log('Accident no on navigation is', accidentNumber);

  if (!accidentNumber) {
    console.error('Could not find accident number in table.');
    return;
  }
  // const bloader = document.getElementById('bloader');
  const loader = document.getElementById('loader');
  const tableLoader = document.getElementById('tableLoader');
  const tableBody = document.getElementById('idTable');
  const idButton = document.getElementById('search');
  const scroller = document.getElementById('scroller');
  const scenarioText = document.getElementById('scenarioText');
  const radioButtonsContainer = document.getElementById('scenarioRadioButtons');
  const otherDropdown = document.getElementById('otherDropdown');
  const confirmationButton = document.getElementById('cofirmation');
  const car = document.getElementById('car');
  // const divTable = document.getElementById('detailstable');
  const detailsTable = document.getElementById('detailstable');

  const submitDetailsButton = document.getElementById('select-scenario');
  const selectedButton = document.getElementById('selected-scenario');
  const modLoader = document.getElementById('modifiers-loader');
  const basicFault = document.getElementById('basic-fault');
  const modHead = document.getElementById('modHead');
  const caseExp = document.getElementById('case-explanation');
  const modifiersTable = document.getElementById('modifiers-table');
  const reportLoader = document.getElementById('reportLoader');
  const finalReport = document.getElementById('final-report');
  const selected = document.getElementById('selected-sce');
  const videoPre = document.getElementById('video-preview');
  const summary = document.getElementById('acc-summary');
  const cause = document.getElementById('cause');
  const timestamp = document.getElementById('timestamp');
  // const faultBasic = document.getElementById('basic-fault');
  const modifiers = document.getElementById('modifiers');
  const generateReport = document.getElementById('generate-report');
  tableLoader.style.display = 'block';
  tableBody.style.display = 'none';
  idButton.style.display = 'none';
  scroller.style.display = 'none';
  scenarioText.style.display = 'none';
  radioButtonsContainer.style.display = 'none';
  otherDropdown.style.display = 'none';
  car.style.display = 'none';
  // divTable.style.display = 'none';
  finalReport.style.display = 'none';
  selected.style.display = 'none';
  videoPre.style.display = 'none';
  summary.style.display = 'none';
  cause.style.display = 'none';
  timestamp.style.display = 'none';
  // faultBasic.style.display = 'none';
  modifiers.style.display = 'none';
  detailsTable.style.display = 'none';
  confirmationButton.style.display = 'none';
  submitDetailsButton.style.display = 'none';
  modLoader.style.display = 'none';
  basicFault.style.display = 'none';
  selectedButton.style.display = 'none';
  modHead.style.display = 'none';
  modifiersTable.style.display = 'none';
  generateReport.style.display = 'none';
  reportLoader.style.display = 'none';

  fetch('/get-identifiers-data', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ data: [accidentNumber] }), // Send accident number to backend
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error('ネットワーク応答が正常ではありませんでした');
      }
      return response.json();
    })
    .then((data) => {
      const firstColumn = [
        '事事故発生の場所',
        '信号の有無',
        '契約者と相手方の車線関係',
        '契約者と相手方の走行方向',
        '相手方と契約者の走行方向',
        '相手方から見た契約者の位置',
        '契約者から見た相手方の位置',
        '道路の優先関係',
      ];

      const radioButtonstext = [
        ['十字路', '丁字路', '道路外進入', '直線道路'],
        ['有', '無'],
        [
          '直行車線',
          '直線路と突き当たり路',
          '同一車線',
          '道路外出入',
          '反対車線',
        ],
        ['直進', '右折', '左折', '転回'],
        ['直進', '右折', '左折', '転回'],
        ['前方', '後方', '左方', '右方'],
        ['前方', '後方', '左方', '右方'],
        ['無', '一方が一時停止規制', '一方が広い', '一方が優先道路', '同幅員'],
      ];

      data.forEach((secondColumn, index) => {
        const tr = document.createElement('tr');
        let radioButtons = '';

        radioButtonstext[index].forEach((text, radioIndex) => {
          const isChecked = secondColumn === text ? 'checked' : '';
          radioButtons += `<input type="radio" name="row-${index}" value="${text}" ${isChecked} > ${text}`;
        });

        tr.innerHTML = `
              <td>${firstColumn[index]}</td>
              <td>${secondColumn}</td>
              <td>${radioButtons}</td>`;

        tableBody.appendChild(tr);
        tableLoader.style.display = 'none';
        tableBody.style.display = 'block';
        idButton.style.display = 'block';

        tr.querySelectorAll(`input[name="row-${index}"]`).forEach(
          (radioButton) => {
            radioButton.addEventListener('change', (event) => {
              tr.children[1].innerText = event.target.value;
            });
          }
        );
      });
    })
    .catch((error) => {
      console.error('Error fetching data', error);
    });

  idButton.addEventListener('click', function () {
    loader.style.display = 'block';
    scroller.style.display = 'none';
    radioButtonsContainer.style.display = 'none';
    otherDropdown.style.display = 'none';
    car.style.display = 'none';
    // divTable.style.display = 'none';
    // detailsTable.style.display = 'none';
    // confirmScenarioButton.style.display = 'none';

    const updatedData = [];
    document.querySelectorAll('#idTable tr').forEach((row) => {
      const firstColumnValue = row.children[0].textContent.trim();
      const secondColumnvalue = row.children[1].textContent.trim();
      updatedData.push({ key: firstColumnValue, value: secondColumnvalue });
    });

    fetch('/process_video', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ updatedData: updatedData }),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('Failed to fetch scenario !');
        }
        return response.json();
      })
      .then((data) => {
        populateScenarios(data.scenarios, data.dropdownOptions);
        confirmationButton.style.display = 'block';
        const scenariosSorted = data.scenarios;
        console.log('Sorted scenarios', scenariosSorted);
        loader.style.display = 'none';
        scroller.style.display = 'block';
        scenarioText.style.display = 'block';
        radioButtonsContainer.style.display = 'block';
        otherDropdown.style.display = 'block';
        car.style.display = 'block';

        // cofirmScenarioButton.style.display = 'block';
      });
  });

  function populateScenarios(scenarios, dropdownOptions) {
    console.log(scenarios);

    radioButtonsContainer.innerHTML = ''; // Clear previous buttons

    const otherLabel = document.createElement('label');
    otherLabel.style.display = 'block';
    otherLabel.style.marginBottom = '10px';

    const otherOption = document.createElement('input');
    otherOption.type = 'radio';
    otherOption.name = 'scenario';
    otherOption.value = 'その他';
    otherOption.id = 'otherOption'; // Add an id for easier access later

    otherLabel.appendChild(otherOption);
    otherLabel.appendChild(document.createTextNode(' その他'));

    const dropdown = document.createElement('select');
    dropdown.id = 'scenarioDropdown';

    const otherDropdownContainer = document.createElement('div');
    otherDropdownContainer.style.display = 'none';
    otherDropdownContainer.style.marginLeft = '40px';
    otherDropdownContainer.style.marginTop = '5px';

    const dropdownLabel = document.createElement('label');
    dropdownLabel.textContent =
      'ドロップダウンから正しいシナリオ番号を選択してください:';
    dropdownLabel.style.display = 'block';
    dropdown.style.marginBottom = '10px';

    otherDropdownContainer.appendChild(dropdownLabel);
    otherDropdownContainer.appendChild(dropdown);

    otherLabel.appendChild(otherDropdownContainer);

    radioButtonsContainer.appendChild(otherLabel);

    const table = document.createElement('table');
    table.style.width = '100%';
    table.style.borderCollapse = 'collapse';

    let row;
    scenarios.forEach((scenario, index) => {
      if (index % 3 === 0) {
        row = document.createElement('tr');
        table.appendChild(row);
      }
      const cell = document.createElement('td');
      cell.style.padding = '10px';
      cell.style.textAlign = 'center';
      cell.style.verticalAlign = 'top';
      cell.style.border = '1px solid #ddd';

      const label = document.createElement('label');
      label.style.display = 'block'; // Ensure label is displayed vertically
      label.style.cursor = 'pointer';

      const radioButton = document.createElement('input');
      radioButton.type = 'radio';
      radioButton.name = 'scenario';
      radioButton.value = scenario['判例番号'];

      const description = document.createElement('div');
      description.innerHTML = ` 
                <p>${scenario['区分５']}</p>
                ${scenario['区分６'] ? `<p>${scenario['区分６']}</p>` : ''}
                <p><strong>A車: </strong> ${
                  scenario['A車']
                } <strong>B車: </strong>${scenario['B車']}</p>
                <p> </p>
            `;

      const image = document.createElement('img');

      // image.src = `/static/images/${radioButton.value}.png`;
      image.src = `/static/images/${radioButton.value.replace(
        /[【】]/g,
        ''
      )}.png`;
      // image.onerror = function () {
      //   image.src = `/static/images/dummy.png`;
      // };
      image.style.width = '250px';
      image.style.marginTop = '10px';

      label.appendChild(radioButton);
      label.appendChild(document.createTextNode(` ${scenario['判例番号']} `));
      label.appendChild(description); // Append the description div
      const imageContainer = document.createElement('div');
      imageContainer.style.clear = 'both';
      imageContainer.appendChild(image);
      label.appendChild(imageContainer);
      cell.appendChild(label);
      row.appendChild(cell);
    });
    radioButtonsContainer.appendChild(table);

    otherOption.addEventListener('change', function () {
      if (this.checked) {
        otherDropdownContainer.style.display = 'block';
        dropdown.innerHTML = '';

        dropdownOptions.forEach((option) => {
          const optionElement = document.createElement('option');
          optionElement.value = option;
          optionElement.text = option;
          dropdown.appendChild(optionElement);
        });
      } else {
        otherDropdown.style.display = 'none';
      }
    });

    document.querySelectorAll('input[name="scenario"]').forEach((input) => {
      input.addEventListener('change', function () {
        if (this !== otherOption) {
          otherDropdown.style.display = 'none';
        }
      });
    });
  }
  const aCarSelect = document.getElementById('aCarSelect');
  const bCarValue = document.getElementById('bCarValue');
  const secondColumnHeader = document.getElementById('secondColumnHeader');
  const fourthColumnHeader = document.getElementById('fourthColumnHeader');
  function updateHeaders() {
    secondColumnHeader.textContent = aCarSelect.value;
    fourthColumnHeader.textContent = bCarValue.textContent;
  }
  updateHeaders();
  aCarSelect.addEventListener('change', function () {
    if (this.value === '契約者') {
      bCarValue.textContent = '相手方';
    } else {
      bCarValue.textContent = '契約者';
    }
    updateHeaders();
  });

  // secondColumnHeader.textContent = this.value;
  // fourthColumnHeader.textContent = bCarValue.textContent;

  confirmationButton.addEventListener('click', function () {
    // car.style.display = 'block';
    // divTable.style.display = 'block';
    detailsTable.style.display = 'block';
    submitDetailsButton.style.display = 'block';
    modLoader.style.display = 'none';

    let selectedScenario = document.querySelector(
      'input[name="scenario"]:checked'
    );
    if (selectedScenario) {
      selectedScenario = selectedScenario.value;
    } else {
      console.error('No scenario selected');
      return;
    }
    // if 'その他' is selcted get value from dropdown
    if (selectedScenario === 'その他') {
      const dropdown = document.getElementById('scenarioDropdown');
      selectedScenario = dropdown ? dropdown.value : null;
    }
    console.log('Selected Scenario:', selectedScenario);

    const tablebody = document.getElementById('tables-body');
    fetch('/details_table', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        data: [accidentNumber],
        selectedScenario: selectedScenario,
      }), // Send accident number to backend
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('ネットワーク応答が正常ではありませんでした');
        }
        return response.json();
      })
      .then((data) => {
        console.log('Selected scenario sent successfully', selectedScenario);
        console.log('first column data', data.first_column);
        console.log('second column data', data.second_column);
        console.log('fourth column data', data.fourth_column);
        console.log('Editable rows', data.editable_rows);
        const thirdColumnOptions = [
          ['緊急車両', '緊急車両以外'],
          ['青', '赤', '黄'],
          ['あり', 'なし'],
          ['あり(赤色)', 'あり(赤色以外)', 'なし'],
          ['あり', 'なし'],
          ['あり', 'なし'],
          ['あり', 'なし'],
          ['あり', 'なし'],
          ['中央寄り', 'それ以外'],
          ['左端寄り', 'それ以外'],
          ['あり', 'なし'],
          ['あり', 'なし'],
        ];

        const fifthColumnOptions = [
          ['緊急車両', '緊急車両以外'],
          ['青', '赤', '黄'],
          ['あり', 'なし'],
          ['あり(赤色)', 'あり(赤色以外)', 'なし'],
          ['あり', 'なし'],
          ['あり', 'なし'],
          ['あり', 'なし'],
          ['あり', 'なし'],
          ['中央寄り', 'それ以外'],
          ['左端寄り', 'それ以外'],
          ['あり', 'なし'],
          ['あり', 'なし'],
        ];

        tablebody.innerHTML = '';

        data.second_column.forEach((value, index) => {
          const tr = document.createElement('tr');

          // Check if row should be disabled
          const isEditable = data.editable_rows[index];

          const firstCol = document.createElement('td');
          firstCol.textContent = data.first_column[index];
          tr.appendChild(firstCol);

          const secondCol = document.createElement('td');
          secondCol.textContent = data.second_column[index];
          tr.appendChild(secondCol);
          console.log('......', secondCol);

          const thirdCol = document.createElement('td');
          thirdColumnOptions[index].forEach((option) => {
            const radio = document.createElement('input');
            radio.type = 'radio';
            radio.style.marginLeft = '10px';
            radio.style.marginRight = '2px';
            radio.name = `third-col-${index}`;
            radio.value = option;
            radio.checked = data.second_column[index] === option;
            // Disable if not editable
            radio.disabled = !isEditable;
            radio.addEventListener('change', function () {
              secondCol.textContent = this.value;
            });
            thirdCol.appendChild(radio);
            thirdCol.appendChild(document.createTextNode(`${option}`));
          });
          tr.appendChild(thirdCol);

          const fourthCol = document.createElement('td');
          fourthCol.textContent = data.fourth_column[index];
          tr.appendChild(fourthCol);

          const fifthCol = document.createElement('td');
          fifthColumnOptions[index].forEach((option) => {
            const radio = document.createElement('input');
            radio.type = 'radio';
            radio.style.marginLeft = '10px';
            radio.style.marginRight = '2px';
            radio.name = `fifth-col-${index}`;
            radio.value = option;
            radio.checked = data.fourth_column[index] === option;
            radio.disabled = !isEditable; // Disable if not editable
            radio.addEventListener('change', function () {
              fourthCol.textContent = this.value;
            });
            fifthCol.appendChild(radio);
            fifthCol.appendChild(document.createTextNode(`${option}`));
          });
          tr.appendChild(fifthCol);
          tablebody.appendChild(tr);
        });
      })
      .catch((error) => {
        console.error('Error fetching data', error);
      });
  });
  document.getElementById('userA').textContent = aCar;
  document.getElementById('userB').textContent = bCar;
  submitDetailsButton.addEventListener('click', function () {
    modLoader.style.display = 'block';
    const tableRows = document.querySelectorAll('#tables-body tr');
    let detailData = {};
    tableRows.forEach((row, index) => {
      const firstColumn = row.cells[0]?.textContent.trim();
      const secondColumn = row.cells[1]?.textContent.trim() || '';
      const fourthColumn = row.cells[3]?.textContent.trim() || '';
      detailData[firstColumn] = { A: secondColumn, B: fourthColumn };
    });
    console.log('formatted details data', detailData);
    const selectedRadio = document.querySelector(
      'input[name="scenario"]:checked'
    );
    const aCar = aCarSelect.value; // Basic A value
    const bCar = bCarValue.textContent; // Basic B value
    const scenarioValue = selectedRadio.value;
    const descriptionDiv = selectedRadio.parentElement.querySelector('div');
    let description = descriptionDiv
      ? descriptionDiv.innerHTML
      : 'No description';
    description = description.replace(/A車/g, aCar).replace(/B車/g, bCar);

    console.log('description', description);
    const imageSRC = selectedRadio.parentElement.querySelector('img').src;
    selectedButton.innerHTML = `
        <p><strong>${scenarioValue}</strong></p>
        <p>${description}</p>
        <img src="${imageSRC}" style="width: 150px; margin-top: 10px; align-items: center">`;
    selectedButton.style.display = 'block';

    // for basic faults values in HTML
    userA.textContent = aCar;
    userB.textContent = bCar;
    // let aCar = 20;
    // let bCar = 80;
    console.log(' Car A Id: ', aCar);
    console.log('Car B Id:', bCar);

    fetch('/confirm_scenario', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ aCar: aCar, bCar: bCar, detailData: detailData }),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('Errorrrrrrrrrrrrrrr');
        }
        return response.json();
      })
      .then((data) => {
        console.log('Modifiers Data', data.modification_answer);
        console.log('basic Fault A:', data.car_a_fault);
        console.log('basic Fault B:', data.car_b_fault);
        let basicA = data.car_a_fault;
        let basicB = data.car_b_fault;
        let case_explanation = data.case_explanation;

        modLoader.style.display = 'none';
        basicFault.style.display = 'block';
        modHead.style.display = 'block';
        modifiersTable.style.display = 'block';
        generateReport.style.display = 'block';

        document.querySelector(
          '.case-info-container .basic-fault tr:nth-child(1) td:nth-child(2)'
        ).textContent = basicA;
        document.querySelector(
          '.case-info-container .basic-fault tr:nth-child(2)  td:nth-child(2)'
        ).textContent = basicB;

        caseExp.innerHTML = `<h3>判例説明：</h3><br><p>${case_explanation}</p>`;
        let tableBody = document.getElementById('modtablebody');

        tableBody.innerHTML = '';
        let totalA = 0;
        let totalB = 0;

        document.querySelector(
          '#modifiers-table thead tr th:nth-child(4)'
        ).textContent = aCar;
        document.querySelector(
          '#modifiers-table thead tr th:nth-child(5)'
        ).textContent = bCar;

        data.modification_answer.forEach((row) => {
          let aCarValue = parseInt(row.数値) || 0;
          let bCarValue = aCarValue * -1;

          let newRow = tableBody.insertRow();
          let aiOutputCell = document.createElement('td');
          aiOutputCell.textContent = row.AI出力結果;

          let carACell = document.createElement('td');
          carACell.classList.add('car-a');
          carACell.textContent = row.AI出力結果 === '〇' ? aCarValue : '';

          let carBCell = document.createElement('td');
          carBCell.classList.add('car-b');
          carBCell.textContent = row.AI出力結果 === '〇' ? bCarValue : '';

          let dropdownCell = document.createElement('td');
          let dropdown = document.createElement('select');
          dropdown.classList.add('adjustment-dropdown');

          if (row.AI出力結果 === '✕') {
            dropdown.innerHTML = `<option value="-">-</option><option value="〇">〇</option>`;
          } else {
            dropdown.innerHTML = `<option value="-">-</option><option value="✕">✕</option>`;
          }
          dropdown.value = '-';
          dropdownCell.appendChild(dropdown);

          let reasonCell = document.createElement('td');
          reasonCell.classList.add('user-reason');
          reasonCell.style.width = 'fit-content';
          reasonCell.textContent = row.該当理由;
          reasonCell.contentEditable = 'false';

          dropdown.addEventListener('change', function () {
            if (!reasonCell.dataset.originalReason) {
              reasonCell.dataset.originalReason = row.該当理由;
            }
            if (dropdown.value === '〇' || dropdown.value === '✕') {
              carACell.textContent = dropdown.value === '〇' ? aCarValue : '';
              carBCell.textContent = dropdown.value === '〇' ? bCarValue : '';
              reasonCell.contentEditable = 'true';
              reasonCell.classList.add('mandatory');
              // reasonCell.textContent = '訂正理由を入力してください'; // Add placeholder text
              reasonCell.style.border = '1px solid red'; // Highlight the cell
              // reasonCell.style.backgroundColor = '#ffe6e6'; // Light red background
            } else {
              carACell.textContent = '';
              carBCell.textContent = '';
              reasonCell.contentEditable = 'false';
              reasonCell.classList.remove('mandatory');
              reasonCell.textContent = reasonCell.dataset.originalReason || '';
              // reasonCell.textContent = '';
              reasonCell.style.border = ''; // Remove highlight
              reasonCell.style.backgroundColor = '';
            }

            updateTotals(basicA, basicB);

            // Remove placeholder and highlight when user starts typing
            reasonCell.addEventListener('focus', function () {
              reasonCell.classList.remove('error');

              reasonCell.textContent = '';

              reasonCell.style.border = '1px solid black';

              reasonCell.style.backgroundColor = '';
            });
          });

          newRow.appendChild(document.createElement('td')).textContent =
            row.修正要素内容;
          newRow.appendChild(document.createElement('td')).textContent =
            row.数値;
          newRow.appendChild(aiOutputCell);
          newRow.appendChild(carACell);
          newRow.appendChild(carBCell);
          newRow.appendChild(dropdownCell);
          newRow.appendChild(reasonCell);

          tableBody.appendChild(newRow);
        });

        // Last three rows
        let stat1 = tableBody.insertRow();
        stat1.innerHTML = `<td colspan="3">修正要素内容</td>
            <td id="totalA">0</td>
            <td id="totalB">0</td>`;

        let stat2 = tableBody.insertRow();
        stat2.innerHTML = `<td colspan="3">過失割合</td>
            <td id="faultA"></td>
            <td id="faultB"></td>`;

        let stat3 = tableBody.insertRow();
        stat3.innerHTML = `<td colspan="3">ユーザー調整</td>
            <td contenteditable="true" id="userFaultA"></td>
            <td contenteditable="true" id="userFaultB"></td>
            <td colspan="2" contenteditable="false" id="reason"></td>`;

        document
          .getElementById('userFaultA')
          .addEventListener('input', enableUserEdits);
        document
          .getElementById('userFaultB')
          .addEventListener('input', enableUserEdits);

        updateTotals(basicA, basicB); // Initialize totals
      })
      .catch((error) => console.log('Error sending to backend', error));
  });

  function updateTotals(basicA, basicB) {
    let totalA = 0;
    let totalB = 0;

    document.querySelectorAll('.car-a').forEach((cell) => {
      totalA += parseInt(cell.textContent) || 0;
    });

    document.querySelectorAll('.car-b').forEach((cell) => {
      totalB += parseInt(cell.textContent) || 0;
    });

    let faultA = Math.max(0, basicA + totalA);
    let faultB = Math.min(100, 100 - faultA);

    document.getElementById('totalA').textContent = totalA;
    document.getElementById('totalB').textContent = totalB;

    // Update Fault A and Fault B based on the formula
    // let faultA = basicA + totalA;
    // // let faultA = basicA + totalA;
    // let faultB = 100 - faultA;

    document.getElementById('faultA').textContent = faultA;
    document.getElementById('faultB').textContent = faultB;
  }

  function enableUserEdits() {
    let faultA = document.getElementById('userFaultA').textContent.trim() || 0;
    let faultB = document.getElementById('userFaultB').textContent.trim() || 0;
    let reason = document.getElementById('reason');

    if (faultA && faultB) {
      reason.contentEditable = 'true';
      reason.classList.add('mandatory');
      reason.textContent = '訂正理由を入力してください'; // Add placeholder text
      reason.style.border = '2px solid red';
      reason.style.border = '1px solid red';

      reason.addEventListener('focus', function () {
        reason.classList.remove('error');
        reason.textContent = '';
        reason.style.border = 'black';
        reason.style.backgroundColor = '';
      });
    } else {
      reason.contentEditable = 'false';
      reason.classList.remove('mandatory');
      reason.textContent = ''; // Add placeholder text
      reason.style.border = '1px solid black';
    }
  }

  generateReport.addEventListener('click', function () {
    reportLoader.style.display = 'block';
    finalReport.style.display = 'none';
    let valid = true;
    document.querySelectorAll('.mandatory').forEach((reasonCell) => {
      if (
        reasonCell.textContent.trim() === '' ||
        reasonCell.textContent === '訂正理由を入力してください'
      ) {
        reasonCell.textContent = '訂正理由を入力してください';

        reasonCell.style.border = '1px solid red';
        valid = false;
      } else {
        reasonCell.style.color = 'black';
      }
    });
    document.querySelectorAll('.mandatory').forEach((reason) => {
      if (
        reason.textContent.trim() === '' ||
        reason.textContent === '訂正理由を入力してください'
      ) {
        reason.textContent = '訂正理由を入力してください';
        reason.style.border = '1px solid red';
        valid = false;
      } else {
        reason.style.color = '1px solid black';
      }
      reason.addEventListener('focus', function () {
        reason.classList.remove('error');
        reason.textContent = '';
        reason.style.border = 'black';
        reason.style.backgroundColor = '';
      });
    });
    if (!valid) {
      alert('修正理由をすべて入力してください');
      return;
    }

    let tablerows = document.querySelectorAll('#modtablebody tr');
    let rowDataArray = [];
    console.log('going goood');
    for (let i = 0; i < tablerows.length - 3; i++) {
      let cells = tablerows[i].children;
      rowDataArray.push({
        修正要素内容: cells[0].textContent.trim(),
        数値: cells[1].textContent.trim(),
        AI出力結果: cells[2].textContent.trim(),
        CarA: cells[3].textContent.trim(),
        CarB: cells[4].textContent.trim(),
        訂正: cells[5].querySelector('select')?.value || '',
        該当理由: cells[6].textContent.trim(),
      });
    }
    console.log('modification from user', rowDataArray);

    let stat3 = document.getElementById('userFaultA');
    let userFaultA = stat3?.textContent.trim();
    let userFaultB = document.getElementById('userFaultB')?.textContent.trim();
    let userReason = document.getElementById('reason')?.textContent.trim();
    let rowData;
    if (userFaultA && userFaultB) {
      rowData = {
        faultA: userFaultA,
        faultB: userFaultB,
        reason: userReason,
      };
    } else {
      rowData = {
        faultA: document.getElementById('faultA')?.textContent.trim(),
        faultB: document.getElementById('faultB')?.textContent.trim(),
      };
    }
    fetch('/fault_calculation', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rowData: rowData, modData: rowDataArray }),
    })
      .then((response) => response.json())
      .then((data) => {
        reportLoader.style.display = 'none';
        console.log('Fault values submitted successfully', data);
        console.log('basic fault', data.formattedA);
        console.log('basic fault B', data.formattedB);
        console.log('accident_summary', data.accident_summary);
        console.log('potential cause', data.potential_cause);

        let basicFaultAKey = Object.keys(data.formattedA)[0];
        let basicFaultA = data.formattedA[basicFaultAKey];
        let basicFaultBKey = Object.keys(data.formattedB)[0];
        let basicFaultB = data.formattedB[basicFaultBKey];
        let accidentSummary = data.accident_summary;
        let potentialCause = data.potential_cause;
        let aCar = data.aCar;
        let bCar = data.bCar;

        finalReport.style.display = 'block';
        const selectedRadio = document.querySelector(
          'input[name="scenario"]:checked'
        );
        const descriptionDiv = selectedRadio.parentElement.querySelector('div');
        const scenarioValue = selectedRadio.value;
        let description = descriptionDiv
          ? descriptionDiv.innerHTML
          : 'No description';
        description = description.replace(/A車/g, aCar).replace(/B車/g, bCar);
        // description = description.replace(/A車/g, aCar).replace(/B車/g, bCar);

        console.log('description', description);

        // const descriptionDiv = selectedRadio.parentElement.querySelector('div');
        // const description = descriptionDiv
        //   ? descriptionDiv.innerHTML
        //   : 'No description';
        // console.log('desc', description);
        // description = description.replace(/A車/g, aCar).replace(/B車/g, bCar);
        const imageSRC = selectedRadio.parentElement.querySelector('img').src;
        selected.innerHTML = `
        <p><strong>${scenarioValue}</strong></p>
        <p>${description}</p>
        <img src="${imageSRC}" style="width: 150px; margin-top: 10px; align-items: center">`;
        selected.style.display = 'block';
        videoPre.innerHTML = `
      <div class="video-finalreport">
        <video controls id="myVideofinalreport" style="width: 100%; height: auto; margin-top: 10px ">
          <source src="${globalvideo}" type="video/mp4" id="finalvideoSource" />
        </video>
      </div> 
    `;
        const video = document.getElementById('myVideofinalreport');
        video.load();
        videoPre.style.display = 'block';
        summary.innerHTML = `<h3>事故概要:</h3><br><p>${accidentSummary}</p>`;
        summary.style.display = 'block';
        cause.innerHTML = `<h3>事故原因:</h3><br><p>${potentialCause}</p>`;
        cause.style.display = 'block';
        timestamp.innerHTML = `<h3>基本割合:</h3><br><p>${basicFaultAKey}: ${basicFaultA}</p><p>${basicFaultBKey}:${basicFaultB}</p>`;
        timestamp.style.display = 'block';
        // faultBasic.innerHTML = `基本割合:`;
        // faultBasic.style.display = 'block';
        modifiers.innerHTML = `<h3>修正要素:</h3>`;
        // reportTable.border = 1;
        let finalTable = document.createElement('table');
        finalTable.id = 'finalTable';
        finalTable.classList.add('style-table');
        let finalTableBody = document.createElement('tbody');
        let headerRow = document.createElement('tr');
        headerRow.innerHTML = `
    <th style="width: 30%">修正要素</th>
    <th style="width: 10%">数値</th>
    <th style="width: 10%">${basicFaultAKey}</th>
    <th style="width: 10%">${basicFaultBKey}</th>
    <th style="width: 40%">該当理由</th>
    `;
        finalTable.appendChild(headerRow);
        let rows = document.querySelectorAll('#modtablebody tr');
        let totalrows = rows.length;
        rows.forEach((row, index) => {
          if (index >= totalrows - 3) return;
          let newrow = document.createElement('tr');
          let 修正要素 = row.cells[0]?.textContent || '-';
          let 数値 = row.cells[1]?.textContent || '-';
          let A車 = row.cells[3]?.textContent || '-';
          let B車 = row.cells[4]?.textContent || '-';
          let 該当理由 = row.cells[6]?.textContent || '-';

          newrow.innerHTML = `
      <td>${修正要素}</td>
      <td>${数値}</td>
      <td>${A車}</td>
      <td>${B車}</td>
      <td>${該当理由}</td>`;
          finalTableBody.appendChild(newrow);
        });
        let finaluserfaultA =
          document.getElementById('userFaultA')?.textContent || '';
        let finaluserfaultB =
          document.getElementById('userFaultB')?.textContent || '';
        let finalreason = document.getElementById('reason')?.textContent || '';
        // let finalfaultA = userfaultA !== '' ? userfaultA : '0';
        // let finalfaultB = userfaultB !== '' ? userfaultA : '0';
        // let finalreason = reason !== '' ? reason : '-';
        let stat1 = document.createElement('tr');
        stat1.innerHTML = `<td colspan="2">修正要素内容</td>
            <td id="finaltotalA">${
              document.getElementById('totalA').textContent
            }</td>
            <td id="finaltotalB">${
              document.getElementById('totalB').textContent
            }</td>`;
        let stat2 = document.createElement('tr');
        stat2.innerHTML = `<td colspan="2">過失割合</td>
            <td id="finalfaultA">${
              document.getElementById('faultA').textContent
            }</td>
            <td id="finalfaultB">${
              document.getElementById('faultB').textContent
            }</td>
            <td colspan="2"></td>`;
        let static3 = document.createElement('tr');
        static3.innerHTML = `<td colspan="2">ユーザー調整</td>
            <td id="finaluserFaultA">${finaluserfaultA}</td>
            <td id="finaluserFaultB">${finaluserfaultB}</td>
            <td id="finalreason">${finalreason}</td>`;
        finalTableBody.appendChild(stat1);
        finalTableBody.appendChild(stat2);
        finalTableBody.appendChild(static3);

        finalTable.appendChild(finalTableBody);
        modifiers.appendChild(finalTable);
        modifiers.style.display = 'block';
      })
      .catch((error) => console.log('Error submitting fault values', error));
  });
});

document.addEventListener('DOMContentLoaded', () => {
  const imagedownloadButton = document.getElementById('imagedownloadButton');
  const videodownloadButton = document.getElementById('videodownloadButton');
  const bloader = document.getElementById('bloader');
  const vloader = document.getElementById('vloader');

  imagedownloadButton.addEventListener('click', async () => {
    bloader.style.display = 'block';
    // Get the accident number from the table cell
    const accidentNumberElement = document.querySelector(
      '.data-table tr:first-child td'
    );
    const accidentNumber = accidentNumberElement
      ? accidentNumberElement.textContent
      : null;

    console.log(accidentNumber);
    if (!accidentNumber) {
      console.error('Could not find accident number in table.');
      return;
    }

    try {
      const response = await fetch('/download_images', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ data: [accidentNumber] }), // Send accident number to backend
      });

      if (response.ok) {
        const result = await response.json();
        if (result.status === 'success') {
          bloader.style.display = 'none';
          console.log('Download started with accident number:', accidentNumber);
          window.location.href = `/download_file?filename=${result.filename}`;
        } else {
          console.error('Error from backend', result.message);
        }
      } else {
        console.error('Error sending data to backend:', response.statusText);
      }
    } catch (error) {
      console.error('Error while making request:', error);
    }
  });
  videodownloadButton.addEventListener('click', async () => {
    vloader.style.display = 'block';
    // Get the accident number from the table cell
    const accidentNumberElement = document.querySelector(
      '.data-table tr:first-child td'
    );
    const accidentNumber = accidentNumberElement
      ? accidentNumberElement.textContent
      : null;

    console.log(accidentNumber);
    if (!accidentNumber) {
      console.error('Could not find accident number in table.');
      return;
    }

    try {
      const response = await fetch('/download_video', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ data: [accidentNumber] }), // Send accident number to backend
      });

      if (response.ok) {
        const result = await response.json();
        if (result.status === 'success') {
          vloader.style.display = 'none';
          console.log('Download started with accident number:', accidentNumber);
          window.location.href = `/download_file?filename=${result.filename}`;
        } else {
          console.error('Error from backend', result.message);
        }
      } else {
        console.error('Error sending data to backend:', response.statusText);
      }
    } catch (error) {
      console.error('Error while making request:', error);
    }
  });
});

const accidentNumberElement = document.querySelector(
  '.data-table tr:first-child td'
);
const accidentNumber = accidentNumberElement
  ? accidentNumberElement.textContent
  : null;

// Construct the video URL dynamically
if (accidentNumber) {
  const videoId = accidentNumber; // Use the accident number as the video ID
  const baseUrl = 'https://storage.googleapis.com/video-preview-public/'; // Replace with your base URL (e.g., "videos/")

  const videoExtension = '.mp4'; // Replace with your video extension if needed

  const videoUrl = baseUrl + videoId + '/' + videoId + videoExtension;
  globalvideo = videoUrl;
  // Update the video source in the HTML
  const videoSource = document.getElementById('videoSource');
  videoSource.src = videoUrl;

  // Load the new video source
  const video = document.getElementById('myVideo');
  video.load();
} else {
  console.error('Could not find accident number to create video URL.');
}
