document.addEventListener('DOMContentLoaded', function () {
  // Fetch and populate existing data
  fetch('/data')
    .then((response) => response.json())
    .then((data) => {
      const tableBody = document.getElementById('accidentTableBody');
      if (tableBody) {
        data.forEach((row) => {
          addRowToTable(row);
        });
      }
    });

  // Add new row and send to backend on form submission
  const userform = document.getElementById('userform');
  if (userform) {
    document
      .getElementById('userform')
      .addEventListener('submit', function (event) {
        event.preventDefault();
        const accidentNumber = document.getElementById('accidentNumber').value;
        const dateOfAccident = document.getElementById('dateOfAccident').value;
        const name = document.getElementById('name').value;
        const registrationNumber =
          document.getElementById('registrationNumber').value;

        const newRow = {
          accidentNumber: accidentNumber,
          dateOfAccident: dateOfAccident,
          name: name,
          registrationNumber: registrationNumber,
        };

        fetch('/add', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(newRow),
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.status === 'success') {
              addRowToTable([
                accidentNumber,
                dateOfAccident,
                name,
                registrationNumber,
                'なし',
                '未',
                '',
              ]);
              document.getElementById('userform').reset();
            } else if (data.status === 'Error') {
              alert(
                'この事故IDの記録が既に存在する場合は、固有の事故IDを入力してください。'
              );
            }
          })
          .catch((error) => {
            console.log('Error', error);
            alert('Ann eror while adding data');
          });
      });
  }
});

function addRowToTable(row) {
  const tableBody = document.getElementById('accidentTableBody');
  const accidentNumber = row[0];
  const newRow = document.createElement('tr');
  newRow.id = `row${accidentNumber}`;
  newRow.innerHTML = `
        <td id="accidentNumberCell${accidentNumber}">
        ${
          row[4] === 'あり'
            ? `<a href= "/process/${accidentNumber}">${accidentNumber}</a>`
            : accidentNumber
        }</td>
        <td>${row[1]}</td>
        <td>${row[2]}</td>
        <td>${row[3]}</td>
        <td>${row[4]}</td>
        <td id="statusCell${accidentNumber}">
        ${row[5]}
        </td>
        <td>
          <input type="file" id="fileUpload${accidentNumber}" style="display: none;" />
          <button onclick="uploadVideo('${accidentNumber}')">動画アップロード</button>
        </td>
        <td>
          <i class= "fas fa-trash" style="cursor: pointer;color:red;" onclick="deleteRow('${accidentNumber}')" title="Delete"></i>
        </td>
      `;
  tableBody.appendChild(newRow);
}

function deleteRow(accidentNumber) {
  if (!confirm('このレコードを削除してもよろしいですか?')) return;

  fetch('/delete', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ accidentNumber }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.status === 'success') {
        const row = document.getElementById(`row${accidentNumber}`);
        if (row) {
          row.remove();
        }
        alert('レコードが正常に削除されました。');
      } else {
        alert('レコードを削除できませんでした。');
      }
    });
}

function updateStatus(accidentNumber) {
  fetch('/update_status', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ accidentNumber }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.status === 'success') {
        const updatedStatus = data.preprocessingStatus;
        const statusCell = document.getElementById(
          `statusCell${accidentNumber}`
        );
        statusCell.innerText = updateStatus;
      } else {
        alert('処理ステータスを更新できませんでした。');
      }
    })
    .catch((error) => {
      console.error('Error fetching procesisng status', error);
      alert('An error occured while updating processing status');
    });
}

function uploadVideo(accidentNumber) {
  const fileInput = document.getElementById(`fileUpload${accidentNumber}`);
  const row = document.getElementById(`row${accidentNumber}`);
  const videoStatus = row.cells[4].innerText;
  if (videoStatus === 'あり') {
    if (!confirm('すでに動画があります。上書きしますか?')) {
      return;
    }
  }
  fileInput.click();

  fileInput.addEventListener('change', function () {
    const formData = new FormData();
    formData.append('accidentNumber', accidentNumber);
    formData.append('file', fileInput.files[0]);

    fetch('/upload', {
      method: 'POST',
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === 'success') {
          alert('ファイルが正常にアップロードされました!');

          const row = fileInput.closest('tr');

          row.cells[4].innerText = 'あり';

          const accidentNumberCell = document.getElementById(
            `accidentNumberCell${accidentNumber}`
          );
          //accidentNumberCell.innerHTML = `<a href= "/process/${accidentNumber}">${accidentNumber}</a>`;

          fetch('/gemini_step1', {
            method: 'POST',
          })
            .then((response) => response.json())
            .then((geminiData) => {
              if (geminiData.status === 'success') {
                accidentNumberCell.innerHTML = `<a href= "/process/${accidentNumber}">${accidentNumber}</a>`;
                alert('ビデオの前処理が完了しました');
                window.location.reload();
                // Optionally update UI to show processing is in progress
              } else {
                alert('Error initiating Gemini Step 1 processing.');
              }
            })
            .catch((error) => {
              console.error('Error during gemini_step1 fetch:', error);
              alert('An error occurred while calling Gemini Step 1.');
            });
        } else {
          alert('ファイルアップロードに失敗しました。');
        }
      })
      .catch((error) => {
        console.error('Error during file upload:', error);
        alert('An error occurred during the file upload.');
      });
  });
}

//           const row = fileInput.closest('tr');
//           row.cells[4].innerText = 'あり';
//           row.cells[6].innerText = data.filename;

//           const accidentNumberCell = document.getElementById(
//             `accidentNumberCell${accidentNumber}`
//           );
//           accidentNumberCell.innerHTML = `<a href= "/process/${accidentNumber}">${accidentNumber}</a>`;
//         } else {
//           alert('ファイルのアップロードに失敗しました。');
//         }
//       });
//   });
// }

function previewVideo() {
  fetch('/videopath')
    .then((response) => {
      if (!response.ok) {
        throw Error('');
      }
      return response.json();
    })
    .then((data) => {
      const videoUrl = data.data;
      window.open(videoUrl, '_blank');
      if (videoUrl) {
        window.open(videoUrl, '_blank');
      } else {
        alert('動画がありません');
      }
    });
}
