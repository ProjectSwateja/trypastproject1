
import streamlit as st
import tempfile
import time
from PIL import Image
import google.generativeai as genai
import os
import pathlib
import textwrap
from dotenv import load_dotenv
load_dotenv()
from typing import Tuple, TypeVar, Union
import re
st.set_page_config(layout="wide")
st.title("事故動画分析")

# Gemini Pro Integration
os.environ['GOOGLE_API_KEY'] = "AIzaSyDHerzbcFUHIZDbIULhZnd_09BzDVEOrsI"  
genai.configure(api_key=os.environ['GOOGLE_API_KEY'])

generation_config = {
    "max_output_tokens": 5000,
    "temperature": 0.2,
    "top_p": 0.2,
}

model = genai.GenerativeModel('gemini-1.5-pro-001')

# initialize session state to manage visibility of fault percentage
if 'show_fault_percentage' not in st.session_state:
    st.session_state.show_fault_percentage = False
#prompt = st.text_area("prompt", "")
prompt_105 = '''Analyse the video and provide the following information:

Step1: Type of incident:
 
Step2: Place of incident:
 
Step3: Traffic signal:(Yes/No/could not identify)
 
Step4: Identify road condition.

'''

prompt_104 = '''Give me the criteria for selecting the speed of car 

- Type of incident: (Choose from the options) 

- Place of incident: (Choose from the options) 

- Traffic signal present: (Yes/No) 

- Priority road present: (Yes/No) 

- Scenario: (Choose from the options) '''

initial_prompt = """
• -For identification of CarA and CarB: 
if user specified {car_a_identify} then,
then Select the {car_a_identify} as carA

if user specified {car_b_identify} then,
then Select the {car_b_identify} as carB 
 
else
user is unable to find CarA and CarB identification then
Select CarA which has Dashcam mounted on it or car which travelling on priority road.
Select carB which collides or can be collided with carA as carB or car travelling on side road rather than priority road.

• -Consider basic fault percentage carA {carA_fault}%:
• -Consider basic fault percentage carB {carB_fault}%:

•	-CarA's {car_a_modifier}
•	-CarB's {car_b_modifier}. 
 
• Analyze the incident video and generate the report summary. 
• -Specify which is CarA and CarB.
• -Give me the timestamp with sequence of events and potential causes. 
• -Give me the detailed Reasoning for this accident. 
• -Give me the list of applied rules and neglected rules and also show the points as well. 
• -Determine the fault percentage for car A and Car B. 
• -Give me the Justification summary and Conclusion for this event. 
"""


def get_gemini_response(question,prompt,image=None):
    model = genai.GenerativeModel('gemini-1.5-pro-001')
    if image:
        response = model.generate_content([question,image,prompt],generation_config=generation_config)
    return response.text


def analyze_video(scenario_number,prompt, video_path):
    with open(f"{scenario_number}_Scenario_drilldown_rulebook.txt", "r") as f:
        scenario_description = f.read()
    if video_path:
        print(video_path)
        image = genai.upload_file(path=video_path)
        while image.state.name == "PROCESSING":
            print('Waiting for video to be processed.')
            time.sleep(10)
            image = genai.get_file(image.name)
        if image.state.name == "FAILED":
            raise ValueError(image.state.name)
        print(f'Video processing complete: ' + image.uri)
        analysis_output = get_gemini_response(
            scenario_description,
            f"{prompt}.",
            image
        )
    return analysis_output

def calculate_fault_percentage(scenario_number, video_path, prompt1):
    with open(f"{scenario_number}_Fault_Percentage_rulebook.txt", "r") as f:
        fault_description = f.read()
    if video_path:
        print(video_path)
        image = genai.upload_file(path=video_path)
        while image.state.name == "PROCESSING":
            print('Waiting for video to be processed.')
            time.sleep(10)
            image = genai.get_file(image.name)
        if image.state.name == "FAILED":
            raise ValueError(image.state.name)
        print(f'Video processing complete: ' + image.uri)
        fault_cal = get_gemini_response(
            fault_description, 
            f"{prompt1}.",
             image
            
        )
    return fault_cal


with st.sidebar:
    scenario_number = st.selectbox("シナリオ番号:", ("104", "105"))

col1, col2 = st.columns([1, 1])

if scenario_number is not None:
    with col2:
        #st.subheader("Scenario Description")
        #scenario_text = ""
        if scenario_number == "104":
            prompt = prompt_104
            #with open("104_fault.txt", "r") as file:
                #scenario_text = file.read()
        elif scenario_number == "105":
            prompt = prompt_105
            #with open("105_fault.txt", "r") as file:
                #scenario_text = file.read()

        #st.write(scenario_text)
with col1:
    uploaded_file = st.file_uploader("📤動画ファイルをアップロード", type=["mp4"])
    video_path = None

    if uploaded_file is not None:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as temp_file:
            temp_file.write(uploaded_file.read())
            video_path = temp_file.name

    if video_path:
        st.video(video_path)

#prompt = "Describe the video."
# Storing the initial analysis output in session state
if 'analysis_output' not in st.session_state:
    st.session_state.analysis_output = None 

#if st.button("シナリオ判定を実行"):
  #  if video_path and prompt: 
      #  result3 = analyze_video(prompt,video_path)
      #  st.markdown(result3)
   # else:
      #  st.warning("動画ファイルを選択してください")

if st.button("シナリオ判定を実行"):
    #st.session_state.show_fault_percentage = True
    if video_path and scenario_number and prompt:
        analysis_output = (" ")
        analysis_output = analyze_video(scenario_number, prompt, video_path)
        st.session_state.analysis_output = analysis_output
        st.subheader("分析結果:")
        st.session_state.show_fault_percentage = True
       # st.markdown(analysis_output)
    else:
        st.warning("動画ファイルを選択してください")

st.markdown(" ")
if 'analysis_output' in st.session_state and st.session_state.analysis_output is not None:
    st.subheader("シナリオ判定結果：")
    st.markdown(st.session_state.analysis_output)

# Store the fault percentage calculation output in session state
if 'fault_percentage_output' not in st.session_state:
    st.session_state.fault_percentage_output = None


if st.session_state.show_fault_percentage:
    st.subheader("過失割合再計算")
    st.markdown(" ")

    with st.form(key= "input"):
        cols = st.columns([1,4])
        cols[0].write("車両判別")
        car_id_A = cols[1].text_input(f"車両 A ", key= f"input_1")
        st.markdown(" ")  

        cols = st.columns([1,4])
        cols[0].write("")
        car_id_B = cols[1].text_input(f"車両 B ", key= f"input_2")
        st.markdown(" ")  

        cols = st.columns([1,4])
        cols[0].write("基本過失割合")
        ini_fault_A = cols[1].text_input(f"車両 A*", key= f"input_3", placeholder = "必須")
        st.markdown(" ")  

        cols = st.columns([1,4])
        cols[0].write("")
        ini_fault_B = cols[1].text_input(f"車両 B*", key= f"input_4", placeholder = "必須")
        st.markdown(" ")  

        tooltip_text = """ 修正要素（著しい過失、重過失）の記載がない場合、修正要素（著しい過失、重過失）を考慮せず過失割合を計算をします。
        修正要素とは下記です。
        著しい過失：脇見運転等の前方不注意、急ハンドル・急ブレーキ、携帯の使用、カーナビ等の注視、15km/h～30km/h未満の速度違反、酒気帯び運転
        重過失：酒酔い運転、居眠り運転、無免許運転、おおむね30km/h以上の速度違反、過労、病気及び薬物の影響"""
        
            # Add custom CSS for the tooltip 
        st.markdown(""" 
                    <style> 
                    .tooltip { 
                        position: relative; 
                        display: inline-block; 
                        cursor: pointer; } 
                    .tooltip .tooltiptext { 
                        visibility: hidden; 
                        width: 500px; 
                        background-color: #d3d3d3; 
                        color: #000;  
                        text-align: left; 
                        border-radius: 5px; 
                        padding: 5px; 
                        position: absolute; 
                        z-index: 1; 
                        bottom: 50%;   
                        left: 110%; 
                        # margin-left: -150px; 
                        opacity: 0; 
                        transition: opacity 0.3s; 
                    }   
                    .tooltip .tooltiptext::after { 
                        content: "";   
                        position: absolute; 
                        top: 50%; 
                        left: -5px;
                        margin-top: -5px;  
                        border-width: 5px; 
                        border-style: solid; 
                        border-color: transparent #555 transparent transparent; 
                    } 
                    .tooltip:hover .tooltiptext { 
                        visibility: visible; 
                        opacity: 1; 
                    } 
                    </style> 
                    """, unsafe_allow_html=True) 
        cols = st.columns([1, 4]) 
        cols[0].markdown(f""" 
            <div class="tooltip"> 
                <span>修正要素(著しい過失、重過失) (ℹ️)</span>
                <span class="tooltiptext">{tooltip_text}</span>    
            </div> 
            """, unsafe_allow_html=True) 
        corr_A = cols[1].text_input("車両 A", key="input_5")
        st.markdown(" ")  

        cols = st.columns([1,4])
        cols[0].write("")
        corr_B = cols[1].text_input(f"車両 B:", key= f"input_6")
        st.markdown(" ")  

        st.markdown(" ")
        submit_button = st.form_submit_button(label ="過失割合計算・最終レポート生成")
         
    

        if submit_button:
            error_messgaes = []
            if not ini_fault_A:
                if not ini_fault_B:
                        error_messgaes.append("過失割合を入力してください。")
            if ini_fault_A and ini_fault_B:
                try:
                    total_per=int(ini_fault_A) + int(ini_fault_B)
                    if total_per !=100:
                        error_messgaes.append("車両AとBの基本過失割合合計は100になる必要があります.")
                except ValueError:
                    error_messgaes.append("過失割合を入力してください。")

            if error_messgaes:
                for error_message in error_messgaes:
                    st.error(error_message)
                    time.sleep(1)
                    st.empty()
            else:
                prompt1 = initial_prompt.format(
                carA_fault=ini_fault_A,
                carB_fault=ini_fault_B,
                car_a_identify=car_id_A,
                car_b_identify=car_id_B,
                car_a_modifier=corr_A,
                car_b_modifier=corr_B
                )
                if video_path and scenario_number and prompt:
                    fault_cal = calculate_fault_percentage(scenario_number, video_path, prompt1)
                    #st.write(prompt1)
                    st.subheader("分析結果:")
                    st.markdown(fault_cal)
                    st.session_state.fault_percentage_output = fault_cal
               
