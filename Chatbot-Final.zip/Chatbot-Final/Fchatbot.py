import streamlit as st
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.llms import AzureOpenAI
import os
from langchain.chat_models import AzureChatOpenAI
from loguru import logger
from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferMemory
import random

llm = AzureChatOpenAI(temperature=0.4,
    openai_api_base="https://gen-ai-training-jg.openai.azure.com/",
    openai_api_version="2023-03-15-preview",
    deployment_name="gpt35jg",
    openai_api_key="a1027151518e483e8b89170d594e156f",
    openai_api_type="azure")

# Define prompt templates
prompt_templates = {
    "code_generation": PromptTemplate(
    input_variables=["task", "language_type"],
    #template="Write a complete well structured program code for given {task} in specified {language_type}.Also specified input and output example and explain the code in breif"
    template="Write a complete ready to execute code for given {task} in specified {language_type}, include required libraries.Do not add other comments and extra symbols. Also dont add ``` python ''' characters"

    ),
    "code_debugging": PromptTemplate(
        input_variables=["code", "error_message"],
        template="""I have the following code: ```\n{code}\n```\n
        This code is producing the following error: ```\n{error_message}\n```\n 
        Please debug the code or resolve the given error.
        Modified Code: Give the modified code snippet. 
        Explanation: A detailed explanation of the changes made and why they were necessary."""
        
    ),
    "code_documentation": PromptTemplate(
        input_variables=["concept","language_type","language1"],
        #template="Generate documentation for the following Python code:\n```python\n{code}\n```\nInclude a description of what the code does, the parameters it takes, and the return value."
        #template="""Write the detailed documentation with detailed information for {concept} in the given {language1}..
        template="""Write the detailed documentation with detailed information for the {concept} in {language1}.
        If the {concept} and {language_type} mentioned give the detailed documentation for concept with respective mentioned programming language in the give {language1}. For the ppt or other document, write the contents/data in detail """
        #template="You are a coding expert. write a detail documentation for {concept} the {language1}.If {concept} and {language_type} both specify give the {concept} documentation in {language1}."

    ),
     "code_explanation": PromptTemplate(
        input_variables=["code","language_type","language2"],
        #template="Generate documentation and give comments for the following Python code:\n```python\n{code}\n```\nInclude a description of what the code does, give the comments,the parameters it takes, and the return value."
        #template="debug the following code:\n```python\n{code}\n```\n Include new and old code as well.\n Give stepwise explanation"
        template="""
        Give the explanation of the {code} for the mentioned programing language in selected {language2}. 
        **If the concept is provided give the detailed explanation of {code} in the give {language_type} programming language in the {language2}. With the code and example if possible.**
        If only concept is mentioned, go ahead with the explanation of only the {code} in selected {language2}.
		If the code is provided, then explain the code in details and re-write the code by giving comments in the code in selected {language2}.
        """
    ),
    "other": PromptTemplate(
        input_variables=["history", "input"],
        template="""
        Instruction : You are a helpful and knowledgeable AI assistant used predominently for Coding purposes.

        {history}

        User: {input}

        Assistant:"""
)
}

# Create LLMChains for each task
chains = {
    task_type: LLMChain(llm=llm, prompt=prompt_template) 
    for task_type, prompt_template in prompt_templates.items()
}
#memory = ConversationBufferMemory()
#conversation = ConversationChain(llm=llm,verbose=True, memory=memory,prompt=PromptTemplate)


# Tagline and Tip Lists
taglines = [
    "🎓Code Smarter, Not Harder. Get Expert Help Here.",
    "🎓Unlocking Your Coding Potential.",
    "🎓Mastering the Art of Code.",
    "🎓Code is poetry that can be understood by machines.",
    "🎓The only way to learn to code is to code.",
    "👨🏻‍🏫Every line of code is a step closer to your dream.",
    "👨🏻‍🏫Don't be afraid to break things. That's how you learn.",
    "👨🏻‍🏫The best code is the code that works.",
    "👨🏻‍🏫The journey of a thousand miles begins with a single line of code.",
    "👨🏻‍🏫Every error is an opportunity to learn.",
    "👨🏻‍🏫Don't give up. You've got this!",
    "👨🏻‍🏫The only limit is your imagination.",
    "👨🏻‍🏫Keep calm and code on.",
    "🤖Debugging is the art of removing the bugs that weren't there before.",
    "🤖Code together, win together.",
    "🤖Collaboration is the key to success in coding.",
    "🤖Building software is a team sport.",
    "🤖Code is art. Express yourself.",
    "🤖The world needs more people who can code and solve problems." ,
    "🤖Think outside the box, and your code will be amazing.", 
    "🤖Don't be afraid to experiment. The best code comes from exploration." 
]

coding_tips = [
    "💡Use meaningful variable names to improve code readability.",
    "💡Employ list comprehensions to write compact and efficient code.",
    "💡Consider using decorators to enhance code modularity and reusability.",
    "💡Always test your code thoroughly for potential bugs.",
    "💡Strive for clean and well-documented code for easier collaboration.",
    "💡Meaningful Names: Use descriptive names for variables, functions, and classes. It makes your code easier to understand and maintain.",
    "💡Comments: Write clear and concise comments to explain complex logic, edge cases, or design decisions.",
    "💡Code Readability: Indentation, consistent formatting, and whitespace make your code easier to read and debug.",
    "💡Modularization: Break down complex programs into smaller, reusable functions or modules. This improves maintainability and reduces code duplication.",
    "💡Error Handling: Implement robust error handling to make your programs more reliable and prevent crashes."
    ]

# Function to generate a random tagline and tip
def get_random_tagline_and_tip():
    random_tagline = random.choice(taglines)
    random_tip = random.choice(coding_tips)
    return random_tagline, random_tip

# Display the dynamic tagline and tip
random_tagline, random_tip = get_random_tagline_and_tip()
st.sidebar.markdown("<h1 style='text-align: left; margin-top: 0;'>🤗💬 Coding Chatbot🤖</h1>", unsafe_allow_html=True)
#st.title('🤗💬 Coding Chatbot🤖')
st.title(random_tagline)
#st.markdown(
  # """
    #<h2 style="font-size: 3.5em;">$random_taglien</h2> 
    #""",
    #unsafe_allow_html=True
#)
st.sidebar.header("Coding Tip")
st.sidebar.info(random_tip)

with st.sidebar:
    #st.title('🤗💬 Coding Chatbot🤖')
    st.title('🤝 Get unstuck with instant coding help')
    st.markdown("How can I help you? I can generate code, debug it, generate documentation, or explain concepts")
    task_type = st.selectbox("💻 Choose a task:", ("Code Generation", "Code Debugging", "Code Documentation", "Concept Explanation","Other"),key="sel_task")
    language_type=st.selectbox("🧑‍💻Choose a programming language:", ("","Python", "JAVA", "C", "CPP", "Other"),key="sel_lang")

memory = ConversationBufferMemory()
conversation = ConversationChain(llm=llm,verbose=True ,memory=memory,prompt=prompt_templates["other"])

counter = 0
if task_type == "Code Generation":
    st.title('🚀Code Generation')
    task = st.text_area("Enter your code request:", height=150)
    #language_type=st.selectbox("🧑‍💻Choose a language:", ("JAVA", "Python", "C", "CPP"),key="sel_lang")
    if st.button("Generate Code"):
        with st.spinner("Generating code..."):
            code_output = chains["code_generation"].run(task=task,language_type=language_type)
            #st.markdown(code_output)
            ext = ".txt"
            if(language_type == "JAVA"): 
                ext = ".java"
            elif(language_type == "Python"):
                 ext = ".py"
            elif(language_type == "C"):
                 ext = ".c"
            elif(language_type == "CPP"):
                ext = ".cpp"
            st.code(code_output)
            st.download_button(
                label="Download Code",
                data=code_output,
                file_name="code"+ext,
                mime="text/plain",)

elif task_type == "Code Debugging":
    st.title('🐞Code Debug')
    st.markdown('🕵You can provide either code/error message or both')
    code = st.text_area("Enter your code:", height=150)
    
    error_message = st.text_area("Enter the error message:", height=50)
    if st.button("Debug Code"):
        with st.spinner("Debugging..."):
            debugging_output = chains["code_debugging"].run(code=code, error_message=error_message)
            st.markdown(debugging_output)
            st.download_button(
                label="Download updated code",
                data=debugging_output,
                file_name="updated_code.txt",
                mime="text/plain",)
              
elif task_type == "Code Documentation":
    st.title('🗒️Code Documentation')
    concept = st.text_area("Enter your code/Concept, you can also specify document format:", height=150)
    language1=st.selectbox("🧑‍💻Choose a language:", ("English","Japanese", "Hindi", "German"),key="sel_lang1`")

    #language_type=st.selectbox("🧑‍💻Choose a language:", ("JAVA", "Python", "C", "CPP"),key="sel_lang")
    if st.button("Generate Documentation"):
        with st.spinner("Generating documentation..."):
            documentation_output = chains["code_documentation"].run(concept=concept,language_type=language_type,language1=language1)
            st.markdown(documentation_output)
            st.download_button(
                label="Download Document",
                data=documentation_output,
                file_name="Code_Documentation.txt",
                mime="text/plain",)

elif task_type == "Concept Explanation":
    st.title('📝Concept Explanation')
    code = st.text_area("Enter your code/Concept which you want to understand:", height=150)
    language2=st.selectbox("🧑‍💻Choose a language:", ("English","Japanese","Hindi","German"),key="sel_lang2`")

    #language_type=st.selectbox("🧑‍💻Choose a language:", ("JAVA", "Python", "C", "CPP"),key="sel_lang")
    if st.button("Explain Concept"):
        with st.spinner("Explaining..."):
            explanation_output = chains["code_explanation"].run(code=code, language_type=language_type,language2=language2)
            #st.text(explanation_output)
            st.markdown(explanation_output)
            st.download_button(
                label="Download explanation",
                data=explanation_output,
                file_name="Code_concept.txt",
                mime="text/plain",)

elif task_type == "Other":
    st.title('🐞Complete code Assistant')
    if 'messages' not in st.session_state:
        st.session_state.messages = []
 
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    else :
        for message in st.session_state.chat_history:
         memory.save_context({'input':message['human']},{'output':message['AI']})
 
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
   
    if prompt := st.chat_input("Enter your request, code or concept for which you want help:"):
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)
 
        #get response from AI
       
        response = conversation.predict(input=prompt)
        with st.chat_message("assistant"):
            st.write(response)
        message = {'human':prompt,'AI':response}
        st.session_state.messages.append({"role": "assistant", "content": response})
        st.session_state.chat_history.append(message)

                